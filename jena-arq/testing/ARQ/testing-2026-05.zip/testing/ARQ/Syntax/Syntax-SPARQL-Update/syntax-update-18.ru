CLEAR GRAPH <graph>
