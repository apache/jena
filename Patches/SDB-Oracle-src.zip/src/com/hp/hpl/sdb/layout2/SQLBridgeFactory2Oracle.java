package com.hp.hpl.jena.sdb.layout2;

import java.util.List;

import com.hp.hpl.jena.sdb.core.SDBRequest;
import com.hp.hpl.jena.sdb.core.sqlnode.SqlNode;
import com.hp.hpl.jena.sdb.store.SQLBridge;
import com.hp.hpl.jena.sparql.core.Var;

public class SQLBridgeFactory2Oracle extends SQLBridgeFactory2 {
	
	public  SQLBridgeFactory2Oracle() { }
	
    public SQLBridge create(SDBRequest request, SqlNode sqlNode, List<Var> projectVars)
    {	
		return new SQLBridge2Oracle(request, sqlNode, projectVars) ;
    }

}
