/*
 * (c) Copyright 2005, 2006 Hewlett-Packard Development Company, LP
 * All rights reserved.
 * [See end of file]
 */

package arq;

import arq.cmd.CmdException;
import arq.cmd.CmdUtils;
import arq.cmd.TerminateException;
import arq.cmdline.* ;

import com.hp.hpl.jena.rdf.model.* ;

import com.hp.hpl.jena.query.*;
//import com.hp.hpl.jena.query.resultset.*;
import com.hp.hpl.jena.query.resultset.ResultSetFormat;

import java.io.* ;

/** Read and write result sets */

public class rset
{
    static { CmdUtils.setLog4j() ; CmdUtils.setN3Params() ; }

    static String usage = rset.class.getName()+
            " [--in syntax] [--out syntax] [--file FILE | FILE ]\n"+ 
            "  where syntax is one of XML, RDF" ;

    public static void main (String [] argv)
    {
        try {
            main2(argv) ;
        }
        catch (CmdException ex)
        {
            System.err.println(ex.getMessage()) ;
            if ( ex.getCause() != null )
                ex.getCause().printStackTrace(System.err) ;
        }
        catch (TerminateException ex) { System.exit(ex.getCode()) ; }
    }
        
    public static void main2(String [] argv)
    {
        CmdLineArgs cl = new CmdLineArgs(argv) ;
        ArgDecl vDecl = new ArgDecl(ArgDecl.NoValue, "v", "verbose") ;
        ArgDecl helpDecl = new ArgDecl(ArgDecl.NoValue, "h", "help") ;
        ArgDecl debugDecl = new ArgDecl(ArgDecl.NoValue, "debug") ;
        
        // Languages - the syntax the result set 
        ArgDecl inDecl = new ArgDecl(ArgDecl.HasValue, "in") ;
        ArgDecl outDecl = new ArgDecl(ArgDecl.HasValue, "out") ;
        
        ArgDecl fileDecl = new ArgDecl(ArgDecl.HasValue, "file") ; 
        
        
        cl.add(vDecl) ;
        cl.add(debugDecl) ;
        cl.add(helpDecl) ;
        
        cl.add(inDecl) ;
        cl.add(outDecl) ;
        cl.add(fileDecl) ;
    
        try {
            cl.process() ;
        } catch (IllegalArgumentException ex)
        {
            System.err.println(ex.getMessage()) ;
            throw new TerminateException(9) ;
        }
    
        if ( cl.contains(helpDecl) )
        {
            usage() ;
            throw new TerminateException(0) ;
        }
        
        //if ( cl.contains(vDecl) )
        
        //if ( cl.contains(debugDecl) )
        
        ResultSetFormat inSyntax = null ; 
        if ( cl.contains(inDecl) )
        {
            inSyntax = ResultSetFormat.lookup(cl.getValue(inDecl)) ;
            if ( inSyntax.equals(ResultSetFormat.syntaxText) )
            {
                System.err.println("Can't read in the tabular text format") ;
                throw new TerminateException(2) ;
            }
        }
    
        ResultSetFormat outSyntax = null ; 
        if ( cl.contains(outDecl) )
            outSyntax = ResultSetFormat.lookup(cl.getValue(outDecl)) ;
        
        String filename = null ;
        
        if ( cl.contains(fileDecl) )
            filename = cl.getValue(fileDecl) ;
        
        if ( filename == null )
        {
            for ( int i = 0 ; i < cl.getNumPositional() ; i++ )
            {
                String s = cl.getPositionalArg(i) ;
                filename = s ;
                break ;
            }
        }
         
        if ( filename != null && inSyntax == null )
            inSyntax = ResultSetFormat.guessSyntax(filename) ;

        // Defaults
        if ( inSyntax == null )
            inSyntax = ResultSetFormat.syntaxRDF ;

        if ( outSyntax == null )
            outSyntax = ResultSetFormat.syntaxText ;
        
        ResultSet rs = parseResultSet(filename, inSyntax) ;
        printResultSet(rs, outSyntax) ;
    }

    static ResultSet parseResultSet(String filename, ResultSetFormat inSyntax)
    {
        if ( filename == null )
        {
            msg("No file input") ;
            throw new TerminateException(9) ;
        }
        
        //if ( filename == null || filename.equals("-") )
        if ( filename.equals("-") )
            return ResultSetFactory.load(System.in, inSyntax) ;
        
        // Only copes with result set results. 
        ResultSet rs = ResultSetFactory.load(filename, inSyntax) ;
        if ( rs == null )
            throw new TerminateException(9) ;
        return rs ;
    }

    private static void printResultSet(ResultSet resultSet, ResultSetFormat outSyntax)
    {
        if ( outSyntax.equals(ResultSetFormat.syntaxXML) )
        {
            ResultSetFormatter.outputAsXML(System.out, resultSet) ;
            return ;
        }
        
        if ( outSyntax.isCompatibleWith(ResultSetFormat.syntaxRDF) )
        {
            Model m = ResultSetFormatter.toModel(resultSet) ;
            String rdfSyntax = "RDF/XML-ABBREV" ;
//            if ( outSyntax.equals(ResultSetFormat.syntaxRDF) )
//                rdfSyntax = "RDF/XML-ABBREV" ;
            if ( outSyntax.equals(ResultSetFormat.syntaxRDF_N3) )
                rdfSyntax = "N3" ;
            if ( outSyntax.equals(ResultSetFormat.syntaxRDF_TTL) )
                rdfSyntax = "N3" ;
            if ( outSyntax.equals(ResultSetFormat.syntaxRDF_NT) )
                rdfSyntax = "N-TRIPLES" ;
            m.write(System.out, rdfSyntax) ;
            return ;
        }
        
        if ( outSyntax.equals(ResultSetFormat.syntaxText) )
        {
            ResultSetFormatter.out(System.out, resultSet) ;
            return ;
        }
        
        if ( outSyntax.equals(ResultSetFormat.syntaxJSON) )
        {
            ResultSetFormatter.outputAsJSON(System.out, resultSet) ;
            return ;
        }
        
        msg("Unknown output syntax: "+outSyntax) ;
        throw new TerminateException(9) ;
    }

    static void msg(String msg)
    {
        System.err.println(msg) ;
    }
    
    static void usage() { msg(usage) ; }
    
    static void usage(PrintStream out)
    {
        out.println(usage) ;
        
    }
}

/*
 * (c) Copyright 2005, 2006 Hewlett-Packard Development Company, LP
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in the
 *    documentation and/or other materials provided with the distribution.
 * 3. The name of the author may not be used to endorse or promote products
 *    derived from this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE AUTHOR ``AS IS'' AND ANY EXPRESS OR
 * IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES
 * OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED.
 * IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR ANY DIRECT, INDIRECT,
 * INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT
 * NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
 * DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
 * THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
 * (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF
 * THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */