/*
 * (c) Copyright 2006 Hewlett-Packard Development Company, LP
 * All rights reserved.
 * [See end of file]
 */

package arq.examples.ext;

import java.util.List;

import com.hp.hpl.jena.graph.Node;
import com.hp.hpl.jena.graph.Triple;
import com.hp.hpl.jena.query.QueryBuildException;
import com.hp.hpl.jena.query.QueryExecException;
import com.hp.hpl.jena.query.core.ARQInternalErrorException;
import com.hp.hpl.jena.query.core.ElementBasicGraphPattern;
import com.hp.hpl.jena.query.engine.QueryIterator;
import com.hp.hpl.jena.query.engine1.ExecutionContext;
import com.hp.hpl.jena.query.engine1.PlanElement;
import com.hp.hpl.jena.query.engine1.plan.PlanBasicGraphPattern;
import com.hp.hpl.jena.query.expr.E_Regex;
import com.hp.hpl.jena.query.expr.Expr;
import com.hp.hpl.jena.query.expr.NodeVar;
import com.hp.hpl.jena.query.extension.Extension;
import com.hp.hpl.jena.query.util.Utils;
import com.hp.hpl.jena.vocabulary.RDFS;

/** Example extension or property function to show rewriting part of a query.
 *  This approach could be used to access an external index (e.g. Lucene) although here
 *  we just show looking for RDFS labels.
 *  
 *  Implements a <code>EXT ext:search(?x, "something")</code> or
 *  
 *  <pre>
 *    ?x ext:search "something"
 *  </pre>
 *  as 
 *  <pre>
 *    ?x rdfs:label ?label . FILTER regex(?label, "something", "i")
 *  </pre>
 *  
 *  by simply doing a regex but could be used to add access to some other form of
 *  indexing or external structure.
 * 
 * @author Andy Seaborne
 * @version $Id: labelSearch.java,v 1.1 2006/08/12 19:43:19 andy_seaborne Exp $
 */ 

public class labelSearch implements Extension
{
    List myArgs = null;
    static int hiddenVariableCount = 0 ; 
    
    public void build(String uri, List args)
    {
        // Some checking
        if ( args.size() != 2 )
            throw new QueryBuildException(Utils.className(this)+": Must be two arguments");
        Expr arg1 = (Expr)args.get(0);
        if ( ! arg1.isVariable() )
            throw new QueryExecException(Utils.className(this)+": First argument must be a variable");
        
        Expr arg2 = (Expr)args.get(1);
        if ( ! arg2.isConstant() )
            throw new QueryExecException(Utils.className(this)+": Second argument must be a constant");
        if ( ! arg2.getConstant().isString() )
            throw new QueryExecException(Utils.className(this)+": Second argument must be a string");
        myArgs = args;
    }

    // Will be called once, with unevaluated arguments
    // To do a rewrite of part of a query, we must use the fundamental Extension interface.
    // The conmvenience Extension2 evaluates arguments and is for execution of a expression
    // for every solution arriving.  Here, we generate a new query processing stage
    // that handles all solutions.  
    
    public QueryIterator exec(QueryIterator input, List args, String uri, ExecutionContext execCxt)
    {
        // System.out.println("search") ; // Show it gets called once only
        if ( args != myArgs )
            // Should not happen, but ...
            throw new ARQInternalErrorException(Utils.className(this)+": Arguments have changed since checking");
        
        // Arguments
        Expr arg1 = (Expr)args.get(0);
        Node var1 = Node.createVariable(arg1.getVarName()) ;        // Checked it was a variable earlier
        hiddenVariableCount++ ;
        Node var2 = Node.createVariable("-search-"+hiddenVariableCount) ;   // Hidden variable
        
        Expr arg2 = (Expr)args.get(1);
        String pattern = arg2.getConstant().getString() ;       // Checked it was a string earlier.
        
        // Create a replacement graph pattern, using syntax elements
        
        // Triple patterns for   ? rdfs:label ?hiddenVar
        ElementBasicGraphPattern elementBGP = new ElementBasicGraphPattern();
        Triple t = new Triple(var1, RDFS.label.asNode(), var2) ;
        elementBGP.addTriple(t) ;

        // Regular expression for  regex(?hiddenVar, "pattern", "i") 
        Expr regex = new E_Regex(new NodeVar(var2.getName()), pattern, "i") ; 
        elementBGP.addConstraint(regex) ;
        
        // Turn into a query execute plan ... 
        PlanElement planBGP = PlanBasicGraphPattern.make(execCxt.getContext(), elementBGP);
        
        // System.out.print(planBGP.toString()) ;   // See what is generated
        return planBGP.build(input, execCxt) ;
    }
}

/*
 * (c) Copyright 2006 Hewlett-Packard Development Company, LP
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in the
 *    documentation and/or other materials provided with the distribution.
 * 3. The name of the author may not be used to endorse or promote products
 *    derived from this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE AUTHOR ``AS IS'' AND ANY EXPRESS OR
 * IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES
 * OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED.
 * IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR ANY DIRECT, INDIRECT,
 * INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT
 * NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
 * DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
 * THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
 * (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF
 * THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */