/*
 * (c) Copyright 2004, 2005, 2006 Hewlett-Packard Development Company, LP
 * All rights reserved.
 * [See end of file]
 */

package arq.cmd;

import java.io.IOException;
import java.util.List ;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import com.hp.hpl.jena.util.FileManager;
import com.hp.hpl.jena.util.FileUtils;
import com.hp.hpl.jena.query.*;
import com.hp.hpl.jena.query.core.ARQInternalErrorException;
import com.hp.hpl.jena.query.engineHTTP.QueryExceptionHTTP;
import com.hp.hpl.jena.query.engineHTTP.HttpQuery;
import com.hp.hpl.jena.query.lang.Parser;
import com.hp.hpl.jena.query.resultset.ResultSetException;
import com.hp.hpl.jena.query.util.IndentedLineBuffer;
import com.hp.hpl.jena.query.util.IndentedWriter;
import com.hp.hpl.jena.shared.JenaException;

/** State and operations for a query command execution.
 * 
 * @author Andy Seaborne
 * @version $Id: QCmd.java,v 1.43 2006/06/05 14:52:04 andy_seaborne Exp $
 */

public class QCmd implements java.io.Serializable
{
    static final long serialVersionUID = 7761L;
    static private Log log = LogFactory.getLog( QCmd.class );

    // Query
    private String queryString           = null ;
    private String queryFilename         = null ;
    private String syntaxHint            = null ;
    private Syntax inSyntax              = null ;
    private Syntax defaultSyntax         = null ;
    private Query query                  = null ;
    private String baseURI               = null ;
    
    // Target
    private Dataset dataset              = null ;
    private String service               = null ;
    private boolean forcePost            = false ;
    private FileManager fileManager      = null ;
    private List graphURLs               = null ;
    private List namedGraphURLs          = null ;
    private DataFormat dataSyntax        = null ;
    
    // Output
    private Syntax outSyntax             = null ;
    private boolean lineNumbers          = false ;
    private ResultsFormat outputFormat   = null ;
    private int messageLevel             = 0 ;
    private boolean timings              = false ;
    
    //   static boolean applyRDFS = false ;
    
    
    /** Execute a query given some information.
     *  Set what you know in the QueryContext object - this code will
     *  sort out missing stuff if it can.
     */
    
    public void query()
    {
        queryFixOutputFormat() ;

        if ( service != null )
            queryRemote() ;
        else
            queryLocal() ;
    }
    
    public void printQuery()
    {
//      if ( query == null )
//      return ;
        // Write it out
        IndentedWriter w = new IndentedWriter(System.out, lineNumbers) ;
        query.serialize(w, outSyntax) ;
        w.flush() ;
    }
    
    public void checkParse()
    {
        if ( ! Parser.canParse(outSyntax) )
            return ;
        
        IndentedLineBuffer buff = new IndentedLineBuffer() ;
        query.serialize(buff, outSyntax) ;
        
        String tmp = buff.toString() ;
        
        Query query2 = null ;
        try {
            String baseURI = null ;
            if ( ! query.explicitlySetBaseURI() )
                // Not in query - use the same one (e.g. file read from) .  
                baseURI = query.getBaseURI() ;
            
            query2 = QueryFactory.create(tmp, baseURI, outSyntax) ;
            
            if ( query2 == null )
                return ;
        } catch (UnsupportedOperationException ex)
        {
            // No parser after all.
            return ;
        }
        catch (QueryException ex)
        {
            System.out.println() ;
            System.out.println("**** Check failed : could not parse output query:: ") ;
            System.out.println("**** "+ex.getMessage()) ;
            return ;
        }
        
        if ( query.hashCode() != query2.hashCode() )
        {
            System.out.println() ;
            System.out.println("**** Check failed : reparsed query hashCode does not equal parsed input query") ;
            //return ;
        }
        
        if ( ! query.equals(query2) ) 
        {
            System.out.println() ;
            System.out.println("**** Check failed : reparsed output does not equal parsed input") ;
            return ;
        }
    }
    
    // -------- Local query
    
    void queryLocal()
    {
        long timeStart = System.currentTimeMillis() ;
        queryFixDataset() ;
        long timeLoad = System.currentTimeMillis() - timeStart ;
        if ( getTimings() )
            System.out.println("Load time = "+(timeLoad/1000.0)) ;
        dumpData() ;
        
        parseQuery() ;
        if ( query == null )
            return ;

        long timeStartQuery = System.currentTimeMillis() ;
        queryExecLocal() ;
        long timeQuery = System.currentTimeMillis()-timeStartQuery ;
        if ( getTimings() )
            System.out.println("Query time = "+(timeQuery/1000.0)) ;
    }
    
    void queryFixDataset()
    {
        // Fix up the data source
        try {
            if ( (graphURLs != null) || (namedGraphURLs != null) )
                dataset = 
                    DatasetFactory.create(graphURLs, namedGraphURLs, fileManager, null) ;
        } 
        catch (JenaException ex)
        {
            throw new CmdException("Error loading URL", ex) ;
        }
        catch (Exception ex)
        {
            throw new CmdException("Error creating dataset", ex) ;
        }
    }
    
    
    void queryFixOutputFormat()
    {
        // Fix the output format
        if ( outputFormat == null )
            outputFormat = ResultsFormat.FMT_TEXT ;
    }
    
    
    public void parseQuery()
    {
        // Create the query
        if ( query != null )
            return ;
        
        if ( queryFilename != null && queryString != null )
        {
            System.err.println("Both query string and query file name given" ) ;
            return ;
        }
        
        if ( queryFilename == null && queryString == null )
        {
            System.err.println("No query string and no query file name given" ) ;
            return ;
        }

        try
        {
            if ( queryFilename != null )
            {
                if ( queryFilename.equals("-") )
                {
                    try {
                        // Stderr?
                        queryString  = FileUtils.readWholeFileAsUTF8(System.in) ;
                        // And drop into next if
                    } catch (IOException ex)
                    {
                        throw new CmdException("Error reading stdin", ex) ;
                    }
                }
                else
                    query = QueryFactory.read(queryFilename, baseURI, inSyntax) ;
            }
            
            if ( queryString != null )
            {                
                if ( inSyntax == null )
                    inSyntax = Syntax.syntaxSPARQL ;
                query = QueryFactory.create(queryString, baseURI, inSyntax) ;
            }
        }
        catch (ARQInternalErrorException intEx)
        {
            System.err.println(intEx.getMessage()) ;
            if ( intEx.getCause() != null )
            {
                System.err.println("Cause:") ;
                intEx.getCause().printStackTrace(System.err) ;
                System.err.println() ;
            }
            intEx.printStackTrace(System.err) ;
            return ;
        }
        catch (QueryParseException parseEx)
        {
            System.err.println(parseEx.getMessage()) ;
            return  ;
        }
        catch (QueryException qEx)
        {
            System.err.println(qEx.getMessage()) ;
            return  ;
        }
        catch (JenaException ex)
        {
            System.err.println(ex.getMessage()) ;
            return  ;
        }
        catch (Exception ex)
        {
            System.out.flush() ;
            ex.printStackTrace(System.err) ;
            return ;
        }
    }
    
    void queryExecLocal()
    {
        try{
            QueryExecution qe = QueryExecutionFactory.create(query, dataset) ;
            
            // Check there is a dataset
            
            if ( dataset == null && ! query.hasDatasetDescription() )
            {
                System.err.println("Dataset not specified in query nor provided on command line.");
                return ;
            }
            
            if ( fileManager != null )
                qe.setFileManager(fileManager) ;

            QExec.doQuery(query, qe, outputFormat) ;
            qe.close() ;
        }
        catch (ARQInternalErrorException intEx)
        {
            System.err.println(intEx.getMessage()) ;
            if ( intEx.getCause() != null )
            {
                System.err.println("Cause:") ;
                intEx.getCause().printStackTrace(System.err) ;
                System.err.println() ;
            }
            intEx.printStackTrace(System.err) ;
        }
        catch (ResultSetException ex)
        {
            System.err.println(ex.getMessage()) ;
            ex.printStackTrace(System.err) ;
        }
        catch (QueryException qEx)
        {
            throw new CmdException("Query Exeception", qEx) ;
        }
        catch (Exception ex)
        {
            throw new CmdException("Exception", ex) ;
        }
    }
    
    // -------- Remote query
    
    private void queryRemote()
    {
        parseQuery() ;
        if ( query == null )
            return ;
        
        try {
            QueryExecution qe = QueryExecutionFactory.sparqlService(service, query, getGraphURLs(), getNamedGraphURLs()) ;
            if ( messageLevel > 0 )
                System.out.println(qe.toString()) ;
            
            if ( getForcePost() )
                HttpQuery.urlLimit = 0 ;
            
            QExec.doQuery(query, qe, outputFormat) ;
        } catch (QueryExceptionHTTP ex)
        {
            throw new CmdException("HTTP Exeception", ex) ;
        }
        catch (Exception ex)
        {
            System.out.flush() ;
            ex.printStackTrace(System.err) ;
        }
    }


    
    // -------- Common query execution 
    
    void dumpData()
    {
        boolean dumpDataset = false ;
        if ( dumpDataset )
        {
            if ( dataset == null )
                System.out.println("Dataset is null") ;
            else
                System.out.println("Dataset: "+dataset) ;
        }
    }
    
    
    
    
    //---- getters and Setters
    
    /** @return Returns the service URL */
    public String getServiceURL() { return service ; }
    
    /** @param serviceURL */
    public void setServiceURL(String serviceURL)
    { this.service = serviceURL ; }
    
    
    /** @return Returns the forcePost. */
    public boolean getForcePost()
    {
        return forcePost ;
    }

    /**  * @param forcePost The forcePost to set. */
    public void setForcePost(boolean forcePost)
    {
        this.forcePost = forcePost ;
    }

    /** @return Returns the baseURI. */
    public String getBaseURI()
    {
        return baseURI ;
    }
    
    /** @param baseURI The baseURI to set. */
    public void setBaseURI(String baseURI)
    {
        this.baseURI = baseURI ;
    }
    
    /** @return Returns the dataset. */
    public Dataset getDataset()
    {
        return dataset ;
    }
    
    /** @param dataset The dataset to set. */
    public void setDataset(Dataset dataset)
    {
        this.dataset = dataset ;
    }
    
    /** @return Returns the dataSyntax. */
    public DataFormat getDataSyntax()
    {
        return dataSyntax ;
    }
    
    /** @param dataSyntax The dataSyntax to set. */
    public void setDataSyntax(DataFormat dataSyntax)
    {
        this.dataSyntax = dataSyntax ;
    }
    
    /** @return Returns the defaultSyntax. */
    public Syntax getDefaultSyntax()
    {
        return defaultSyntax ;
    }
    
    /** @param defaultSyntax The defaultSyntax to set. */
    public void setDefaultSyntax(Syntax defaultSyntax)
    {
        this.defaultSyntax = defaultSyntax ;
    }
    
    /** @return Returns the fileManager. */
    public FileManager getFileManager()
    {
        return fileManager ;
    }
    
    /** @param fileManager The fileManager to set. */
    public void setFileManager(FileManager fileManager)
    {
        this.fileManager = fileManager ;
    }
    
    /** @return Returns the graphURLs. */
    public List getGraphURLs()
    {
        return graphURLs ;
    }
    
    /** @param graphURLs The graphURLs to set. */
    public void setGraphURLs(List graphURLs)
    {
        this.graphURLs = graphURLs ;
    }
    
    /** @return Returns the inSyntax. */
    public Syntax getInSyntax()
    {
        return inSyntax ;
    }
    
    /** @param inSyntax The inSyntax to set. */
    public void setInSyntax(Syntax inSyntax)
    {
        this.inSyntax = inSyntax ;
    }
    
    /** @return Returns the lineNumbers. */
    public boolean isLineNumbers()
    {
        return lineNumbers ;
    }
    
    /** @param lineNumbers The lineNumbers to set. */
    public void setLineNumbers(boolean lineNumbers)
    {
        this.lineNumbers = lineNumbers ;
    }
    
    public boolean getTimings() { return timings ; }
    public void setTimings(boolean t) { timings = t ; }
    
    
    /** @return Returns the messageLevel. */
    public int getMessageLevel()
    {
        return messageLevel ;
    }
    
    /** @param messageLevel The messageLevel to set. */
    public void setMessageLevel(int messageLevel)
    {
        this.messageLevel = messageLevel ;
    }
    
    /** @return Returns the namedGraphURLs. */
    public List getNamedGraphURLs()
    {
        return namedGraphURLs ;
    }
    
    /** @param namedGraphURLs The namedGraphURLs to set. */
    public void setNamedGraphURLs(List namedGraphURLs)
    {
        this.namedGraphURLs = namedGraphURLs ;
    }
    
    /** @return Returns the outputFormat. */
    public ResultsFormat getOutputFormat()
    {
        return outputFormat ;
    }
    
    /** @param outputFormat The outputFormat to set. */
    public void setOutputFormat(ResultsFormat outputFormat)
    {
        this.outputFormat = outputFormat ;
    }
    
    /** @return Returns the outSyntax. */
    public Syntax getOutSyntax()
    {
        return outSyntax ;
    }
    
    /** @param outSyntax The outSyntax to set. */
    public void setOutSyntax(Syntax outSyntax)
    {
        this.outSyntax = outSyntax ;
    }
    
    /** @return Returns the query. */
    public Query getQuery()
    {
        return query ;
    }
    
    /** @param query The query to set. */
    public void setQuery(Query query)
    {
        this.query = query ;
    }
    
    /** @return Returns the queryFilename. */
    public String getQueryFilename()
    {
        return queryFilename ;
    }
    
    /** @param queryFilename The queryFilename to set. */
    public void setQueryFilename(String queryFilename)
    {
        this.queryFilename = queryFilename ;
        setSyntaxHint(queryFilename) ;
    }
    
    /** @return Returns the queryString. */
    public String getQueryString()
    {
        return queryString ;
    }
    
    /** @param queryString The queryString to set. */
    public void setQueryString(String queryString)
    {
        this.queryString = queryString ;
    }

    /** @return Returns the syntaxHint. */
    public String getSyntaxHint()
    {
        return syntaxHint ;
    }

    /** @param syntaxHint The syntaxHint to set. */
    public void setSyntaxHint(String syntaxHint)
    {
        this.syntaxHint = syntaxHint ;
        if ( inSyntax == null )
            inSyntax = Syntax.guessQueryFileSyntax(syntaxHint) ;
        if ( outSyntax == null )
            outSyntax = Syntax.guessQueryFileSyntax(syntaxHint) ;
    }
    
}

/*
 * (c) Copyright 2004, 2005, 2006 Hewlett-Packard Development Company, LP
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in the
 *    documentation and/or other materials provided with the distribution.
 * 3. The name of the author may not be used to endorse or promote products
 *    derived from this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE AUTHOR ``AS IS'' AND ANY EXPRESS OR
 * IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES
 * OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED.
 * IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR ANY DIRECT, INDIRECT,
 * INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT
 * NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
 * DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
 * THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
 * (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF
 * THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */