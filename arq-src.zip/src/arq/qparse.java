/*
 * (c) Copyright 2004, 2005, 2006 Hewlett-Packard Development Company, LP
 * [See end of file]
 */


package arq;

import java.io.* ;
import java.util.* ;


import arq.cmd.CmdException;
import arq.cmd.CmdUtils;
import arq.cmd.QCmd;
import arq.cmd.TerminateException;
import arq.cmdline.* ;


import com.hp.hpl.jena.Jena;
import com.hp.hpl.jena.query.*;
import com.hp.hpl.jena.query.engine1.PlanElement;
import com.hp.hpl.jena.query.engine1.PlanFormatter;
import com.hp.hpl.jena.query.serializer.FmtElementARQ;
import com.hp.hpl.jena.query.util.QueryUtils;
import com.hp.hpl.jena.query.util.RelURI;
import com.hp.hpl.jena.util.FileUtils ;

//import org.apache.commons.logging.Log;
//import org.apache.commons.logging.LogFactory;

/** A program to parse and print a query.
 *
 * @author  Andy Seaborne
 * @version $Id: qparse.java,v 1.46 2006/06/15 19:48:23 andy_seaborne Exp $
 */

public class qparse
{
    static { CmdUtils.setLog4j() ; }

    static String usage = qparse.class.getName()+
            " [--in syntax] [--out syntax] [\"query\" | --query <file>\n"+
            "  where syntax is one of ARQ, SPARQL, RDQL\n" +
            "Other options: \n"+
            "  --num on|off   Line number ('on' by default)\n"+
            "  --base URI     Set the base URI for resolving relative URIs\n"+
            "  --plain        No pretty printing\n"+
            "  -n, --parse    Parse only - don't print\n"+
            "  ---planning    Turn planning on/off\n"+
            "  --show X       Show internal structure (X = query or plan)\n" ;
    
    public static void main (String [] argv)
    {
        try {
            main2(argv) ;
        }
        catch (CmdException ex)
        {
            System.err.println(ex.getMessage()) ;
            if ( ex.getCause() != null )
                ex.getCause().printStackTrace(System.err) ;
        }
        catch (TerminateException ex) { System.exit(ex.getCode()) ; }
    }
        
    public static void main2(String [] argv)
    {
        CmdLineArgs cl = new CmdLineArgs(argv) ;

        ArgDecl verboseDecl = new ArgDecl(ArgDecl.NoValue, "v", "verbose") ;
        cl.add(verboseDecl) ;

        ArgDecl quietDecl = new ArgDecl(ArgDecl.NoValue, "q", "quiet") ;
        cl.add(quietDecl) ;

        ArgDecl helpDecl = new ArgDecl(ArgDecl.NoValue, "h", "help") ;
        cl.add(helpDecl) ;

        ArgDecl debugDecl = new ArgDecl(ArgDecl.NoValue, "debug") ;
        cl.add(debugDecl) ;
        
        // Languages - the syntax the query is in
        ArgDecl inDecl = new ArgDecl(ArgDecl.HasValue, "in") ;
        cl.add(inDecl) ;

        ArgDecl outDecl = new ArgDecl(ArgDecl.HasValue, "out") ;
        cl.add(outDecl) ;

        ArgDecl fileDecl = new ArgDecl(ArgDecl.HasValue, "file", "query") ; 
        cl.add(fileDecl) ;
        
        // Misc
        ArgDecl numDecl       = new ArgDecl(ArgDecl.HasValue, "num") ;
        cl.add(numDecl) ;

        ArgDecl plainDecl     = new ArgDecl(ArgDecl.NoValue, "plain") ;
        cl.add(plainDecl) ;

        ArgDecl parseOnlyDecl = new ArgDecl(ArgDecl.NoValue, "n", "parse") ;
        cl.add(parseOnlyDecl) ;
        
        ArgDecl planningDecl = new ArgDecl(ArgDecl.HasValue, "planning") ;
        cl.add(planningDecl) ;

        ArgDecl showDecl = new ArgDecl(ArgDecl.HasValue, "show") ;
        cl.add(showDecl) ;

        ArgDecl baseDecl = new ArgDecl(ArgDecl.HasValue, "base") ;
        cl.add(baseDecl) ;

        ArgDecl versionDecl = new ArgDecl(ArgDecl.NoValue, "ver", "version", "V") ;
        cl.add(versionDecl) ;
        
        ArgDecl checkParseDecl = new ArgDecl(ArgDecl.NoValue, "ver", "version", "V") ;
        cl.add(checkParseDecl) ;
        
        boolean printQueryOut  = true ;
        boolean printParseTree = false ;
        boolean printPlan      = false ;
        boolean checkParsing   = true ;

        QCmd qCmd = new QCmd() ;
        
        try {
            cl.process() ;
        } catch (IllegalArgumentException ex)
        {
            System.err.println(ex.getMessage()) ;
            throw new TerminateException(1) ;
        }

        if ( cl.contains(helpDecl) )
        {
            usage() ;
            throw new TerminateException(0) ;
        }
        
        if ( cl.contains(versionDecl) )
        {
            System.out.println("ARQ Version: "+ARQ.VERSION+" (Jena: "+Jena.VERSION+")") ;
            throw new TerminateException(0) ;
        }
        
        if ( cl.contains(planningDecl) )
        {
            String v = cl.getValue(planningDecl) ;
            if ( v.equalsIgnoreCase("on") || v.equalsIgnoreCase("yes") )
                ARQ.getContext().set(ARQ.orderPlanning, "true") ;
            else if ( v.equalsIgnoreCase("off") || v.equalsIgnoreCase("no" ) )
                ARQ.getContext().set(ARQ.orderPlanning, "false") ;
            else
            {
                System.err.println("Unrecognized planning control: "+v) ;
                throw new TerminateException(3) ;
            }
        }

        if ( cl.contains(showDecl) )
        {
            List x = cl.getValues(showDecl) ;
            for ( Iterator iter = x.iterator() ; iter.hasNext(); )
            {
                String v = (String)iter.next() ;
                if ( v.equalsIgnoreCase("plan") )
                    printPlan = true ;
                if ( v.equalsIgnoreCase("query") )
                    printParseTree = true ;
            }
        }

        if ( cl.contains(baseDecl) )
        {
            qCmd.setBaseURI(cl.getValue(baseDecl)) ;
            RelURI.setBaseURI(qCmd.getBaseURI()) ;
        }

        if ( cl.contains(quietDecl) )
            printQueryOut = false ;
        
        //if ( cl.contains(debugDecl) )

        // Input syntax
        if ( cl.contains(inDecl) )
        {
            Syntax syn = Syntax.lookup(cl.getValue(inDecl)) ;
            if ( syn == null )
            {
                msg("Unknown query syntax for input: "+cl.getArg(inDecl).getValue()) ;
                writeSyntaxes("Known syntaxes (not all implemented for both input and output)", System.err) ;
                throw new TerminateException(9) ;
            }
            qCmd.setInSyntax(syn) ;
        }
            
        // Output syntax
        if ( cl.contains(outDecl) )
        {
            Syntax syn = Syntax.lookup(cl.getValue(outDecl)) ;
            if ( syn == null )
            {
                msg("Unknown query syntax for output: "+cl.getArg(outDecl).getValue()) ;
                writeSyntaxes("Known syntaxes", System.err) ;
                throw new TerminateException(9) ;
            }
            qCmd.setOutSyntax(syn) ;
        }
        
        // Default
        qCmd.setLineNumbers(true) ;
        
        if ( cl.contains(numDecl) )
        {
            boolean b = cl.getValue(numDecl).equalsIgnoreCase("yes") ; 
            qCmd.setLineNumbers(b) ;
        }
        
        if ( cl.contains(plainDecl) )
            FmtElementARQ.PRETTY_PRINT = false ;
        
        if ( cl.contains(plainDecl) ) 
            qCmd.setLineNumbers(false) ;
        
        if ( cl.contains(parseOnlyDecl) )
        {
            printQueryOut = false ;
            checkParsing = false ;
        }
         
        // Query to translate
        
        if ( cl.contains(fileDecl) )
        {
            if ( cl.hasPositional() )
            {
                System.err.println("file argument and command line item") ;
                throw new TerminateException(9) ;
            }
            qCmd.setQueryFilename(cl.getValue(fileDecl)) ;
        }
        else
        {
            if ( ! cl.hasPositional() )
            {
                // Neither - read stdin
                try {
                    qCmd.setQueryString(FileUtils.readWholeFileAsUTF8(System.in)) ;
                } catch (IOException ex)
                {
                    System.err.println(ex.getMessage()) ;
                    ex.printStackTrace(System.err) ;
                }
            }
            else
            {
                if ( cl.hasPositional() && cl.getNumPositional() != 1 )
                {
                    System.err.println("Too many command line items") ;
                    throw new TerminateException(9) ;
                }
                
                // One positional argument.
                
                String qs = cl.getPositionalArg(0) ;
                if ( cl.matchesIndirect(qs) ) 
                    qCmd.setSyntaxHint(qs) ;
                
                qs = cl.indirect(qs) ;
                qCmd.setQueryString(qs) ;
            }
        }
        
        if (  qCmd.getOutSyntax() == null )
            qCmd.setOutSyntax(Syntax.syntaxSPARQL) ;
        
        process(qCmd, printQueryOut, printParseTree, printPlan, checkParsing) ;
    }
    
    static void process(QCmd qCmd, boolean printQueryOut, boolean printParseTree, boolean printPlan, boolean checkParsing)
    {
        qCmd.parseQuery() ;
        if ( qCmd.getQuery() == null )
            return ;
        
        if ( printParseTree )
        {
            qCmd.getQuery().serialize(System.out, Syntax.syntaxPrefix) ;
            System.out.println() ;
        }
        
        if ( printPlan )
        {
            // Force planning
            PlanElement plan = QueryUtils.generatePlan(qCmd.getQuery()) ;
            PlanFormatter.out(System.out, qCmd.getQuery(), plan) ;
            System.out.println() ;
        }
        
        if ( printQueryOut )
            qCmd.printQuery() ;
        
        if ( checkParsing )
            qCmd.checkParse() ;
    }
    
    static void writeSyntaxes(String msg, PrintStream out)
    {
        if ( msg != null )
            out.println(msg) ;
        for ( Iterator iter = Syntax.querySyntaxNames.keys() ; iter.hasNext() ; )
        {
            String k = (String)(iter.next()) ;
            Syntax v = Syntax.lookup(k) ;
            k = padOut(k,10) ;
            out.println("  "+k+"  "+v) ;
        }
    }
    
    static void msg(String msg)
    {
        System.err.println(msg) ;
    }

    // printf ... java 1.5 .. mutter,mutter
    static String padOut(String x, int len)
    {
        StringBuffer r = new StringBuffer(x) ;
        for ( int i = x.length() ; i <= len ; i++ )
            r.append(" ") ;
        return r.toString() ; 
    }
    
    static void usage() { msg(usage) ; }
    
    static void usage(java.io.PrintStream out)
    {
        out.println(usage) ;
        
    }
 }

/*
 *  (c) Copyright 2004, 2005, 2006 Hewlett-Packard Development Company, LP
 *  All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in the
 *    documentation and/or other materials provided with the distribution.
 * 3. The name of the author may not be used to endorse or promote products
 *    derived from this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE AUTHOR ``AS IS'' AND ANY EXPRESS OR
 * IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES
 * OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED.
 * IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR ANY DIRECT, INDIRECT,
 * INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT
 * NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
 * DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
 * THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
 * (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF
 * THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */
