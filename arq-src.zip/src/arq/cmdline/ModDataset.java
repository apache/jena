/*
 * (c) Copyright 2006 Hewlett-Packard Development Company, LP
 * All rights reserved.
 * [See end of file]
 */

package arq.cmdline;

import java.util.List;

import com.hp.hpl.jena.query.DataFormat;
import com.hp.hpl.jena.query.Dataset;
import com.hp.hpl.jena.query.DatasetFactory;
import com.hp.hpl.jena.shared.JenaException;
import com.hp.hpl.jena.util.FileManager;
import com.hp.hpl.jena.util.LocationMapper;

import arq.cmd.CmdException;
import arq.cmd.TerminationException;

public class ModDataset implements ArgModule
{
    protected final ArgDecl graphDecl      = new ArgDecl(ArgDecl.HasValue, "graph", "data") ;
    protected final ArgDecl namedGraphDecl = new ArgDecl(ArgDecl.HasValue, "named", "namedgraph", "namedGraph") ;
    //protected final ArgDecl dataFmtDecl    = new ArgDecl(ArgDecl.HasValue, "fmt", "format") ;
    //protected final ArgDecl dirDecl        = new ArgDecl(ArgDecl.HasValue, "dir") ;
    protected final ArgDecl lmapDecl       = new ArgDecl(ArgDecl.HasValue, "lmap") ;
 
    protected final ArgDecl datasetDecl    = new ArgDecl(ArgDecl.HasValue, "desc", "dataset") ;
    
    private List graphURLs               = null ;
    private List namedGraphURLs          = null ;
    private DataFormat dataSyntax        = null ;
    private Dataset dataset = null ;
    private FileManager fileManager     = FileManager.get() ;    

    public void registerWith(CmdArgModule cl)
    {
        cl.add(graphDecl,
               "--graph",
               "Graph for default graph of the datset") ;
        cl.add(namedGraphDecl,
               "--namedGraph",
               "Add a graph into the dataset as a named graph") ;
        //cl.add(dirDecl) ;
        //cl.add(dataFmtDecl) ;
        cl.add(lmapDecl,
               "--lmap",
               "Specify a location mapping file") ;
        cl.add(datasetDecl) ;
    }
    
    public void processArgs(CmdArgModule cmdLine)
    {
        graphURLs = cmdLine.getValues(graphDecl) ;
        namedGraphURLs = cmdLine.getValues(namedGraphDecl) ;
        
        if ( cmdLine.contains(lmapDecl) )
        {
            String lmapFile = cmdLine.getValue(lmapDecl) ;
            LocationMapper locMap = new LocationMapper(lmapFile) ;
            fileManager = new FileManager(locMap) ;
        }
        
        if ( cmdLine.contains(datasetDecl))
        {
            // TODO Assemblers for datasets
            System.err.println("No timplemented : assember dataset") ;
            throw new TerminationException(67) ;
        }
    }
    
    public Dataset getDataset()
    {
        if ( dataset != null )
            return dataset ;
        try {
            if ( (graphURLs != null) || (namedGraphURLs != null) )
                dataset = 
                    DatasetFactory.create(graphURLs, namedGraphURLs, fileManager, null) ;
        } 
        catch (JenaException ex)
        { throw ex ; }
        catch (Exception ex)
        { throw new CmdException("Error creating dataset", ex) ; }
        return dataset ;
    }

    public List getGraphURLs()
    {
        return graphURLs ;
    }

    public List getNamedGraphURLs()
    {
        return namedGraphURLs ;
    }
}


/*
 * (c) Copyright 2006 Hewlett-Packard Development Company, LP
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in the
 *    documentation and/or other materials provided with the distribution.
 * 3. The name of the author may not be used to endorse or promote products
 *    derived from this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE AUTHOR ``AS IS'' AND ANY EXPRESS OR
 * IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES
 * OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED.
 * IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR ANY DIRECT, INDIRECT,
 * INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT
 * NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
 * DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
 * THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
 * (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF
 * THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */