/*
 * (c) Copyright 2006 Hewlett-Packard Development Company, LP
 * All rights reserved.
 * [See end of file]
 */

package arq.cmdline;

import java.io.PrintStream;
import java.util.ArrayList;
import java.util.List;

import arq.cmd.CmdUtils;

import com.hp.hpl.jena.query.util.IndentedWriter;

// Added usage + some common flags
// This is the usual starting point for any sub 

public abstract class CmdGeneral extends CmdArgModule
{
    static { CmdUtils.setLog4j() ; CmdUtils.setN3Params() ; } 
   
    ModGeneral modGeneral = new ModGeneral() ;
    
    // Could be turned into a module but these are convenient as inherited flags
    // ModGeneral.
    // Which can set the globals here.
    
    // Also for things that just happen (--help, --version)
    private final ArgDecl argDeclHelp        = new ArgDecl(false, "help", "h");
    private final ArgDecl argDeclVersion     = new ArgDecl(false, "version");

    private final ArgDecl argDeclVerbose     = new ArgDecl(false, "v", "verbose");
    private final ArgDecl argDeclQuiet       = new ArgDecl(false, "q", "quiet");
    private final ArgDecl argDeclDebug       = new ArgDecl(false, "debug");

    protected CmdGeneral(String[] argv)
    {
        super(argv) ;
        addModule(modGeneral) ;
    }

    public void addModule(ArgModuleGeneral argModule)
    {
        super.addModule(argModule) ;
        argModule.registerWith(this) ;
    }
    
    protected boolean isVerbose() { return modGeneral.verbose ; }
    protected boolean isQuiet()   { return modGeneral.quiet ; }
    protected boolean isDebug()   { return modGeneral.debug ; }

    private Usage usage = new Usage() ; 
    private List argName = new ArrayList() ;
    private List argText = new ArrayList() ;
    
    protected String cmdName = null ;

//    protected CmdGeneral(String argv[])
//    {
//        // See also ModGeneral - better that way if it can be last help category
//        super(argv) ;
//        add(argDeclVerbose) ;
//        add(argDeclQuiet) ;
//        add(argDeclDebug) ;
//        add(argDeclHelp) ;
//        add(argDeclVersion) ;
//        
//        usage.startCategory("General") ;
//        usage.addUsage("--help",              null) ;
//        usage.addUsage("-v   --verbose",      "Verbose") ;
//        usage.addUsage("--debug",             "Output information for debugging") ;
//        usage.addUsage("-q   --quiet",        "Run with minimal output") ;
//        usage.addUsage("--version",           "Print version information") ;
//    }
//    
//    //@Override 
//    public void process()
//    {
//        try {
//            super.process();
//        } catch (IllegalArgumentException ex)
//        {
//            System.err.println(ex.getMessage()) ;
//            usage.output(System.err) ;
//            throw new TerminationException(1) ;
//        }
//        
//        if ( contains(argDeclHelp) )
//        {
//            usage(System.err) ;
//            throw new TerminationException(0) ;
//        }
//        
//        if ( contains(argDeclVersion) )
//        {
//            List items = new ArrayList() ;
//            version(items) ;
//            String s = StringUtils.join(" ", items);
//            System.out.println(s) ; 
//            throw new TerminationException(0) ;
//        }
//        
//        verbose = contains(argDeclVerbose) ;
//        quiet = contains(argDeclQuiet) ;
//        debug = contains(argDeclDebug) ;
//        if ( debug )
//            verbose = true ;
//    }

    protected abstract String getSummary() ;

    public void usage() { usage(System.err) ; }

    public void usage(PrintStream pStr)
    {
        IndentedWriter out = new IndentedWriter(pStr) ;
        out.println(getSummary()) ;
        usage.output(out) ;
    }
    
    public void add(ArgDecl argDecl, String argName, String msg)
    {
        add(argDecl) ;
        getUsage().addUsage(argName, msg) ;
    }

    public Usage getUsage() { return usage ; }
}

/*
 * (c) Copyright 2006 Hewlett-Packard Development Company, LP
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in the
 *    documentation and/or other materials provided with the distribution.
 * 3. The name of the author may not be used to endorse or promote products
 *    derived from this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE AUTHOR ``AS IS'' AND ANY EXPRESS OR
 * IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES
 * OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED.
 * IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR ANY DIRECT, INDIRECT,
 * INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT
 * NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
 * DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
 * THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
 * (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF
 * THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */