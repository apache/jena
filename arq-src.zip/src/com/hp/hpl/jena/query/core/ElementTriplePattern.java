/*
 * (c) Copyright 2004, 2005, 2006 Hewlett-Packard Development Company, LP
 * All rights reserved.
 * [See end of file]
 */

package com.hp.hpl.jena.query.core;


import com.hp.hpl.jena.graph.* ;

/** 
 * @author Andy Seaborne
 * @version $Id: ElementTriplePattern.java,v 1.18 2006/07/23 19:26:54 andy_seaborne Exp $
 */

public class ElementTriplePattern extends Element
{
    Triple triple = null ;

    //public ElementTriplePattern() { }
    public ElementTriplePattern(Triple t) { triple = t ; }
    
    public void setTriple(Triple t) { triple = t ; }
    
    public Triple getTriple() { return triple ; }

    //@Override
    public int hashCode() { return triple == null ? 2 : triple.hashCode() ; }

    //@Override
    public boolean equals(Object el2)
    {
        if ( el2 == null ) return false ;

        if ( ! ( el2 instanceof ElementTriplePattern ) )
            return false ;
        ElementTriplePattern tp2 = (ElementTriplePattern)el2 ;
        
//        Node s1 = this.getTriple().getSubject() ;
//        Node p1 = this.getTriple().getPredicate() ;
//        Node o1 = this.getTriple().getObject() ;
//        
//        Node s2 = tp2.getTriple().getSubject() ;
//        Node p2 = tp2.getTriple().getPredicate() ;
//        Node o2 = tp2.getTriple().getObject() ;
//        
//        if ( ! s1.equals(s2) )
//            return false ;
//        if ( ! p1.equals(p2) )
//            return false ;
//        if ( ! o1.equals(o2) )
//            return false ;

        if ( ! this.getTriple().equals(tp2.getTriple()) )
            return false ;
        return true ;
    }
    
    public void visit(ElementVisitor v) { v.visit(this) ; }
 }

/*
 * (c) Copyright 2004, 2005, 2006 Hewlett-Packard Development Company, LP
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in the
 *    documentation and/or other materials provided with the distribution.
 * 3. The name of the author may not be used to endorse or promote products
 *    derived from this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE AUTHOR ``AS IS'' AND ANY EXPRESS OR
 * IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES
 * OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED.
 * IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR ANY DIRECT, INDIRECT,
 * INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT
 * NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
 * DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
 * THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
 * (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF
 * THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */