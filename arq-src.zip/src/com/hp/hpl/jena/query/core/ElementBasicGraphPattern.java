/*
 * (c) Copyright 2004, 2005, 2006 Hewlett-Packard Development Company, LP
 * All rights reserved.
 * [See end of file]
 */

package com.hp.hpl.jena.query.core;

import java.util.* ;

import org.apache.commons.logging.LogFactory;

import com.hp.hpl.jena.graph.Triple;
import com.hp.hpl.jena.query.expr.Expr;

/** A SPARQL FilteredBasicGraphPattern
 * 
 * @author Andy Seaborne
 * @version $Id: ElementBasicGraphPattern.java,v 1.7 2006/10/11 14:45:30 andy_seaborne Exp $
 */

public class ElementBasicGraphPattern extends Element implements TripleCollector
{
    // This is quite like ElementGroup but to reduce the chances of programmatically
    // building queries that have no syntactic form, there are methods for the specific
    // operations allowed on a basic graph pattern.
    // Likewise: ElementGroup has converter functions to ensure there is an
    // ElementBasicGraphPattern.  By not using the same names for methods, it should be clearer
    // to an application that converters are being used. 
    
    List elements = new ArrayList() ;

    public ElementBasicGraphPattern()
    {  }

    public boolean isEmpty() { return elements.size() == 0 ; }
    
    public void addTriple(Triple t)                  { addElement(new ElementTriplePattern(t)) ; }
    public void addConstraint(Expr expr)             
    { 
        LogFactory.getLog(ElementBasicGraphPattern.class).warn("addConstraint called") ;
        addElement(new ElementFilter(expr)) ; 
    }
    
    public void addElement(ElementFilter f)          { elements.add(f) ; }
    public void addElement(ElementTriplePattern tp)  { elements.add(tp) ; }
    
    public int mark() { return elements.size() ; }
    public void addTriple(int index, Triple t)
    { elements.add(index, new ElementTriplePattern(t)) ; }
    
    public List getElements() { return elements; }

    //@Override
    public int hashCode()
    { 
        int calcHashCode = Element.HashGroup ; // So the empty group isn't zero.
        calcHashCode ^=  getElements().hashCode() ; 
        return calcHashCode ;
    }

    //@Override
    public boolean equals(Object el2)
    {
        if ( el2 == null ) return false ;

        if ( ! ( el2 instanceof ElementBasicGraphPattern) )
            return false ;
        
        ElementBasicGraphPattern eg2 = (ElementBasicGraphPattern)el2 ;
        if ( this.getElements().size() != eg2.getElements().size() )
            return false ;
        for ( int i = 0 ; i < this.getElements().size() ; i++ )
        {
            Element e1 = (Element)getElements().get(i) ;
            Element e2 = (Element)eg2.getElements().get(i) ;
            if ( ! e1.equals(e2) )
                return false ;
        }
        return true ;
    }

    public void visit(ElementVisitor v) { v.visit(this) ; }
}

/*
 * (c) Copyright 2006 Hewlett-Packard Development Company, LP
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in the
 *    documentation and/or other materials provided with the distribution.
 * 3. The name of the author may not be used to endorse or promote products
 *    derived from this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE AUTHOR ``AS IS'' AND ANY EXPRESS OR
 * IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES
 * OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED.
 * IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR ANY DIRECT, INDIRECT,
 * INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT
 * NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
 * DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
 * THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
 * (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF
 * THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */