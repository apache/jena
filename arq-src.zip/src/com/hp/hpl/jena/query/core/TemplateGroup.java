/*
 * (c) Copyright 2005, 2006 Hewlett-Packard Development Company, LP
 * All rights reserved.
 * [See end of file]
 */

package com.hp.hpl.jena.query.core;

import java.util.*;

import com.hp.hpl.jena.graph.Triple;
import com.hp.hpl.jena.query.engine.Binding;

/** A number of templates, grouped together.
 *  Kept as a list so printing maintains order.
 * @author Andy Seaborne
 * @version $Id: TemplateGroup.java,v 1.14 2006/12/11 21:57:45 andy_seaborne Exp $
 */

public class TemplateGroup extends Template implements TripleCollector
{
    List templates = new ArrayList() ;
    
    public TemplateGroup()
    {
    }
    
    public void add(Template templ)
    {
        templates.add(templ) ;
    }
    
    public void addTriple(Triple t) { templates.add(new TemplateTriple(t)) ; }
    public int mark() { return templates.size() ; }
    public void addTriple(int index, Triple t)
    { templates.add(index, new TemplateTriple(t)) ; }

    public List getTemplates() { return templates ; }
    public Iterator templates() { return templates.iterator() ; }
    
    public void subst(Collection s, Map bNodeMap, Binding b)
    {
        for ( Iterator iter = templates.iterator() ; iter.hasNext() ; )
        {
            Template t = (Template)iter.next() ;
            t.subst(s, bNodeMap, b) ;
        }
    }

    private int calcHashCode = -1 ;  
    //@Override
    public int hashCode()
    { 
        int calcHashCode = Template.HashTemplateGroup ;
        calcHashCode ^=  getTemplates().hashCode() ; 
        return calcHashCode ;
    }

    //@Override
    public boolean equalTo(Object temp2, LabelMap labelMap)
    {
        if ( temp2 == null ) return false ;

        if ( ! ( temp2 instanceof TemplateGroup) )
            return false ;
        TemplateGroup tg2 = (TemplateGroup)temp2 ;
        if ( this.getTemplates().size() != tg2.getTemplates().size() )
            return false ;
        for ( int i = 0 ; i < this.getTemplates().size() ; i++ )
        {
            Template t1 = (Template)getTemplates().get(i) ;
            Template t2 = (Template)tg2.getTemplates().get(i) ;
            if ( ! t1.equalTo(t2, labelMap) )
                return false ;
        }
        return true ;
    }
    
    public void visit(TemplateVisitor visitor)
    {
        visitor.visit(this) ;
    }
}

/*
 * (c) Copyright 2005, 2006 Hewlett-Packard Development Company, LP
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in the
 *    documentation and/or other materials provided with the distribution.
 * 3. The name of the author may not be used to endorse or promote products
 *    derived from this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE AUTHOR ``AS IS'' AND ANY EXPRESS OR
 * IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES
 * OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED.
 * IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR ANY DIRECT, INDIRECT,
 * INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT
 * NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
 * DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
 * THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
 * (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF
 * THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */