/*
 * (c) Copyright 2005, 2006 Hewlett-Packard Development Company, LP
 * All rights reserved.
 * [See end of file]
 */

package com.hp.hpl.jena.query.core;

import java.util.Collection;
import java.util.Map;

import com.hp.hpl.jena.graph.* ;
import com.hp.hpl.jena.query.engine1.QueryEngineUtils;

/** A single triple template.
 *  bNodes are "magic" in that they are duplicated on substitution.  
 * 
 * @author Andy Seaborne
 * @version $Id: TemplateTriple.java,v 1.11 2005/12/26 20:08:19 andy_seaborne Exp $
 */

public class TemplateTriple extends Template
{
    Triple triple ;
    
    public TemplateTriple(Node s, Node p, Node o)
    {
        triple = new Triple(s, p ,o) ;
    }
    
    public TemplateTriple(Triple t)
    {
        triple = t ;
    }
    
    public Triple getTriple() { return triple ; } 
    
    public void subst(Collection acc, Map bNodeMap, Binding b)
    {
        Node s = triple.getSubject() ; 
        Node p = triple.getPredicate() ;
        Node o = triple.getObject() ;
        
        if ( s.isBlank() )
            s = newBlank(s, bNodeMap) ;

        if ( p.isBlank() )
            p = newBlank(p, bNodeMap) ;

        if ( o.isBlank() )
            o = newBlank(o, bNodeMap) ;

        Triple t = new Triple(s, p, o) ; 
        Triple t2 = QueryEngineUtils.substituteIntoTriple(t, b) ;
        acc.add(t2) ;
    }
    
    //@Override
    public int hashCode() { return triple.hashCode() ; }

    //@Override
    public boolean equals(Object temp2)
    {
        if ( temp2 == null ) return false ;

        if ( ! ( temp2 instanceof TemplateTriple) )
            return false ;
        TemplateTriple tt2 = (TemplateTriple)temp2 ;
        if  ( ! this.getTriple().equals(tt2.getTriple() ))
            return false ;
        return true ;
    }
    
    public void visit(TemplateVisitor visitor)
    {
        visitor.visit(this) ;
    }
    
    private Node newBlank(Node n, Map bNodeMap)
    {
        if ( ! bNodeMap.containsKey(n) ) 
            bNodeMap.put(n, Node.createAnon() );
        return (Node)bNodeMap.get(n) ;
    }
}

/*
 * (c) Copyright 2005, 2006 Hewlett-Packard Development Company, LP
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in the
 *    documentation and/or other materials provided with the distribution.
 * 3. The name of the author may not be used to endorse or promote products
 *    derived from this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE AUTHOR ``AS IS'' AND ANY EXPRESS OR
 * IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES
 * OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED.
 * IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR ANY DIRECT, INDIRECT,
 * INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT
 * NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
 * DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
 * THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
 * (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF
 * THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */