/*
 * (c) Copyright 2005, 2006 Hewlett-Packard Development Company, LP
 * [See end of file]
 */

package com.hp.hpl.jena.query.util;

import java.io.Reader;
import java.io.StringReader;
import java.util.Iterator;
import java.util.List;

import com.hp.hpl.jena.graph.Node;
import com.hp.hpl.jena.query.Constants;
import com.hp.hpl.jena.query.Query;
import com.hp.hpl.jena.query.QueryFactory;
import com.hp.hpl.jena.query.QueryParseException;
import com.hp.hpl.jena.query.expr.*;
import com.hp.hpl.jena.query.lang.sparql.*;

/** Misc support for Expr
 * @author Andy Seaborne
 * @version $Id: ExprUtils.java,v 1.15 2006/03/28 17:16:38 andy_seaborne Exp $
 */

public class ExprUtils
{
    public static Expr nodeToExpr(Node n)
    {
        if ( n.isVariable() )
            return new NodeVar(n) ;
        return NodeValue.makeNode(n) ;
    }
    
    public static String joinList(List args, String sep)
    {
        if ( args == null )
            return "<<Null list>>" ;
        
        if ( args.size() == 0 )
            return "<<Empty list>>" ;
        
        StringBuffer s = new StringBuffer() ;
        
        boolean first = true ;

        for ( Iterator iter = args.listIterator() ; iter.hasNext() ; )
        {
            if ( ! first )
                s.append(sep) ;
            Expr ex = (Expr)iter.next() ;
            
            // Values are printed withquoting.
            if ( ex instanceof NodeValue )
            {
                NodeValue nv =(NodeValue)ex ;
                s.append(nv.asQuotedString()) ;
            }
            else
                s.append(ex.toString()) ;
            first = false ;
        }
        return s.toString() ;
    }
    
    public static Expr parseExpr(String s)
    { 
        Query query = QueryFactory.make() ;
        query.setPrefixMapping(Constants.getGlobalPrefixMap()) ;
        return parseExpr(query, s, true) ; }

    public static Expr parseExpr(Query query, String s, boolean checkAllUsed)
    {
        try {
            Reader in = new StringReader(s) ;
            SPARQLParser parser = new SPARQLParser(in) ;
            parser.setQuery(query) ;
            Expr expr = parser.Expression() ;
            
            if ( checkAllUsed )
            {
                Token t = parser.getNextToken() ;
                if ( t.kind != SPARQLParserTokenManager.EOF )
                    throw new QueryParseException("Extra tokens beginning \""+t.image+"\" starting line "+t.beginLine+", column "+t.beginColumn,
                                                  t.beginLine, t.beginColumn) ;
            }
            return expr ;
        } catch (ParseException ex)
        { throw new QueryParseException(ex.getMessage(),
                                        ex.currentToken.beginLine,
                                        ex.currentToken.beginLine) ;
        }
        catch (TokenMgrError tErr)
        {
            throw new QueryParseException(tErr.getMessage(), -1, -1) ;
        }
        catch (Error err)
        {
            // The token stream can throw java.lang.Error's 
            String tmp = err.getMessage() ;
            if ( tmp == null )
                throw new QueryParseException(err,-1, -1) ;
            throw new QueryParseException(tmp,-1, -1) ;
        }
    }

    public static NodeValue parseNodeValue(String s)
    {
        try {
            Query query = QueryFactory.make() ;
            query.setPrefixMapping(Constants.getGlobalPrefixMap()) ;
            Reader in = new StringReader(s) ;
            SPARQLParser parser = new SPARQLParser(in) ;
            parser.setQuery(query) ;
            Node n = parser.GraphTerm() ;
            // Check we consumed the whole string.
            Token t = parser.getNextToken() ;
            if ( t.kind != SPARQLParserTokenManager.EOF )
                throw makeException("Extra tokens beginning \""+t.image+"\" starting line "+t.beginLine+", column "+t.beginColumn, t.beginLine, t.beginColumn) ;
            NodeValue nv = NodeValue.makeNode(n) ;
            return nv ;
        } catch (ParseException ex)
        { throw new QueryParseException(ex.getMessage(), ex.currentToken.beginLine, ex.currentToken.beginColumn) ; }
    }
    
    private static QueryParseException makeException(String msg, int line, int column)
    {
        return new QueryParseException(msg, line, column) ;
    }
    
    // Need a "clone"-with-expections mechanism
//    /** Substitute variable values for variables but leave the rest of the expression alone. */
//    // Use a special print visitor to do subtitute vars for values, reparse, evaluate.      
//    public static Expr subst(Expr expr)
//    {   
//        try {
//            // Crude duplicate - print , parse.
//            Expr expr2 = parseExpr(expr.toString()) ;
//            
//        } catch (ParseException ex)
//        {
//            LogFactory.getLog(ExprUtils.class).warn("Failed to duplicate expression") ;
//            return null ;
//        }
//         
//        return null ;
//    }

}

/*
 *  (c) Copyright 2005, 2006 Hewlett-Packard Development Company, LP
 *  All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in the
 *    documentation and/or other materials provided with the distribution.
 * 3. The name of the author may not be used to endorse or promote products
 *    derived from this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE AUTHOR ``AS IS'' AND ANY EXPRESS OR
 * IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES
 * OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED.
 * IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR ANY DIRECT, INDIRECT,
 * INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT
 * NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
 * DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
 * THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
 * (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF
 * THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */
