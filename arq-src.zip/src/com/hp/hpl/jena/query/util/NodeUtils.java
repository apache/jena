/*
 * (c) Copyright 2005, 2006 Hewlett-Packard Development Company, LP
 * All rights reserved.
 * [See end of file]
 */

package com.hp.hpl.jena.query.util;

import com.hp.hpl.jena.graph.Node;
import com.hp.hpl.jena.query.Constants;
import com.hp.hpl.jena.query.QueryException;
import com.hp.hpl.jena.query.core.ARQInternalErrorException;
import com.hp.hpl.jena.query.engine1.QueryEngineUtils;
import com.hp.hpl.jena.query.expr.Expr;
import com.hp.hpl.jena.query.expr.ExprEvalException;
import com.hp.hpl.jena.query.expr.ExprNotComparableException;
import com.hp.hpl.jena.query.expr.NodeValue;
import com.hp.hpl.jena.rdf.model.Model;
import com.hp.hpl.jena.rdf.model.RDFNode;
import com.hp.hpl.jena.rdf.model.impl.LiteralImpl;
import com.hp.hpl.jena.rdf.model.impl.ModelCom;
import com.hp.hpl.jena.rdf.model.impl.ResourceImpl;

/** Node utilities. 
 * @author Andy Seaborne
 * @version $Id: NodeUtils.java,v 1.14 2006/02/03 18:45:02 andy_seaborne Exp $
 */ 


public class NodeUtils
{
    public static boolean isBlankNodeVar(Node v)
    {
        if ( ! v.isVariable() )
            return false ;
        if ( v.getName().startsWith(Constants.anonVarMarker) )
            return true ; 
        return false ;
    }

    public static boolean isApplicationVar(Node v)
    {
        if ( ! v.isVariable() )
            return false ;
        if ( v.getName().startsWith(Constants.anonVarMarker) )
            return false ; 
        return true ;
    }

    
    /** Compare two Nodes based on the SPARQL comparison rules */ 
    public static int compareNodesByValue(Node node1, Node node2)
    {
        try {
            // TODO compare by value first?
            return compareNodesByKind(node1, node2) ;
        } catch (ExprNotComparableException ex) {}
        return compareLiteralsByValue(node1, node2) ;
    }
    
    /** Compare two Nodes, based on type and lexcial form, not value */
    public static int compareNodesByKindTypeLexical(Node node1, Node node2)
    {
        try {
            return compareNodesByKind(node1, node2) ;
        } catch (ExprNotComparableException ex) {}
        return compareLiteralsLexical(node1, node2) ;
    }
    
    /** Compare two Nodes based on the SPARQL comparison rules except for literals.*/
    private static int compareNodesByKind(Node node1, Node node2)
    {
        if ( node1 == null )
        {
            if ( node2 == null )
                return Expr.CMP_EQUAL ;
            return Expr.CMP_LESS ;
        }
        
        if ( node2 == null )
            return Expr.CMP_GREATER ;
        
        // No nulls.
        
        if ( node1.isBlank() )
        {
            if ( node2.isBlank() )
            {
                String s1 = node1.getBlankNodeId().getLabelString() ;
                String s2 = node2.getBlankNodeId().getLabelString() ;
                return StringUtils.strCompare(s1, s2) ;
                
                
            }
            // bNodes before anything else.
            return Expr.CMP_LESS ;
        }
            
        if ( node2.isBlank() )
            // Node1 not blank.
            return Expr.CMP_GREATER ; 
        
        // No blanks.
        
        if ( node1.isURI() )
        {
            if ( node2.isURI() )
            {
                String s1 = node1.getURI() ;
                String s2 = node2.getURI() ;
                return StringUtils.strCompare(s1, s2) ; 
            }
            return Expr.CMP_LESS ;
        }
        
        if ( node2.isURI() )
            return Expr.CMP_GREATER ;

        // No URIs by this point - literals only.
        
        if ( node1.isLiteral() && node2.isLiteral() )
            throw new ExprNotComparableException("Literals: "+node1+", "+node2);
        
        // Error.  Should not happen.
        //throw new QueryExecException("Compare: "+node1+"  "+node2) ;
        throw new ARQInternalErrorException("Compare: "+node1+"  "+node2) ;
    }
    
    private static int compareLiteralsByValue(Node node1, Node node2)
    {
        NodeValue nv1 = NodeValue.makeNode(node1) ;
        NodeValue nv2 = NodeValue.makeNode(node2) ;
        
        try {
            return NodeValue.compare(nv1, nv2) ;
        } catch (ExprEvalException ex)
        {
            // can't compare as types - try lexical forms.
            String lex1 = nv1.asString() ;
            String lex2 = nv2.asString() ;
            return StringUtils.strCompare(lex1, lex2) ; 
        }
    }
    
    // Compare by kind (URI, literal, bNode,) then lexical forms.  NOT by value. 
    private static int compareLiteralsLexical(Node node1, Node node2)
    {
        String lex1 = node1.getLiteralLexicalForm() ;
        String lex2 = node2.getLiteralLexicalForm() ;
    
        String dt1 = node1.getLiteralDatatypeURI() ;
        String dt2 = node2.getLiteralDatatypeURI() ;
    
        if ( dt1 == null && dt2 == null )
        {
            // Both plain literals
        }
        
        // If both have types and are the same ...
        if ( dt1 != null && dt2 != null && dt1.equals(dt2) )
            return StringUtils.strCompare(lex1, lex2) ; 
        
        // One plain literals
        if ( dt1 == null || dt2 == null )
        {
            int x = StringUtils.strCompare(lex1, lex2) ; 
            if ( x != Expr.CMP_EQUAL )
                return x ;
            // Same lexicial form, plain literals first.
            if ( dt1 == null )
                return Expr.CMP_LESS ;
            if ( dt2 == null )
                return Expr.CMP_GREATER ;
            throw new QueryException("Bug: one plain literal: "+node1+" and "+node2) ;
        }
            
        // No plain literals.
        int x = StringUtils.strCompare(lex1, lex2) ; 
        if ( x != Expr.CMP_EQUAL ) return x ;
        return StringUtils.strCompare(dt1, dt2) ;
    }
    
    public static RDFNode convertGraphNodeToRDFNode(Node n, Model model)
    {
        if ( n.isLiteral() )
            return new LiteralImpl(n, (ModelCom) model) ;
                
        if ( n.isURI() || n.isBlank() )
            return new ResourceImpl(n, (ModelCom) model) ;
                
        if ( n.isVariable() )
        {
            throw new QueryException("Variable unbound: "+n) ;
            //binding.add(name, n) ;
            //return null ;
        }
                
        QueryEngineUtils.log.warn("Unknown node type for node: "+n) ;
        return null ;
    }
    
}

/*
 * (c) Copyright 2005, 2006 Hewlett-Packard Development Company, LP
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in the
 *    documentation and/or other materials provided with the distribution.
 * 3. The name of the author may not be used to endorse or promote products
 *    derived from this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE AUTHOR ``AS IS'' AND ANY EXPRESS OR
 * IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES
 * OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED.
 * IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR ANY DIRECT, INDIRECT,
 * INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT
 * NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
 * DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
 * THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
 * (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF
 * THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */