/*
 * (c) Copyright 2005, 2006 Hewlett-Packard Development Company, LP
 * All rights reserved.
 * [See end of file]
 */

package com.hp.hpl.jena.query.util;

import java.util.*;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import com.hp.hpl.jena.graph.*;
import com.hp.hpl.jena.query.ARQ;
import com.hp.hpl.jena.rdf.model.Model;
import com.hp.hpl.jena.rdf.model.ModelFactory;
import com.hp.hpl.jena.util.iterator.ExtendedIterator;
import com.hp.hpl.jena.vocabulary.RDF;

/** Graph utilities. 
 * @author Andy Seaborne
 * @version $Id: GraphUtils.java,v 1.10 2006/06/04 19:32:39 andy_seaborne Exp $
 */ 

public class GraphUtils
{
    static Log log = LogFactory.getLog(GraphUtils.class) ;
    
    private static RefBoolean usePlainGraph = null ;
    static {
        usePlainGraph = new RefBoolean(ARQ.graphNoSameValueAs) ;
    }

    // These functions control creating models for datasets.
    
    // ---- Model
    
    public static Model makeDefaultModel()
    {
        return ModelFactory.createModelForGraph(makeDefaultGraph()) ;
    }

    public static Model makePlainModel()
    {
        return ModelFactory.createModelForGraph(makePlainGraph()) ;
    }

    
    public static Model makeJenaDefaultModel() { return ModelFactory.createDefaultModel() ; }
    
    // ---- Graph
    
    public static Graph makeDefaultGraph()
    { return usePlainGraph.getValue() ? makePlainGraph() : makeJenaDefaultGraph() ; }

    public static Graph makeJenaDefaultGraph() { return Factory.createDefaultGraph() ; }
    
    public static Graph makePlainGraph() { return new PlainGraphMem() ; } 
    
    // ------- List utilities
    
    static final Node CAR = RDF.first.asNode() ;
    static final Node CDR = RDF.rest.asNode() ;
    static final Node NIL = RDF.nil.asNode() ;
    static final Node BAG = RDF.Bag.asNode() ;
    static final Node ALT = RDF.Alt.asNode() ;
    static final Node SEQ = RDF.Seq.asNode() ;
    static final Node RDFtype = RDF.type.asNode() ;
    static final String membershipPattern = RDF.getURI()+"_\\d+" ;

    public static boolean isListMember(Graph graph, Node list, Node member)
    {  
        int i = listIndex("listMember", graph, list, member);
        return i >= 0 ;
    }

    public static int countListMember(Graph graph, Node list, Node member)
    {
        if ( graph == null )
        {
            log.warn("countListMember called with null graph") ;
            return 0 ;
        }
        if ( list == null )
        {
            log.warn("countListMember called with null list") ;
            return 0 ;
        }
        if ( member == null )
        {
            log.warn("countListMember called with null member") ;
            return 0 ;
        }
        
        return countListMember(graph, list, member, new HashSet(), 0) ;
        
    }

    // Consolidate with isListMember
    private static int countListMember(Graph graph, Node list, Node member, Collection visited, int count)
    {
        if ( list.equals(NIL) )
            return count ;
        if ( list.isLiteral() )
            return count ; 
        if ( graph.contains(list, CAR, member) )
            count++ ;
        // Find all the tails
        ExtendedIterator iter2 = graph.find(list, CDR, Node.ANY) ;

        int count2 = 0 ;
        for ( ; iter2.hasNext() ; )
        {
            Node x = ((Triple)iter2.next()).getObject() ;
            if ( visited.contains(x) )
            {
                log.warn("Circular list detected") ;
                return count ;
            }
            
            
            int c2 = countListMember(graph, x, member, visited, 0) ;
            count2 = count2 + c2 ;
        }
        iter2.close() ;
        return count+count2 ;
    }
    
    public static int listIndex(Graph graph, Node list, Node member)
    { return listIndex("listMember", graph, list, member) ; }
    
    
    public static int listIndex(String opName, Graph graph, Node list, Node member)
    {
        if ( graph == null )
        {
            log.warn(opName+" called with null graph") ;
            return -1 ;
        }
        if ( list == null )
        {
            log.warn(opName+" called with null list") ;
            return -2 ;
        }
        
        if ( list.isLiteral() )
            return -4 ; 
        
        if ( member == null )
        {
            log.warn(opName+" called with null member") ;
            return -3 ;
        }
        
        Set visited = new HashSet() ;
        int idx = listIndex(graph, list, member, visited, 0) ;
        return idx ;
    }

    private static int listIndex(Graph graph, Node list, Node member, Collection visited, int index)
    {
        // Allows for multiple CARs and CDRs.
        // This one location and recurses on the tail
        
        if ( list.equals(NIL) )
            return -1 ;
        
        if ( graph.contains(list, CAR, member) )
            return index ;

        visited.add(list) ;
        // Not this step.
        ExtendedIterator iter2 = graph.find(list, CDR, Node.ANY) ;
        index++ ;

        for ( ; iter2.hasNext() ; )
        {
            Node x = ((Triple)iter2.next()).getObject() ;
            if ( visited.contains(x) )
            {
                log.warn("Circular list detected") ;
                return -2 ;
            }
            
            int index2 = listIndex(graph, x, member, visited, index) ;
            if ( index2 > 0 )
                return index2 ;
        }
        iter2.close() ;
        return -1 ;
    }
    
    static public List listMembers(Graph graph, Node list)
    {
        if ( graph == null )
        {
            log.warn("isListMember called with null graph") ;
            return null ;
        }
        if ( list == null )
        {
            log.warn("isListMember called with null list") ;
            return null ;
        }

        List members = new ArrayList() ;
        Set visited = new HashSet() ;
        findMembers(graph, list, members, visited) ;
        return members ;
    }
        
    static private void findMembers(Graph graph, Node n, List members, Set visited)
    {
        visited.add(n) ;
        if ( n == null || n.isLiteral() )
            return ;
        
        // Allows for multiple CARs and CDRs.
        

        // No need for this - it will (probably) have no CAR or CDR or be weirdly formed.  
//        if ( n.equals(NIL) )
//            return ;
        
        // Get value(s).
        ExtendedIterator iter = graph.find(n, CAR, Node.ANY) ;
        for ( ; iter.hasNext() ; )
        {
            Node x = ((Triple)iter.next()).getObject() ;
            members.add(x) ;
        }
        iter.close() ;
        // Process rest of list
        ExtendedIterator iter2 = graph.find(n, CDR, Node.ANY) ;
        for ( ; iter2.hasNext() ; )
        {
            Node x = ((Triple)iter2.next()).getObject() ;
            if ( ! visited.contains(x) )
                findMembers(graph, x, members, visited) ;
            else
                log.warn("Circular list detected") ;
        }
        iter2.close() ;
    }
    
    // ------- Container utilities

    public static Collection containerMembers(Graph graph, Node container)
    { return containerMembers(graph, container, null) ; }
    
    public static Collection containerMembers(Graph graph, Node container, Node containerType)
    {
        if ( ! isContainer(graph, container, containerType) )
            return null ;
        
        ExtendedIterator iter = graph.find(container, Node.ANY, Node.ANY) ;
        List x = new ArrayList() ;
      
        try {
          for ( ; iter.hasNext() ; )
          {
              Triple t = (Triple)iter.next() ;
              String p = t.getPredicate().getURI() ;

              if ( p.matches(membershipPattern) )
                  x.add(t.getObject()) ;
          }
      } finally { iter.close() ; }
      return x ;
  }

    
    public static boolean isContainerMember(Graph graph, Node container, Node containerType, Node member)
    {
        return countContainerMember(graph, container, containerType, member, true) != 0 ;
    }
    
    public static int countContainerMember(Graph graph, Node container, Node containerType, Node member)
    {
        return countContainerMember(graph, container, containerType, member, false) ;
    }
    
    private static int countContainerMember(Graph graph, Node container, Node containerType, Node member, boolean stopEarly)
    {
        if ( graph == null )
        {
            log.warn("containerMember called with null graph") ;
            return 0 ;
        }
        
        if ( container == null )
        {
            log.warn("containerMember called with null list") ;
            return 0 ;
        }
        if ( member == null )
        {
            log.warn("containerMember called with null member") ;
            return 0 ;
        }
        
        if ( ! isContainer(graph, container, containerType) )
            return 0 ;
        
        int count = 0 ;
        ExtendedIterator iter = graph.find(container, Node.ANY, member) ;
        try {
            for ( ; iter.hasNext() ; )
            {
                Triple t = (Triple)iter.next() ;
                Node p = t.getPredicate() ;
                String u = p.getURI() ;
                
                if ( u.matches(membershipPattern) )
                {
                    count ++ ;
                    if ( stopEarly )
                        return count ;
                }
            }
        } finally { iter.close() ; }
        return count ;
    }
        
    public static boolean isContainer(Graph graph, Node container)
    { return isContainer(graph, container, null) ; }

    public static boolean isContainer(Graph graph, Node container, Node containerType)
    {
        if ( containerType == null )
            containerType = Node.ANY ;
        
        if ( container.isLiteral() )
            return false ;
        
        // Must have some type.
        return graph.contains(container, RDFtype, containerType) ; 
    }

}

/*
 * (c) Copyright 2005, 2006 Hewlett-Packard Development Company, LP
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in the
 *    documentation and/or other materials provided with the distribution.
 * 3. The name of the author may not be used to endorse or promote products
 *    derived from this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE AUTHOR ``AS IS'' AND ANY EXPRESS OR
 * IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES
 * OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED.
 * IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR ANY DIRECT, INDIRECT,
 * INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT
 * NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
 * DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
 * THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
 * (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF
 * THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */