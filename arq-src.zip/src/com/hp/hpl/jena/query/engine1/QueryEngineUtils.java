/*
 * (c) Copyright 2004, 2005, 2006 Hewlett-Packard Development Company, LP
 * [See end of file]
 */

package com.hp.hpl.jena.query.engine1;
import java.util.Iterator;
import java.util.List;
import java.util.Set;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import com.hp.hpl.jena.graph.Node;
import com.hp.hpl.jena.graph.Triple;
import com.hp.hpl.jena.query.QuerySolution;
import com.hp.hpl.jena.query.core.Var;
import com.hp.hpl.jena.query.engine.Binding;
import com.hp.hpl.jena.query.engine.BindingMap;
import com.hp.hpl.jena.query.util.NodeUtils;
import com.hp.hpl.jena.rdf.model.*;

/**
 * @author     Andy Seaborne
 * @version    $Id: QueryEngineUtils.java,v 1.11 2006/12/11 21:57:59 andy_seaborne Exp $
 */
 
public class QueryEngineUtils
{
    public static Log log = LogFactory.getLog(QueryEngineUtils.class) ;
  
    public static void compilePattern(com.hp.hpl.jena.graph.query.Query graphQuery,
                               List pattern, Binding presets, Set vars)
    {
        if ( pattern == null )
            return ;
        for (Iterator iter = pattern.listIterator(); iter.hasNext();)
        {
            Triple t = (Triple) iter.next();
            t = substituteIntoTriple(t, presets) ;
            if ( vars != null )
            {
                if ( t.getSubject().isVariable() )
                    vars.add(t.getSubject()) ;
                if ( t.getPredicate().isVariable() )
                    vars.add(t.getPredicate()) ;
                if ( t.getObject().isVariable() )
                    vars.add(t.getObject()) ;
            }
            graphQuery.addMatch(t);
        }
    }
    
    public static void compileConstraints(com.hp.hpl.jena.graph.query.Query graphQuery, List constraints)
    {
        log.warn("Call to compileConstraints for Jena Expressions") ;
    }

    public static Triple substituteIntoTriple(Triple t, Binding binding)
    {
        Node subject = substituteNode(t.getSubject(), binding) ;
        Node predicate = substituteNode(t.getPredicate(), binding) ;
        Node object = substituteNode(t.getObject(), binding) ;
        
        if ( subject == t.getSubject() &&
             predicate == t.getPredicate() &&
             object == t.getObject() )
             return t ;
             
        return new Triple(subject, predicate, object) ;
    }
    
    public static Node substituteNode(Node n, Binding binding)
    {
        if ( ! n.isVariable() )
            return n ;

        if ( ! (n instanceof Var) )
            log.fatal("Node_Variable, not a Var") ; 
        
        //String name = ((Node_Variable)n).getName() ;
        String name = n.getName() ;
        Object obj = null ;
        
        if ( binding != null )
            obj = binding.get(name) ;
        
        if ( obj == null )
            return n ;
            
        if ( obj instanceof Node )
            return (Node)obj ;

        log.warn("Unknown object in binding: ignored: "+obj.getClass().getName()) ;        
        return n ;
    }
    
    
    public static Node[] projectionVars(Set vars)
    {
        Node[] result = new Node[vars.size()] ;
    
        int i = 0 ; 
        for ( Iterator iter = vars.iterator() ; iter.hasNext() ; )
        {
            Node n = (Node)iter.next() ;
            result[i] = n ;
            i++ ;
        }
        return result ;
    }
            
    public static Statement tripleToStatement(Model model, Triple t)
    {
        Node sNode = t.getSubject() ;
        Node pNode = t.getPredicate() ;
        Node oNode = t.getObject() ;
        
        if ( sNode.isLiteral() || sNode.isVariable() )
            return null ;
        
        if ( ! pNode.isURI() )
            return null ;
        
        if ( oNode.isVariable() )
            return null ;
        
        RDFNode s = NodeUtils.convertGraphNodeToRDFNode(sNode, model) ;
        RDFNode p = NodeUtils.convertGraphNodeToRDFNode(pNode, model) ;
        if ( p instanceof Resource )
            p = model.createProperty(((Resource)p).getURI()) ;
        RDFNode o = NodeUtils.convertGraphNodeToRDFNode(oNode, model) ;
        
        Statement stmt = model.createStatement((Resource)s, (Property)p, o) ;
        return stmt ;
    }
    
    public static Binding asBinding(QuerySolution qSolution)
    {
        Binding binding = new BindingMap(null) ;
        addToBinding(binding, qSolution) ;
        return binding ;
    }
        
    public static void addToBinding(Binding binding, QuerySolution qSolution)
    {        
        for ( Iterator iter = qSolution.varNames() ; iter.hasNext() ; )
        {
            String n = (String)iter.next() ;
            RDFNode x = qSolution.get(n) ;
            binding.add(n, x.asNode()) ;
        }
    }


}

/*
 *  (c) Copyright 2004, 2005, 2006 Hewlett-Packard Development Company, LP
 *  All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in the
 *    documentation and/or other materials provided with the distribution.
 * 3. The name of the author may not be used to endorse or promote products
 *    derived from this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE AUTHOR ``AS IS'' AND ANY EXPRESS OR
 * IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES
 * OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED.
 * IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR ANY DIRECT, INDIRECT,
 * INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT
 * NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
 * DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
 * THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
 * (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF
 * THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */
