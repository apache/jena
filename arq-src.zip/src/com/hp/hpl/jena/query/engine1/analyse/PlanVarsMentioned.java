/*
 * (c) Copyright 2005, 2006 Hewlett-Packard Development Company, LP
 * All rights reserved.
 * [See end of file]
 */

package com.hp.hpl.jena.query.engine1.analyse;

import java.util.HashSet;
import java.util.Iterator;
import java.util.Set;

import com.hp.hpl.jena.graph.Node;
import com.hp.hpl.jena.graph.Triple;
import com.hp.hpl.jena.query.engine1.PlanElement;
import com.hp.hpl.jena.query.engine1.PlanVisitor;
import com.hp.hpl.jena.query.engine1.PlanVisitorBase;
import com.hp.hpl.jena.query.engine1.PlanWalker;
import com.hp.hpl.jena.query.engine1.plan.*;

public class PlanVarsMentioned extends PlanVisitorBase
{
    public static Set varMentioned(PlanElement planElt)
    {
        Set acc = new HashSet() ;
        PlanVisitor v = new Visitor(acc) ;
        PlanWalker.walk(planElt, v) ;
        return acc ;
    }
    
        
    static class Visitor extends PlanVisitorBase
    {
        Set acc ;
        public Visitor(Set s) { acc = s ; }
        
        public void visit(PlanBlockTriples planElt)
        {
            for ( Iterator iter = planElt.triples() ; iter.hasNext() ; )
            {
                Triple t = (Triple)iter.next() ;
                addVarsFromTriple(acc, t) ;
            }
        }
        
        public void visit(PlanGroup planElt) {}
        
        public void visit(PlanFilter planElt)
        {
            planElt.getExpr().varNamesMentioned(acc);
        }
        
        public void visit(PlanNamedGraph planElt)
        {
            addVar(acc, planElt.getGraphNameNode()) ;
        }
    
        private static void addVarsFromTriple(Set acc, Triple t)
        {
            addVar(acc, t.getSubject()) ;
            addVar(acc, t.getPredicate()) ;
            addVar(acc, t.getObject()) ;
        }
        
        private static void addVar(Set acc, Node n)
        {
            if ( n == null )
                return ;
            
            if ( n.isVariable() )
                acc.add(n.getName()) ;
        }
    }
}

/*
 * (c) Copyright 2005, 2006 Hewlett-Packard Development Company, LP
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in the
 *    documentation and/or other materials provided with the distribution.
 * 3. The name of the author may not be used to endorse or promote products
 *    derived from this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE AUTHOR ``AS IS'' AND ANY EXPRESS OR
 * IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES
 * OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED.
 * IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR ANY DIRECT, INDIRECT,
 * INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT
 * NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
 * DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
 * THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
 * (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF
 * THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */