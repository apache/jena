/*
 * (c) Copyright 2005, 2006 Hewlett-Packard Development Company, LP
 * All rights reserved.
 * [See end of file]
 */

package com.hp.hpl.jena.query.engine1.compiler;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.ListIterator;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

//import org.apache.commons.logging.*;

import com.hp.hpl.jena.graph.Triple;
import com.hp.hpl.jena.query.ARQ;
import com.hp.hpl.jena.query.core.ElementBasicGraphPattern;
import com.hp.hpl.jena.query.core.ElementFilter;
import com.hp.hpl.jena.query.core.ElementTriplePattern;
import com.hp.hpl.jena.query.engine.QueryIterator;
import com.hp.hpl.jena.query.engine1.*;
import com.hp.hpl.jena.query.util.RefBoolean;
import com.hp.hpl.jena.query.util.Utils;

/**  
 * @author Andy Seaborne
 * @version $Id: PlanBasicGraphPattern.java,v 1.5 2006/06/09 10:50:43 andy_seaborne Exp $
 */

public class PlanBasicGraphPattern extends PlanElementBase
{
    private static Log log = LogFactory.getLog(PlanBasicGraphPattern.class) ;
    List triples = null ;
    List constraints = null ;
    
    // Need to worry about magic properties.
    // Do as a multi pass and return a list of PlanElements?
    
    
    public static PlanElementMulti make(Plan plan, ElementBasicGraphPattern bgp)
    { 
        return splitBlocks(plan, bgp) ;
//        // Step 1 
//        //     - split for magic properties
//        //     - split for filters (compiler to recurse - no - new compiler
//        // **** QueryPatternCompiler.makePlan(plan, Element)
//        // Step 2 - do blocks of triples.
//        PlanBasicGraphPattern planElt = new PlanBasicGraphPattern(plan, bgp) ;
//        x.add(planElt) ;
//        return x ;
    }
    
//    // Currently, we leave the constraints out.  TEMP!
//    // The parser does not place constraints in BGPs currently.
//    // @@ To be removed when splitting works
//    PlanBasicGraphPattern(Plan plan, ElementBasicGraphPattern bgp)
//    {
//        this(plan) ;
//
//        for ( Iterator iter = bgp.getElements().iterator() ; iter.hasNext() ; )
//        {
//            Object obj = iter.next() ;
//            if ( obj instanceof ElementFilter )
//            {
//                ElementFilter pf = (ElementFilter)obj ;
//                log.warn("FixMe: Constraint skipped: "+pf.getConstraint()) ;
//                continue ;
//            }
//            if ( obj instanceof ElementTriplePattern )
//            {
//                ElementTriplePattern eTriple= (ElementTriplePattern)obj ;
//                triples.add(eTriple.getTriple()) ;
//                continue ;
//            }
//            log.warn("Don't recognize: ["+obj.getClass()+"]") ;
//        }
//        
//    }
    
    PlanBasicGraphPattern(Plan plan)
    {
        super(plan);
        triples = new ArrayList() ;
        constraints = new ArrayList() ;
    }

    public static RefBoolean enableMagicProperties = new RefBoolean(EngineConfig.getContext(), ARQ.enablePropertyFunctions) ;
    
    // Split on magic properties and constraints
    private static PlanElementMulti splitBlocks(Plan plan, ElementBasicGraphPattern bgp)
    {
        PlanElementMulti x = new PlanElementMulti() ;
        PlanBasicGraphPattern pbgp = null ; 
        
        if ( bgp.getElements().size() == 0 )
        {
            // Empty basic pattern. Push a blank plan element
            pbgp = new PlanBasicGraphPattern(plan) ;
            x.add(pbgp) ;
            return x ;
        }
        
        for ( Iterator iter = bgp.getElements().iterator() ; iter.hasNext() ; )
        {
            Object obj = iter.next() ;
            PlanElement splitPoint = null ;
            
            if ( pbgp == null )
            {
                // @@
                // Going to do something - allocate a plan element.
                pbgp = new PlanBasicGraphPattern(plan) ;
                x.add(pbgp) ;
            }
            
            if ( obj instanceof ElementTriplePattern )
            {
                ElementTriplePattern eTriple = (ElementTriplePattern)obj ;
                Triple t = eTriple.getTriple() ;
                PlanElement p2 = null ;
                if ( enableMagicProperties.getValue() )
                    p2 = PropertyFunctions.magicProperty(plan, t) ;
                if ( p2 == null )
                {
                    pbgp.triples.add(t) ;
                    continue ;
                }
                splitPoint = p2 ;
            }
            else if ( obj instanceof ElementFilter )
            {
                ElementFilter pf = (ElementFilter)obj ;
                PlanElement e = QueryPatternCompiler.makePlan(plan, pf) ;
                splitPoint = e ;
            }
            else
            {
                log.warn("Don't recognize: ["+obj.getClass()+"]") ;
                continue ;
            }
            // Split the block of triples at the splitElement.
            x.add(splitPoint) ;
        }
        
        return x ; 
    }

    
    
    public ListIterator triples() { return triples.listIterator() ; }
    public List getPattern() { return triples ; }
    public List getConstraints() { return constraints ; }
    
    
    public QueryIterator build(QueryIterator input, ExecutionContext execCxt)
    {
        if ( input == null )
            log.fatal("Null input to "+Utils.classShortName(this.getClass())) ;

        QueryIterator cIter = new QueryIterBasicPattern(input, triples, constraints, execCxt) ;
        return cIter ;
    }


    public void visit(PlanVisitor visitor) { visitor.visit(this) ; }
}

/*
 * (c) Copyright 2005, 2006 Hewlett-Packard Development Company, LP
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in the
 *    documentation and/or other materials provided with the distribution.
 * 3. The name of the author may not be used to endorse or promote products
 *    derived from this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE AUTHOR ``AS IS'' AND ANY EXPRESS OR
 * IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES
 * OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED.
 * IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR ANY DIRECT, INDIRECT,
 * INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT
 * NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
 * DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
 * THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
 * (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF
 * THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */