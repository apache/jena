/*
 * (c) Copyright 2004, 2005, 2006 Hewlett-Packard Development Company, LP
 * [See end of file]
 */

package com.hp.hpl.jena.query.engine1;
import java.util.* ;

import org.apache.commons.logging.*;

import com.hp.hpl.jena.util.*;
import com.hp.hpl.jena.datatypes.xsd.XSDDatatype;
import com.hp.hpl.jena.graph.*;
import com.hp.hpl.jena.query.*;
import com.hp.hpl.jena.query.describe.DescribeHandler;
import com.hp.hpl.jena.query.describe.DescribeHandlerRegistry;
import com.hp.hpl.jena.query.engine.QueryIterator ;
import com.hp.hpl.jena.query.core.ResultBinding;
import com.hp.hpl.jena.query.engine.ResultSetStream;
import com.hp.hpl.jena.query.engine1.compiler.*;
import com.hp.hpl.jena.query.core.*;
import com.hp.hpl.jena.query.util.*;
import com.hp.hpl.jena.rdf.model.*;
import com.hp.hpl.jena.shared.PrefixMapping;

/**
 * @author     Andy Seaborne
 * @version    $Id: QueryEngine.java,v 1.57 2006/04/18 12:55:58 andy_seaborne Exp $
 */
 
public class QueryEngine implements QueryExecution
{
    private static Log log = LogFactory.getLog(QueryEngine.class) ;
    
    protected Query query ;

    static int queryCount = 0 ;
    protected boolean queryInitialised = false ;
    protected int idQueryExecution ;
    
    protected QueryIterator resultsIter ;
    protected Context parameters ;
    protected ExecutionContext context = null ; 
    protected Plan plan ;

    protected QuerySolution startBinding = null ; 
    protected FileManager fileManager = null ;
    protected Dataset dataset = null ;
    
    /** Create a QueryEngine.  The preferred mechanism is through QueryEngineFactory */
    
    public QueryEngine(Query q)
    {
        this(q, null) ;
    }

    public QueryEngine(Query q, Context parameters)
    {
        // System initialized by now : Query class ensures ARQ initialized.
        if ( parameters == null )
            parameters = new Context(EngineConfig.getContext()) ;
        query = q ;
        idQueryExecution = (++queryCount) ;
        this.parameters = parameters ;
    }

    
    public Query getQuery() { return query ; }
    
    /** Initialise a query execution.  May be called before exec.
     *  If it has not be called, the query engine will initialise
     *  itself during the exec() method.
     */

    private void init()
    {
        if (queryInitialised)
            return;

        queryInitializing() ;
        
        // Fixup query.
        query.setResultVars() ;
        
        DatasetGraph dsg = null ;
        if ( getDataset() == null )
            dsg = buildDatasetForQuery() ;
        else
        {
            if ( getDataset().getDefaultModel() == null )
                log.warn("Default model is null in the dataset") ;
            log.debug("External data source for query") ;
            dsg = new DataSourceGraphImpl(getDataset()) ;
        }
        
        // Assign dataset to the top query block. 
        if ( query.getQueryBlock() != null )
            query.getQueryBlock().setDataset(dsg) ;
        else
            query.setQueryBlock(new ElementBlock(dsg, null)) ;
        
        // NB The query has a QueryBlock which will reset the dataset on execution.
        context = new ExecutionContext(parameters, getQuery(), dsg.getDefaultGraph(), dsg) ;
        
        // Build an execution plan
        if ( plan == null )
            plan = buildPlan() ;
            
        queryInitialised = true ;
    }
    
    
    protected void queryInitializing()
    {}
    
    /** Called if a query execution needs a dataset : not called if a dataset has been
     * explicitly set (see also QueryEngineRegistry) 
     */
    protected DatasetGraph buildDatasetForQuery()
    {
        if ( ( query.getGraphURIs() == null || query.getGraphURIs().size() == 0 ) &&
             ( query.getNamedGraphURIs() == null || query.getNamedGraphURIs().size() == 0 ) )
        {
            //Query.log.warn("No data for query (no URL, no model)");
            throw new QueryExecException("No model for query");
        }
        
        String baseURI = query.getBaseURI() ;
        if ( baseURI == null )
            baseURI = RelURI.chooseBaseURI() ;
        log.debug("init: baseURI for query is: "+baseURI) ; 
        
        DatasetGraph dsg =
            DatasetUtils.createDatasetGraph(query.getGraphURIs(),
                                            query.getNamedGraphURIs(),
                                            fileManager, baseURI ) ;
        return dsg ;
   }
    
    public void setInitialBinding(QuerySolution rb) { startBinding = rb ; }
    public void setFileManager(FileManager fm) { fileManager = fm ; }

    /**
     * @return Returns the dataset.
     */
    public Dataset getDataset()
    {
        return dataset;
    }
    /**
     * @param dataset The dataset to set.
     */
    public void setDataset(Dataset dataset)
    {
        this.dataset = dataset;
    }
    
    /** Debugging operation */
    
    public Plan getPlan() 
    {
        if ( plan == null )
            plan = buildPlan() ;
        return plan ;
    }
    
    /** @return Return the parameters associated with this QueryEngine */
    public Context getContext() { return parameters ; }
    
    // Construct
    
    public Model execConstruct()
    {
        init() ;

        if ( ! query.isConstructType() )
            throw new QueryExecException("Attempt to get a CONSTRUCT model from a "+labelForQuery(query)+" query") ; 

        Model resultModel = GraphUtils.makeJenaDefaultModel() ;

        // Prefixes for result
        insertPrefixesInto(resultModel) ;
        
        ResultSet qRes = execInternal() ;
        Set set = new HashSet() ;
        
        Template template = query.getConstructTemplate() ;
        
        for ( ; qRes.hasNext() ; )
        {
            Map bNodeMap = new HashMap() ;
            QuerySolution qs = qRes.nextSolution() ;
            ResultBinding rb = (ResultBinding)qs ;
            template.subst(set, bNodeMap, rb.getBinding()) ; 
        }
        
        for ( Iterator iter = set.iterator() ; iter.hasNext() ; )
        {
            Triple t = (Triple)iter.next() ;
            Statement stmt = QueryEngineUtils.tripleToStatement(resultModel, t) ;
            if ( stmt != null )
                resultModel.add(stmt) ;
        }
        
        this.close() ;
        return resultModel ;
    }


    public Model execDescribe()
    {
        init() ;
        if ( ! query.isDescribeType() )
            throw new QueryExecException("Attempt to get a DESCRIBE result from a "+labelForQuery(query)+" query") ; 
        
        Model results = GraphUtils.makeJenaDefaultModel() ;

        // Prefixes for result
        insertPrefixesInto(results) ;
        Set set = new HashSet() ;
        
        // if there is a WHERE block ... 
        if ( query.getQueryBlock().getPatternElement() != null )
        {
            ResultSet qRes = execInternal() ;
            for ( ; qRes.hasNext() ; )
            {
                QuerySolution rb = qRes.nextSolution() ;
                for ( Iterator iter = query.getResultVars().iterator() ; iter.hasNext() ; )
                {
                    String varName = (String)iter.next() ;
                    RDFNode n = rb.get(varName) ;
                    set.add(n) ;
                }
            }
        }
        
        if ( query.getResultURIs() != null )
        {
            // Any URIs in the DESCRIBE
            for ( Iterator iter = query.getResultURIs().iterator() ; iter.hasNext() ; )
            {
                Node n = (Node)iter.next() ;
                RDFNode rNode = NodeUtils.convertGraphNodeToRDFNode(n, dataset.getDefaultModel()) ;
                set.add(rNode) ;
            }
        }

        // Notify start of describe phase
        
        DescribeHandlerRegistry dhReg = DescribeHandlerRegistry.get() ;
        for ( Iterator handlers = dhReg.handlers() ; handlers.hasNext() ; )
        {
            DescribeHandler dh = (DescribeHandler)handlers.next() ;
            dh.start(results, context) ;
        }
        
        // Do describe for each resource found.
        
        for (Iterator iter = set.iterator() ; iter.hasNext() ;)
        {
            RDFNode n = (RDFNode)iter.next() ;
        
            if ( n instanceof Resource )
            {
                Iterator handlers = dhReg.handlers() ;
                for ( ; handlers.hasNext() ; )
                {
                    DescribeHandler dh = (DescribeHandler)handlers.next() ;
                    dh.describe((Resource)n) ;
                }
            }
            else
                // Can't describe literals
                continue ;
        }
        
        // Notify end of describe phase
        for ( Iterator handlers = dhReg.handlers() ; handlers.hasNext() ; )
        {
            DescribeHandler dh = (DescribeHandler)handlers.next() ;
            dh.finish() ;
        }


        this.close() ;
        return results ; 
    }
    
    /** Execute a query and get back the results.
     * @return ResultSet
     */
    
    public ResultSet execSelect()
    {
        init() ;

        if ( ! query.isSelectType() )
            throw new QueryExecException("Attempt to have ResultSet from a "+labelForQuery(query)+" query") ; 
        return execInternal() ;
    }
        
    public boolean execAsk()
    {
        if ( ! query.isAskType() )
            throw new QueryExecException("Attempt to have boolean from a "+labelForQuery(query)+" query") ; 

        ResultSet results = execInternal() ;
        boolean r = results.hasNext() ;
        this.close() ;
        return r ; 
    }

    private ResultSet execInternal()
    {
        resultsIter = planToIterator() ;
        
        // Choose the model for reconstructed resources.
        // This is the default model of any supplied dataset
        // (not perfect - suppose the variable is bound by a named graph)
        // or one constructed from the queried graph 
        
        Model model = null ;
        if ( dataset != null )
            model = dataset.getDefaultModel() ;
        if ( model == null )
        {
            Graph g = query.getQueryBlock().getDataset().getDefaultGraph() ;
            if ( g != null )
                model = ModelFactory.createModelForGraph(g) ;
            else
                model = null ;
        }
        
        ResultSetStream rStream = new ResultSetStream(query.getResultVars(), model, resultsIter) ;
        
        // Set flags (the plan has the elements for solution modifiers)
        if ( query.hasOrderBy() )
            rStream.setOrdered(true) ;
        if ( query.isDistinct() )
            rStream.setDistinct(true) ;
        return rStream ;
    }
    
    // ------------------------------------------------
    // Query Engine extension points.
    
    /** This operator is a hook for other query engines to reuse this framework but
     *  take responsibility for their own query pattern execution. 
     */
    protected PlanElement makePlanForQueryPattern(Plan plan)
    {
        return QueryPatternCompiler.makePlan(plan, query.getQueryBlock()) ;
    }
    
    /** Inspect, and possibily modify, the query plan and execution tree.
     * Called after plan creation getPlanForQueryPattern
     * 
     * @param plan
     * @param planElt
     * @return PlanElement  New root of the planning tree (often, the one passed in)
     */
    protected PlanElement queryPlanHook(Plan plan, PlanElement planElt)
    { return planElt ; } 
    
    // Turn a plan for the whole query into a results iterator.
    private QueryIterator planToIterator()
    {
        QueryIterator qIter = null ;
        try {
            init() ;
            PlanElement pElt = getPlan().getRoot() ; 
            
            Binding rootBinding = makeRootBinding() ;
            
            if ( startBinding != null )
            {
                for ( Iterator iter = startBinding.varNames() ; iter.hasNext() ; )
                {
                    String n = (String)iter.next() ;
                    RDFNode x = startBinding.get(n) ;
                    rootBinding.add(n, x.asNode()) ;
                }
            }
            
            QueryIterator initialIter = new QueryIterSingleton(rootBinding, context) ; ;
            
            DatasetGraph datasetGraph = new DataSourceGraphImpl(dataset) ;
            qIter = pElt.build(initialIter, context) ;
            
            // = patternIterator(mark, qBlock, initialIter, context, dataset) ;
            
            ElementBlock qBlock = query.getQueryBlock() ;
            if ( qBlock == null )
                return new QueryIterNullIterator(context) ;
            
            // This happens in init() as well.
            qBlock.setDataset(datasetGraph) ;
            
            return qIter ;
        } catch (RuntimeException ex) {
            if ( qIter != null )
                qIter.close();
            throw ex ;
        }
        
    }

    private Binding makeRootBinding()
    {
        Binding rootBinding = Binding.createRootBinding() ;
        Calendar cal = new GregorianCalendar() ;
        String lex = Utils.calendarToXSDDateTimeString(cal) ;
        Node n = Node.createLiteral(lex, null, XSDDatatype.XSDdateTime) ;
        rootBinding.add(Constants.varCurrentTime, n) ;
        return rootBinding ;
    }
    
    // Build plan around the query pattern plan 
    
    private Plan buildPlan()
    {
        if ( plan != null )
            return plan ;
        
        plan = new Plan(parameters) ;
        PlanElement planElt = makePlanForQueryPattern(plan) ;
        planElt = queryPlanHook(plan, planElt) ;
        plan.setRoot(planElt) ;

        // -- Modifiers
        
        // ORDER BY
        if ( query.hasOrderBy() )
            planElt = PlanOrderBy.make(plan, planElt, query.getOrderBy()) ;
        
        // Project (ORDER may involve an unselected variable)
        if ( ! query.isQueryResultStar() )
        {
            if ( query.getResultVars().size() == 0 && query.isSelectType() )
                log.warn("No project variables") ;
            planElt = PlanProject.make(plan, planElt, query.getResultVars()) ;
        }
        
        // DISTINCT
        if ( query.isDistinct() )
            planElt = PlanDistinct.make(plan, planElt, query.getResultVars()) ;
        
        // LIMIT/OFFSET
        if ( query.hasLimit() || query.hasOffset() )
            planElt = PlanLimitOffset.make(plan, planElt, query.getLimit(), query.getOffset()) ;

        plan.setRoot(planElt) ;
        return plan ;
    }
    
    // --------------------------------
    
    /** Abnormal end of this execution  */
    public void abort()
    {
        // The close operation below does not mind if the
        // query has not been exhausted.
        close(true) ;
    }

    /** Normal end of use of this execution  */
    public void close()
    {
        close(true) ;
    }
    
    /** End execution: if the iteration is already exhusted,
     * the main iterator will already be closed (and also for 
     * ASK, DESCRIBE, CONSTRUCT queries).  
     * 
     * @param forceClose Whether to shut the iterator anyway.
     */
    private void close(boolean forceClose)
    {
        if ( ! queryInitialised )
        {
            log.warn("Closing a query that has not been run") ;
            return ;
        }
        
        // If not forced close, the results iterator should have autoclosed already.
        if ( forceClose )
        {
            if ( resultsIter != null )
                resultsIter.close() ;
            resultsIter = null ;
        }
        
        // Now check for open iterators
        Iterator iter = context.listOpenIterators() ;
        while(iter.hasNext())
        {
            QueryIterator qIterOpen = (QueryIterator)iter.next() ;
            if ( qIterOpen instanceof QueryIter )
            {
                QueryIter qIterBase = (QueryIter)qIterOpen ;
                log.warn("Open iterator: "+qIterBase.getCounter()+" "+qIterOpen) ;
            }
            else
                log.warn("Open iterator: "+qIterOpen) ;
        }
        
        // Close it anyway
        if ( resultsIter != null )
            resultsIter.close() ;
        resultsIter = null ;
    }
    
    private void insertPrefixesInto(Model model)
    {
        try {
            // Load the models prefixes first
            PrefixMapping m = query.getQueryBlock().getDataset().getDefaultGraph().getPrefixMapping() ;
            model.setNsPrefixes(m) ;
            
            // Then add the queries (just the declared mappings)
            // so the query declarations override the data sources. 
            model.setNsPrefixes(query.getPrefixMapping()) ;

        } catch (Exception ex)
        {
            log.warn("Exception in insertPrefixes: "+ex.getMessage()) ;
        }
    }
    
    static private String labelForQuery(Query q)
    {
        if ( q.isSelectType() )     return "SELECT" ; 
        if ( q.isConstructType() )  return "CONSTRUCT" ; 
        if ( q.isDescribeType() )   return "DESCRIBE" ; 
        if ( q.isAskType() )        return "ASK" ;
        return "<<unknown>>" ;
    }
}

/*
 *  (c) Copyright 2004, 2005, 2006 Hewlett-Packard Development Company, LP
 *  All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in the
 *    documentation and/or other materials provided with the distribution.
 * 3. The name of the author may not be used to endorse or promote products
 *    derived from this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE AUTHOR ``AS IS'' AND ANY EXPRESS OR
 * IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES
 * OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED.
 * IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR ANY DIRECT, INDIRECT,
 * INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT
 * NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
 * DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
 * THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
 * (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF
 * THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */
