/*
 * (c) Copyright 2004, 2005, 2006 Hewlett-Packard Development Company, LP
 * [See end of file]
 */

package com.hp.hpl.jena.query.engine1;
import java.util.* ;

import org.apache.commons.logging.*;

import com.hp.hpl.jena.util.*;
import com.hp.hpl.jena.datatypes.xsd.XSDDatatype;
import com.hp.hpl.jena.graph.*;
import com.hp.hpl.jena.query.*;
import com.hp.hpl.jena.query.describe.DescribeHandler;
import com.hp.hpl.jena.query.describe.DescribeHandlerRegistry;
import com.hp.hpl.jena.query.engine.QueryIterator ;
import com.hp.hpl.jena.query.core.ARQConstants;
import com.hp.hpl.jena.query.core.ResultBinding;
import com.hp.hpl.jena.query.engine.ResultSetStream;
import com.hp.hpl.jena.query.engine1.compiler.*;
import com.hp.hpl.jena.query.engine1.iterator.QueryIter;
import com.hp.hpl.jena.query.engine1.iterator.QueryIterNullIterator;
import com.hp.hpl.jena.query.engine1.iterator.QueryIterSingleton;
import com.hp.hpl.jena.query.engine1.plan.PlanDistinct;
import com.hp.hpl.jena.query.engine1.plan.PlanLimitOffset;
import com.hp.hpl.jena.query.engine1.plan.PlanOrderBy;
import com.hp.hpl.jena.query.engine1.plan.PlanProject;
import com.hp.hpl.jena.query.core.*;
import com.hp.hpl.jena.query.util.*;
import com.hp.hpl.jena.rdf.model.*;
import com.hp.hpl.jena.shared.PrefixMapping;

/**
 * @author     Andy Seaborne
 * @version    $Id: QueryEngine.java,v 1.74 2006/08/01 17:19:36 andy_seaborne Exp $
 */
 
public class QueryEngine implements QueryExecution
{
    private static Log log = LogFactory.getLog(QueryEngine.class) ;
    
    protected Query query ;

    static int queryCount = 0 ;
    protected boolean queryExecutionInitialised = false ;
    protected int idQueryExecution ;
    
    protected QueryIterator resultsIter ;
    protected Context context ;                  // Passed in
    protected ExecutionContext execContext = null ; 
    //protected Plan plan = null ;                    // Plan for whole query
    protected PlanElement plan = null ;
    protected PlanElement planPattern = null ;      // PlanElement tree for the pattern part

    
    protected QuerySolution startBinding = null ; 
    protected FileManager fileManager = null ;
    protected Dataset      dataset = null ;         // Set extenally
    protected DatasetGraph datasetGraph = null ;    // The graph equivalent
    
    /** Create a QueryEngine.  The preferred mechanism is through QueryEngineFactory */
    
    public QueryEngine(Query q)
    {
        this(q, null) ;
    }

    public QueryEngine(Query q, Context context)
    {
        // System initialized by now : Query class ensures ARQ initialized.
        if ( context == null )
            context = new Context(EngineConfig.getContext()) ;
        query = q ;
        idQueryExecution = (++queryCount) ;
        this.context = context ;
    }

    
    public Query getQuery() { return query ; }
    
    /** Initialise a query execution.  
     * Does not build the plan though.
     * May be called before exec.
     * If it has not be called, the query engine will initialise
     * itself during the exec() method.
     */

    protected void init()
    {
        if (queryExecutionInitialised)
            return;

        startInitializing() ;
        
        // Fixup query.
        query.setResultVars() ;
        
        // Set the dataset (graph form) 
        DatasetGraph dsg = null ;
        if ( getDataset() == null )
            dsg = buildDatasetForQuery() ;
        else
        {
            if ( getDataset().getDefaultModel() == null )
                log.warn("Default model is null in the dataset") ;
            dsg = new DataSourceGraphImpl(getDataset()) ;
        }
        
        datasetGraph = dsg ;
        
        // Create query execution context
        execContext = new ExecutionContext(context, getQuery(), dsg.getDefaultGraph(), dsg) ;
        
        queryExecutionInitialised = true ;
        finishInitializing() ;
    }
    
    protected void startInitializing()
    {}

    protected void finishInitializing()
    {}
    
    /** Called if a query execution needs a dataset : not called if a dataset has been
     * explicitly set (see also QueryEngineRegistry) 
     */
    protected DatasetGraph buildDatasetForQuery()
    {
        if ( ( query.getGraphURIs() == null || query.getGraphURIs().size() == 0 ) &&
             ( query.getNamedGraphURIs() == null || query.getNamedGraphURIs().size() == 0 ) )
        {
            //Query.log.warn("No data for query (no URL, no model)");
            throw new QueryExecException("No model for query");
        }
        
        String baseURI = query.getBaseURI() ;
        if ( baseURI == null )
            baseURI = RelURI.chooseBaseURI() ;
        log.debug("init: baseURI for query is: "+baseURI) ; 
        
        DatasetGraph dsg =
            DatasetUtils.createDatasetGraph(query.getGraphURIs(),
                                            query.getNamedGraphURIs(),
                                            fileManager, baseURI ) ;
        return dsg ;
    }
    
    public void setInitialBinding(QuerySolution rb) { startBinding = rb ; }
    public void setFileManager(FileManager fm) { fileManager = fm ; }

    /**
     * @return Returns the dataset.
     */
    public Dataset getDataset()
    {
        return dataset;
    }
    /**
     * @param dataset The dataset to set.
     */
    public void setDataset(Dataset dataset)
    {
        this.dataset = dataset;
    }
    
    /** Get the Plan for the query (building it if it has not already been built)
     * 
     * @return Plan
     */
    public PlanElement getPlan() 
    {
        if ( plan == null )
            plan = buildPlan() ;
        return plan ;
    }
    
    /** Get the PlanElement for the start of the query pattern.
     *  Builds the whole plan if necessary.
     * 
     * @return PlanElement
     */
    public PlanElement getPlanPattern() 
    {
        if ( plan == null )
            getPlan() ;
        return planPattern ;    
    }
    
    /** @return Return the parameters associated with this QueryEngine */
    public Context getContext() { return context ; }
    
    // Construct
    public Model execConstruct()
    { return execConstruct(GraphUtils.makeJenaDefaultModel()) ; }
    
    public Model execConstruct(Model model)
    {
        if ( ! query.isConstructType() )
            throw new QueryExecException("Attempt to get a CONSTRUCT model from a "+labelForQuery(query)+" query") ;
        //This causes there to be no PROJECT around the pattern
        // That in turn, exposes the initial bindings.  
        query.setQueryResultStar(true) ;

        init() ;
        buildPlan(true) ;       // No projection on the pattern

        // Prefixes for result
        insertPrefixesInto(model) ;
        
        ResultSet qRes = execInternal() ;
//        if ( this.startBinding != null )
//            query.addExtraVars(startBinding.varNames()) ;
        
        Set set = new HashSet() ;
        
        Template template = query.getConstructTemplate() ;
        
        // The result set does not include the variables from initial bindings because they got
        // projected away when the result set has its variables set. 
        for ( ; qRes.hasNext() ; )
        {
            Map bNodeMap = new HashMap() ;
            QuerySolution qs = qRes.nextSolution() ;
            ResultBinding rb = (ResultBinding)qs ;
            template.subst(set, bNodeMap, rb.getBinding()) ; 
        }
        
        for ( Iterator iter = set.iterator() ; iter.hasNext() ; )
        {
            Triple t = (Triple)iter.next() ;
            Statement stmt = QueryEngineUtils.tripleToStatement(model, t) ;
            if ( stmt != null )
                model.add(stmt) ;
        }
        
        this.close() ;
        return model ;
    }

    public Model execDescribe()
    { return execDescribe(GraphUtils.makeJenaDefaultModel()) ; }

    
    public Model execDescribe(Model model)
    {
        if ( ! query.isDescribeType() )
            throw new QueryExecException("Attempt to get a DESCRIBE result from a "+labelForQuery(query)+" query") ; 
        query.setQueryResultStar(true) ;
        
        init() ;
        buildPlan() ;

        // Prefixes for result
        insertPrefixesInto(model) ;
        Set set = new HashSet() ;
        
        // if there is a WHERE block ... 
        if ( plan != null )
        {
            ResultSet qRes = execInternal() ;
            for ( ; qRes.hasNext() ; )
            {
                QuerySolution rb = qRes.nextSolution() ;
                for ( Iterator iter = query.getResultVars().iterator() ; iter.hasNext() ; )
                {
                    String varName = (String)iter.next() ;
                    RDFNode n = rb.get(varName) ;
                    set.add(n) ;
                }
            }
        }
        
        if ( query.getResultURIs() != null )
        {
            // Any URIs in the DESCRIBE
            for ( Iterator iter = query.getResultURIs().iterator() ; iter.hasNext() ; )
            {
                Node n = (Node)iter.next() ;
                RDFNode rNode = NodeUtils.convertGraphNodeToRDFNode(n, dataset.getDefaultModel()) ;
                set.add(rNode) ;
            }
        }

        // Notify start of describe phase
        
        DescribeHandlerRegistry dhReg = DescribeHandlerRegistry.get() ;
        for ( Iterator handlers = dhReg.handlers() ; handlers.hasNext() ; )
        {
            DescribeHandler dh = (DescribeHandler)handlers.next() ;
            dh.start(model, execContext) ;
        }
        
        // Do describe for each resource found.
        
        for (Iterator iter = set.iterator() ; iter.hasNext() ;)
        {
            RDFNode n = (RDFNode)iter.next() ;
        
            if ( n instanceof Resource )
            {
                Iterator handlers = dhReg.handlers() ;
                for ( ; handlers.hasNext() ; )
                {
                    DescribeHandler dh = (DescribeHandler)handlers.next() ;
                    dh.describe((Resource)n) ;
                }
            }
            else
                // Can't describe literals
                continue ;
        }
        
        // Notify end of describe phase
        for ( Iterator handlers = dhReg.handlers() ; handlers.hasNext() ; )
        {
            DescribeHandler dh = (DescribeHandler)handlers.next() ;
            dh.finish() ;
        }


        this.close() ;
        return model ; 
    }
    
    /** Execute a query and get back the results.
     * @return ResultSet
     */
    
    public ResultSet execSelect()
    {
        init() ;
        buildPlan() ;

        if ( ! query.isSelectType() )
            throw new QueryExecException("Attempt to have ResultSet from a "+labelForQuery(query)+" query") ; 
        return execInternal() ;
    }
        
    public boolean execAsk()
    {
        if ( ! query.isAskType() )
            throw new QueryExecException("Attempt to have boolean from a "+labelForQuery(query)+" query") ; 

        init() ;
        buildPlan() ;

        ResultSet results = execInternal() ;
        boolean r = results.hasNext() ;
        this.close() ;
        return r ; 
    }

    private ResultSet execInternal()
    {
        resultsIter = planToIterator() ;
        
        // Choose the model for reconstructed resources.
        // This is the default model of any supplied dataset
        // (not perfect - suppose the variable is bound by a named graph)
        // or one constructed from the queried graph 
        
        Model model = null ;
        if ( dataset != null )
            model = dataset.getDefaultModel() ;
        if ( model == null )
        {
            Graph g = datasetGraph.getDefaultGraph() ;
            if ( g != null )
                model = ModelFactory.createModelForGraph(g) ;
            else
                model = null ;
        }
        
        ResultSetStream rStream = new ResultSetStream(query.getResultVars(), model, resultsIter) ;
        
        // Set flags (the plan has the elements for solution modifiers)
        if ( query.hasOrderBy() )
            rStream.setOrdered(true) ;
        if ( query.isDistinct() )
            rStream.setDistinct(true) ;
        return rStream ;
    }
    
    // ------------------------------------------------
    // Query Engine extension points.
    
    /** This operator is a hook for other query engines to reuse this framework but
     *  take responsibility for their own query pattern construction. 
     */
    protected PlanElement makePlanForQueryPattern(Context context, Element queryPatternElement)
    {
        // Choose the thing to make a plan of
        // This can be null - no WHERE clause.
        if ( queryPatternElement == null )
            return null ;
        return QueryPatternCompiler.makePlan(context, queryPatternElement) ;
    }
    
    /** Inspect, and possibily modify, the query plan and execution tree.
     * Called after plan creation getPlanForQueryPattern
     * 
     * @param context
     * @param planElt
     * @return PlanElement The plan element for the query pattern - often the PlanElement passed in
     */
    protected PlanElement queryPlanPatternHook(Context context, PlanElement planElt)
    { return planElt ; } 
    
    /** Inspect, and possibily modify, the query plan and execution tree.
     * Called after plan creation getPlanForQueryPattern
     * 
     * @param context
     * @param planElt
     * @return PlanElement  New root of the planning tree (often, the one passed in)
     */
    protected PlanElement queryPlanHook(Context context, PlanElement planElt)
    { return planElt ; } 
    
    // Turn a plan for the whole query into a results iterator.
    private QueryIterator planToIterator()
    {
        QueryIterator qIter = null ;
        try {
            if ( ! queryExecutionInitialised )
                throw new ARQInternalErrorException("Query executiuon not initialized") ;

            Binding rootBinding = makeRootBinding() ;
            
            if ( startBinding != null )
            {
                for ( Iterator iter = startBinding.varNames() ; iter.hasNext() ; )
                {
                    String n = (String)iter.next() ;
                    RDFNode x = startBinding.get(n) ;
                    rootBinding.add(n, x.asNode()) ;
                }
            }
            
            QueryIterator initialIter = new QueryIterSingleton(rootBinding, execContext) ;
            
            if ( datasetGraph == null )
                throw new ARQInternalErrorException("No DatsetGraph for query") ;

            PlanElement pElt = getPlan() ; 
            
            // Any WHERE clause ?
            if ( pElt == null )
            {
                if ( startBinding != null )
                    return initialIter ;
                else
                    return new QueryIterNullIterator(execContext) ;
            }

            qIter = pElt.build(initialIter, execContext) ;
            return qIter ;
        } catch (RuntimeException ex) {
            if ( qIter != null )
                qIter.close();
            throw ex ;
        }
        
    }

    private static Binding makeRootBinding()
    {
        Binding rootBinding = BindingBase.createRootBinding() ;
        Calendar cal = new GregorianCalendar() ;
        String lex = Utils.calendarToXSDDateTimeString(cal) ;
        Node n = Node.createLiteral(lex, null, XSDDatatype.XSDdateTime) ;
        rootBinding.add(ARQConstants.varCurrentTime, n) ;
        return rootBinding ;
    }
    
    // Build plan around the query pattern plan 
    private PlanElement buildPlan() { return buildPlan(false) ; }
    
    private PlanElement buildPlan(boolean surpressProject)
    {
        if ( plan != null )
            return plan ;

        // Remember the part of the plan that is specifically for the query pattern
        planPattern = makePlanForQueryPattern(context, query.getQueryPattern()) ;
        
        // Give subclasses a chance to run
        planPattern = queryPlanPatternHook(context, planPattern) ;
        PlanElement planElt = planPattern ;

        // -- Modifiers
        
        // ORDER BY
        if ( query.hasOrderBy() )
            planElt = PlanOrderBy.make(context, planElt, query.getOrderBy()) ;
        
        // Project (ORDER may involve an unselected variable)
        // No propjection => initial variables are exposed.  Needed for CONSTRUCT.
        
        if ( query.isQueryResultStar() )
            surpressProject = true ;
        
        if ( ! surpressProject )
        {
            if ( query.getResultVars().size() == 0 && query.isSelectType() )
                log.warn("No project variables") ;
            planElt = PlanProject.make(context, planElt, query.getResultVars()) ;
        }
        
        // DISTINCT
        if ( query.isDistinct() || getContext().isTrue(EngineConfig.autoDistinct) )
            planElt = PlanDistinct.make(context, planElt, query.getResultVars()) ;
        
        // LIMIT/OFFSET
        if ( query.hasLimit() || query.hasOffset() )
            planElt = PlanLimitOffset.make(context, planElt, query.getLimit(), query.getOffset()) ;

        plan = planElt ;
        plan = queryPlanHook(context, plan) ;
        return plan ;
    }
    
    // --------------------------------
    
    /** Abnormal end of this execution  */
    public void abort()
    {
        // The close operation below does not mind if the
        // query has not been exhausted.
        close(true) ;
    }

    /** Normal end of use of this execution  */
    public void close()
    {
        close(true) ;
    }
    
    /** End execution: if the iteration is already exhusted,
     * the main iterator will already be closed (and also for 
     * ASK, DESCRIBE, CONSTRUCT queries).  
     * 
     * @param forceClose Whether to shut the iterator anyway.
     */
    private void close(boolean forceClose)
    {
        if ( ! queryExecutionInitialised )
        {
            log.warn("Closing a query that has not been run") ;
            return ;
        }
        
        // If not forced close, the results iterator should have autoclosed already.
        if ( forceClose )
        {
            if ( resultsIter != null )
                resultsIter.close() ;
            resultsIter = null ;
        }
        
        // Now check for open iterators
        Iterator iter = execContext.listOpenIterators() ;
        while(iter.hasNext())
        {
            QueryIterator qIterOpen = (QueryIterator)iter.next() ;
            if ( qIterOpen instanceof QueryIter )
            {
                QueryIter qIterBase = (QueryIter)qIterOpen ;
                log.warn("Open iterator: "+qIterBase.getCounter()+" "+qIterOpen) ;
            }
            else
                log.warn("Open iterator: "+qIterOpen) ;
        }
        
        // Close it anyway
        if ( resultsIter != null )
            resultsIter.close() ;
        resultsIter = null ;
    }
    
    private void insertPrefixesInto(Model model)
    {
        try {
            // Load the models prefixes first
            PrefixMapping m = datasetGraph.getDefaultGraph().getPrefixMapping() ;
            model.setNsPrefixes(m) ;
            
            // Then add the queries (just the declared mappings)
            // so the query declarations override the data sources. 
            model.setNsPrefixes(query.getPrefixMapping()) ;

        } catch (Exception ex)
        {
            log.warn("Exception in insertPrefixes: "+ex.getMessage()) ;
        }
    }
    
    static private String labelForQuery(Query q)
    {
        if ( q.isSelectType() )     return "SELECT" ; 
        if ( q.isConstructType() )  return "CONSTRUCT" ; 
        if ( q.isDescribeType() )   return "DESCRIBE" ; 
        if ( q.isAskType() )        return "ASK" ;
        return "<<unknown>>" ;
    }
}

/*
 *  (c) Copyright 2004, 2005, 2006 Hewlett-Packard Development Company, LP
 *  All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in the
 *    documentation and/or other materials provided with the distribution.
 * 3. The name of the author may not be used to endorse or promote products
 *    derived from this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE AUTHOR ``AS IS'' AND ANY EXPRESS OR
 * IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES
 * OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED.
 * IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR ANY DIRECT, INDIRECT,
 * INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT
 * NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
 * DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
 * THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
 * (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF
 * THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */
