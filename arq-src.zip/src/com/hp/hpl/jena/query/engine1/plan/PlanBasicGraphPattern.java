/*
 * (c) Copyright 2005, 2006 Hewlett-Packard Development Company, LP
 * All rights reserved.
 * [See end of file]
 */

package com.hp.hpl.jena.query.engine1.plan;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import com.hp.hpl.jena.graph.Triple;
import com.hp.hpl.jena.query.ARQ;
import com.hp.hpl.jena.query.core.ElementBasicGraphPattern;
import com.hp.hpl.jena.query.core.ElementFilter;
import com.hp.hpl.jena.query.core.ElementTriplePattern;
import com.hp.hpl.jena.query.engine.QueryIterator;
import com.hp.hpl.jena.query.engine1.*;
import com.hp.hpl.jena.query.engine1.compiler.PropertyFunctions;
import com.hp.hpl.jena.query.engine1.compiler.QueryPatternCompiler;
import com.hp.hpl.jena.query.util.RefBoolean;

/**  
 * @author Andy Seaborne
 * @version $Id: PlanBasicGraphPattern.java,v 1.1 2006/06/15 17:07:29 andy_seaborne Exp $
 */

public class PlanBasicGraphPattern extends PlanElementN
{
    private static Log log = LogFactory.getLog(PlanBasicGraphPattern.class) ;
    
    // Need to worry about magic properties.
    // Do as a multi pass and return a list of PlanElements?
    
    public static PlanElement make(Plan plan, ElementBasicGraphPattern bgp)
    { 
        return new PlanBasicGraphPattern(plan, bgp) ;
    }
    
    private PlanBasicGraphPattern(Plan plan, ElementBasicGraphPattern bgp)
    {
        this(plan, splitBGP(plan, bgp));
    }

    private PlanBasicGraphPattern(Plan plan, List readyMadePlanElements)
    {
        super(plan, readyMadePlanElements) ;
    }
    
    public static RefBoolean enableMagicProperties = new RefBoolean(EngineConfig.getContext(), ARQ.enablePropertyFunctions) ;
    
    // Split on magic properties and constraints
    private static List splitBGP(Plan plan, ElementBasicGraphPattern bgp)
    {
        List x = new ArrayList() ;
        PlanBlockTriples planBP = null ;
        
        for ( Iterator iter = bgp.getElements().iterator() ; iter.hasNext() ; )
        {
            Object obj = iter.next() ;
            PlanElement splitPoint = null ;
            
            // Clump triples
            
            if ( obj instanceof ElementTriplePattern )
            {
                if ( planBP == null )
                {
                    planBP = new PlanBlockTriples(plan) ;
                    x.add(planBP) ;
                }
                
                ElementTriplePattern eTriple = (ElementTriplePattern)obj ;
                Triple t = eTriple.getTriple() ;
                PlanElement p2 = null ;
                if ( enableMagicProperties.getValue() )
                    p2 = PropertyFunctions.magicProperty(plan, t) ;
                if ( p2 == null )
                {
                    // Not magic - add the PlanBasicPattern and continue.
                    planBP.addTriple(t) ;
                    continue ;
                }
                splitPoint = p2 ;
                // Drop through
            }
            else if ( obj instanceof ElementFilter )
            {
                ElementFilter pf = (ElementFilter)obj ;
                PlanElement e = QueryPatternCompiler.makePlan(plan, pf) ;
                splitPoint = e ;
            }
            else
            {
                log.warn("Don't recognize: ["+obj.getClass()+"]") ;
                continue ;
            }
            // Split the block of triples at the splitElement.
            x.add(splitPoint) ;
            planBP = null ;
        }
        
        return x ; 
    }

    public QueryIterator build(QueryIterator input, ExecutionContext execCxt)
    {
        return buildSerial(this, input, execCxt) ;
    }
    
    public void visit(PlanVisitor visitor) { visitor.visit(this) ; }
    
    public PlanElement apply(Transform transform, List newSubElements)
    { return transform.transform(this, newSubElements) ; }

    public PlanElement copy(List newSubElements)
    {
        return new PlanBasicGraphPattern(getPlan(), newSubElements) ;
    }
}

/*
 * (c) Copyright 2005, 2006 Hewlett-Packard Development Company, LP
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in the
 *    documentation and/or other materials provided with the distribution.
 * 3. The name of the author may not be used to endorse or promote products
 *    derived from this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE AUTHOR ``AS IS'' AND ANY EXPRESS OR
 * IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES
 * OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED.
 * IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR ANY DIRECT, INDIRECT,
 * INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT
 * NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
 * DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
 * THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
 * (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF
 * THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */