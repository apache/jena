/*
 * (c) Copyright 2005, 2006 Hewlett-Packard Development Company, LP
 * All rights reserved.
 * [See end of file]
 */

package com.hp.hpl.jena.query.engine1.plan;

import java.util.*;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import com.hp.hpl.jena.graph.Triple;
import com.hp.hpl.jena.query.ARQ;
import com.hp.hpl.jena.query.core.ElementBasicGraphPattern;
import com.hp.hpl.jena.query.core.ElementFilter;
import com.hp.hpl.jena.query.core.ElementTriplePattern;
import com.hp.hpl.jena.query.engine.QueryIterator;
import com.hp.hpl.jena.query.engine1.EngineConfig;
import com.hp.hpl.jena.query.engine1.ExecutionContext;
import com.hp.hpl.jena.query.engine1.PlanElement;
import com.hp.hpl.jena.query.engine1.PlanVisitor;
import com.hp.hpl.jena.query.engine1.compiler.PFuncOps;
import com.hp.hpl.jena.query.engine1.compiler.QueryPatternCompiler;
import com.hp.hpl.jena.query.pfunction.PropertyFunctionRegistry;
import com.hp.hpl.jena.query.util.Context;
import com.hp.hpl.jena.query.util.RefBoolean;
import com.hp.hpl.jena.query.util.Utils;

/**  
 * @author Andy Seaborne
 * @version $Id: PlanBasicGraphPattern.java,v 1.10 2006/08/25 14:54:56 andy_seaborne Exp $
 */

public class PlanBasicGraphPattern extends PlanElementN
{
    private static Log log = LogFactory.getLog(PlanBasicGraphPattern.class) ;
    
    // Need to worry about magic properties.
    // Do as a multi pass and return a list of PlanElements?
    
    public static PlanElement make(Context context, ElementBasicGraphPattern bgp)
    { 
        return new PlanBasicGraphPattern(context, bgp) ;
    }
    
    /** Create an empty PlanBasicGraphPattern */
    public PlanBasicGraphPattern(Context context)
    {
        this(context, (List)null) ;
    }
    
    private PlanBasicGraphPattern(Context context, ElementBasicGraphPattern bgp)
    {
        this(context, process(context, bgp));
    }

    private PlanBasicGraphPattern(Context context, List readyMadePlanElements)
    {
        super(context, readyMadePlanElements) ;
    }
    
    public static RefBoolean enableMagicProperties = new RefBoolean(EngineConfig.getContext(), ARQ.enablePropertyFunctions) ;
    
    // Split into blocks of triples, deal with magic properties
    
    private static List process(Context context, ElementBasicGraphPattern bgp)
    {
        boolean doingMagicProperties = enableMagicProperties.getValue() ;

        // Gather sequential triples together.
        // At end of gathering (filter or end of BGP), process for and property functions
        // then generate the PlanBlockTriples/PlanPropertyFunction
        
        List planBGPElements = new ArrayList() ;            // The elements of the PlanBGP
        List propertyFunctionTriples = new ArrayList() ;    // Property functions seen (current block)
        // TODO Parallel execution      
        PropertyFunctionRegistry registry = PFuncOps.chooseRegistry(context) ;
        
        List triples = new ArrayList() ;                    // current block of triples
        
        for ( Iterator iter = bgp.getElements().iterator() ; iter.hasNext() ; )
        {
            Object obj = iter.next() ;
            
            if ( obj instanceof ElementTriplePattern )
            {
                ElementTriplePattern eTriple = (ElementTriplePattern)obj ;
                Triple t = eTriple.getTriple() ;
                triples.add(t) ;
                if ( doingMagicProperties && PFuncOps.isMagicProperty(registry, t) )
                    propertyFunctionTriples.add(t) ;
                continue ;
            }
            
            if ( obj instanceof ElementFilter )
            {
                finishTriples(context, registry, planBGPElements, triples, propertyFunctionTriples) ;
                if ( triples.size()!=0 || propertyFunctionTriples.size()!=0 )
                    log.warn("finishTriples left some things behind") ;
                
                ElementFilter pf = (ElementFilter)obj ;
                PlanElement e = QueryPatternCompiler.makePlan(context, pf) ;
                planBGPElements.add(e) ;
                continue ;
            }
            log.warn("Don't recognize: ["+Utils.className(obj)+"]") ;
        }
        // Process last block of triples
        finishTriples(context, registry, planBGPElements, triples, propertyFunctionTriples) ;
        if ( triples.size()!=0 || propertyFunctionTriples.size()!=0 )
            log.warn("finishTriples left some things behind") ;
        return planBGPElements ;
    }
    
    
    // Must empty the lists
    private static void finishTriples(Context context, PropertyFunctionRegistry registry,
                                      List planBGPElements, List triples, List pfTriples)
    {
        if ( triples.size() == 0 )
            return ;
        
        if ( pfTriples.size() == 0 )
        {
            PlanBlockTriples pBlk = new PlanBlockTriples(context) ;
            pBlk.getPattern().addAll(triples) ;
            planBGPElements.add(pBlk) ;
            triples.clear() ;
            return ;
        }
        
        // Stage 1: remove any additional triples due to list arguments of property functions
        Map pfPlanElts = new HashMap() ;     // In parallel with pfTriples
        for ( Iterator iter = pfTriples.iterator() ; iter.hasNext(); )
        {
            Triple pf = (Triple)iter.next();
            
            PlanElement planElt = PFuncOps.magicProperty(context, registry, pf, triples) ;
            if ( planElt == null )
            {
                log.warn("Lost a PlanElement for a property function") ;
                continue ;
            }
            pfPlanElts.put(pf, planElt) ;
        }
        
        PlanBlockTriples pBlk = new PlanBlockTriples(context) ;
        // Stage 2: buid the PlanElements list : PlanBlockTriples/PlanPropertyFunction/PlanBlockTriples
        for ( Iterator iter = triples.iterator() ; iter.hasNext(); )
        {
            Triple t = (Triple)iter.next() ;
            if ( ! pfTriples.contains(t) )
            {
                pBlk.addTriple(t) ;         // Plain triple
                continue ;
            }
            PlanElement planElt = (PlanElement)pfPlanElts.get(t) ;
            pfTriples.remove(t) ;
            
            if ( pBlk.getPattern().size() > 0 )
            {
                planBGPElements.add(pBlk) ;
                pBlk = new PlanBlockTriples(context) ;
            }
            planBGPElements.add(planElt) ;
        }
        triples.clear() ;
        if ( pfTriples.size() > 0 )
            log.warn("Property function triples remain: "+pfTriples) ;
        
        // Complete last block (trailing triples after a property function)
        if ( pBlk.getPattern().size() > 0 )
        {
            planBGPElements.add(pBlk) ;
            //pBlk = new PlanBlockTriples(context) ;
        }
    }

    public QueryIterator build(QueryIterator input, ExecutionContext execCxt)
    {
        return PlanUtils.buildSerial(this, input, execCxt) ;
    }
    
    public void visit(PlanVisitor visitor) { visitor.visit(this) ; }
    
    public PlanElement apply(Transform transform, List newSubElements)
    { return transform.transform(this, newSubElements) ; }

    public PlanElement copy(List newSubElements)
    {
        return new PlanBasicGraphPattern(getContext(), newSubElements) ;
    }
}

/*
 * (c) Copyright 2005, 2006 Hewlett-Packard Development Company, LP
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in the
 *    documentation and/or other materials provided with the distribution.
 * 3. The name of the author may not be used to endorse or promote products
 *    derived from this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE AUTHOR ``AS IS'' AND ANY EXPRESS OR
 * IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES
 * OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED.
 * IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR ANY DIRECT, INDIRECT,
 * INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT
 * NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
 * DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
 * THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
 * (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF
 * THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */