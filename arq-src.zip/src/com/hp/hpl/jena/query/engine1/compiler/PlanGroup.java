/*
 * (c) Copyright 2005, 2006 Hewlett-Packard Development Company, LP
 * All rights reserved.
 * [See end of file]
 */

package com.hp.hpl.jena.query.engine1.compiler;

import java.util.*;

import org.apache.commons.logging.*;

import com.hp.hpl.jena.graph.Triple;
import com.hp.hpl.jena.query.ARQ;
import com.hp.hpl.jena.query.core.ElementExtension;
import com.hp.hpl.jena.query.engine.QueryIterator;
import com.hp.hpl.jena.query.engine1.*;
import com.hp.hpl.jena.query.engine1.analyse.AnalyseFilters;
import com.hp.hpl.jena.query.engine1.analyse.AnalyseOrderSets;
import com.hp.hpl.jena.query.engine1.analyse.VarUsageVisitor;
import com.hp.hpl.jena.query.expr.Expr;
import com.hp.hpl.jena.query.util.ExprUtils;
import com.hp.hpl.jena.query.util.RefBoolean;

public class PlanGroup extends PlanElementBase
{
    static Log log = LogFactory.getLog(PlanGroup.class) ;
    public static boolean enableOrderWarnings = true ;

    
    // Includes triple pattern to base pattern compression 
    List planElements = new ArrayList() ;
    //List planElements = null ;
    private boolean canReorder = true ;
    
    public static PlanElement make(Plan plan, List acc)
    {
        if ( acc.size() == 1 && !( acc.get(0) instanceof PlanTriplePattern ) )
            return (PlanElement)acc.get(0) ;
        
        return new PlanGroup(plan, acc, true) ;
    }
    
    public static PlanGroup make(Plan plan, List acc, boolean reorderable)
    {
        return new PlanGroup(plan, acc, reorderable) ;
    }
    
    public boolean canReorder() { return canReorder ; }
    
    private PlanGroup(Plan plan, List subElts, boolean reorderable)
    {
        super(plan) ;
        planElements = subElts ;
        canReorder = reorderable ;

        // TODO Generalize this to a query rewriter.
        // Stage one - notice magic properties
        rewriteMagicProperties(planElements, plan) ;
        
        // Stage two - rearrange triple patterns in basic patterns
        // Always do this.
        planElements = compressBasicPatterns(planElements, plan) ;
        
        if ( plan.getContext().isTrue(ARQ.orderPlanning) )
            planGroup() ;
    }
    
    private void planGroup()
    {
        if ( ! canReorder )
            return ;

        // Stage two - sort in execution order
        // Fixed patterns, unions, single optionals, equivalence set optionals.
        // Unions count as fixed or optionals (they give the right answers
        // and don't mask) but are after because fixed patterns are (guessed) to be
        // more selective.
        
        AnalyseOrderSets aOpt = new AnalyseOrderSets(this) ;
        if ( false )
           warnOrderDependence(aOpt) ;
        
        planElements = aOpt.reorder() ;
        
        // Stage three - put in filters
        AnalyseFilters aFlt = new AnalyseFilters(this) ;
        planElements = aFlt.reorder() ;

    }
    
    public List getPlanElements() { return planElements ; }
    //public ElementGroup getGroupElement() { return element ; }
    
    public QueryIterator build(QueryIterator input, ExecutionContext execCxt)
    {
        if ( planElements.size() == 0 )
            return input ;
        
        // Does not inc the mark depth because this does not create an iterator itself. 
        
        // Nesting on one item.
        if ( planElements.size() == 1 )
        {
            PlanElement e = (PlanElement)planElements.get(0) ;
            if ( log.isDebugEnabled() )
                log.debug("New group stage (1 step)") ;
            return e.build(input, execCxt) ;
        }

        int count = 0 ;
        
        // A Group execution is the execution of each element with
        // the results from one fed into the next. 
        Iterator elementsIterator = planElements.listIterator() ;
        QueryIterator chain = input ;     // Results of previous stage.
        while(elementsIterator.hasNext() )
        {
            count++ ;
            PlanElement element = (PlanElement)elementsIterator.next() ;
            
            // Occurs is some subclass query engine nulls out a slot.
            if ( element == null )
            {
                //log.info("Null slot ("+count+")") ;
                continue ;
            }
           
            if ( log.isDebugEnabled() )
                log.debug("New group stage") ;
            QueryIterator cIter = element.build(chain, execCxt) ;
            chain = cIter ;
        }
        // Return tail of chain - it will pull the rest through. 
        return chain ;
    }
 
    public void visit(PlanVisitor visitor) { visitor.visit(this) ; }
    
    public static RefBoolean enableMagicProperties = new RefBoolean(EngineConfig.getContext(), ARQ.enablePropertyFunctions) ;
    
    private void rewriteMagicProperties(List pElts, Plan plan)
    {
        if ( ! enableMagicProperties.getValue() )
            return ;
        
        // Get from the Plan context
        PropertyFunctionRegistry registry =
            (PropertyFunctionRegistry)plan.getContext().get(EngineConfig.registryMagicProperties) ;
        if ( registry == null )
            registry = PropertyFunctionRegistry.get() ;
        
        for ( int i = 0 ; i< pElts.size() ; i++ )
        {
            PlanElement e = (PlanElement)pElts.get(i) ;
            if ( e instanceof PlanTriplePattern )
            {
                PlanTriplePattern etp = (PlanTriplePattern)e ;
                Triple t = etp.getTriple() ;
                if ( registry.contains(t.getPredicate()) )
                {
                    // Why do we need this indirection?
                    // Could simply lookup in the extension regsitry
                    // so don't end up with thwo names - the property function name
                    // and the extension name.
                    // Minor - it means that java: loading of the extension gets a chance
                    // to operate.
                    
                    String extURI = registry.get(t.getPredicate()) ;
                    List args = new ArrayList() ; // expressions
                    
                    Expr sExpr = ExprUtils.nodeToExpr(t.getSubject()) ;
                    Expr oExpr = ExprUtils.nodeToExpr(t.getObject()) ;
                    
                    args.add(sExpr) ;
                    args.add(oExpr) ;
                    
                    ElementExtension eExt = new ElementExtension(extURI, args, null) ;
                    PlanElement e2 = PlanExtension.make(plan, eExt) ;
                    pElts.set(i, e2) ;
                }
            }
        }
    }
    
    private List compressBasicPatterns(List pElts, Plan plan)
    {
        List newPlanElements = new ArrayList() ;
        // Convert consecutive triple patterns in base patterns
        // Replace unused slots with a null (removed later)
        for ( int i = 0 ; i< pElts.size() ; i++ )
        {
            PlanElement e = (PlanElement)pElts.get(i) ;
            
            if ( ! ( e instanceof PlanTriplePattern ) )
            {
                newPlanElements.add(e) ; 
            }
            else
            {
                PlanTriplePattern etp = (PlanTriplePattern)e ;
                PlanBasicPattern basePatterns = new PlanBasicPattern(getPlan()) ;
                // Do i'th one.
                basePatterns.getPattern().add(etp.getTriple()) ;
                newPlanElements.add(basePatterns) ;
                
                // Start gathering
                int j = i+1 ;
                for (  ; j < pElts.size() ; j++ )
                {
                    PlanElement e2 = (PlanElement)pElts.get(j) ;
                    if ( e2 instanceof PlanTriplePattern )
                    {
                        PlanTriplePattern etp2 = (PlanTriplePattern)e2 ;
                        basePatterns.addTriple(etp2.getTriple()) ;
                    }
                    else
                    {
                        // Not a triple pattern - but is it a simple regex filter? 
                        boolean handled = GroupUtils.optimizableConstraint(basePatterns, e2, plan) ;
                        if ( !handled  )
                            newPlanElements.add(e2) ;
                        // No more PlanTriplePattern in this basic block
                        break ;
                    }
                }
                // Reset the scanning index
                // We know current j is not a ElementTriplePattern
                // or we ran to the end of the list
                i = j ;
            }
        }
        return newPlanElements ; 
    }
   
    private void warnOrderDependence(AnalyseOrderSets a)
    {
        for ( Iterator iter = a.getEquivalenceSets().iterator() ; iter.hasNext() ; )
        {
            Set r = (Set)iter.next() ;
            if ( enableOrderWarnings && r.size() != 1 )
            {
                log.warn("Potential order dependence") ;
                for ( Iterator pEltIter = r.iterator() ; pEltIter.hasNext() ; )
                {
                    PlanElement e = (PlanElement)pEltIter.next() ;
                    PlanFormatter.out(System.out, e) ;
                }
            }
        }
    }
    
    public void varsReport()
    {
        // -------------- Variables mentioned
        
        VarUsageVisitor varUsage = new VarUsageVisitor() ;
        this.visit(varUsage) ;
    
        System.out.println() ;
        System.out.print("Fixed:  ") ;
        for ( Iterator iter = varUsage.getFixedUsageVars().iterator() ; iter.hasNext() ; )
        {
            String vn = (String)iter.next() ;
            System.out.print(" "+vn) ;
        }
        System.out.println() ;
        System.out.print("Varying:") ;
        for ( Iterator iter = varUsage.getOptionalUsageVars().iterator() ; iter.hasNext() ; )
        {
            String vn = (String)iter.next() ;
            System.out.print(" "+vn) ;
        }
        System.out.println() ;
        System.out.print("Constrained:") ;
        for ( Iterator iter = varUsage.getConstraintUsageVars().iterator() ; iter.hasNext() ; )
        {
            String vn = (String)iter.next() ;
            System.out.print(" "+vn) ;
        }
        System.out.println() ;
    }
}

/*
 * (c) Copyright 2005, 2006 Hewlett-Packard Development Company, LP
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in the
 *    documentation and/or other materials provided with the distribution.
 * 3. The name of the author may not be used to endorse or promote products
 *    derived from this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE AUTHOR ``AS IS'' AND ANY EXPRESS OR
 * IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES
 * OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED.
 * IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR ANY DIRECT, INDIRECT,
 * INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT
 * NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
 * DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
 * THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
 * (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF
 * THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */