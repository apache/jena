/*
 * (c) Copyright 2005, 2006 Hewlett-Packard Development Company, LP
 * All rights reserved.
 * [See end of file]
 */

package com.hp.hpl.jena.query.engine1.analyse;

import java.util.*;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

//import com.hp.hpl.jena.query.core.*;

import com.hp.hpl.jena.query.engine1.PlanElement;
import com.hp.hpl.jena.query.engine1.PlanFormatter;
import com.hp.hpl.jena.query.engine1.compiler.*;
import com.hp.hpl.jena.shared.PrefixMapping;


public class AnalyseFilters
{
    static Log log = LogFactory.getLog(AnalyseFilters.class) ;
    // Input
    PlanGroup planGroup ;
    
    List basePlanElements = new ArrayList() ;
    List filterPlanElements = new ArrayList() ;
    List unknownFilterPlanElements = new ArrayList() ;
    List otherPlanElements = new ArrayList() ;
    List ordered = new ArrayList() ;
    
    public AnalyseFilters(PlanGroup cElt)
    {
        planGroup = cElt ;
        buildStructures() ;
        analyse() ;
    }

    private void buildStructures()
    {
        for ( Iterator iter = planGroup.getPlanElements().iterator() ; iter.hasNext() ; )
        {
            PlanElement e = (PlanElement)iter.next() ;
            if ( e instanceof PlanTriplePattern )
            {                
                PlanTriplePattern tp = (PlanTriplePattern)e ;
                basePlanElements.add(tp) ;
                continue ;
            }
            if ( e instanceof PlanBasicPattern )
            {                
                PlanBasicPattern bp = (PlanBasicPattern)e ;
                basePlanElements.add(bp) ;
                continue ;
            }
            if ( e instanceof PlanFilter )
            {                
                PlanFilter pc = (PlanFilter)e ;
                filterPlanElements.add(pc) ;
//                for ( Iterator iter2 = pc.getConstraints().iterator() ; iter2.hasNext() ; )
//                {
//                    Constraint c = (Constraint)iter2.next() ;
//                }
                continue ;
            }
            
            otherPlanElements.add(e) ;
        }
    }

    private void analyse()
    {
        Set varsFixed = new HashSet() ;
        // Need an insertion step before, between and after all triples
        insertFilters(varsFixed) ;
        
        // This only copes with fixed vars
        // Tie to the structures built by AnalyseOrderSets 
        for ( Iterator iter = basePlanElements.iterator() ; iter.hasNext() ; )
        {
            PlanBasicPattern p = (PlanBasicPattern)iter.next() ;
            //Set x = PlanVarsMentioned.varMentioned(p) ;0
            //varsFixed.addAll(x) ;
            VarUsageVisitor v = new VarUsageVisitor() ;
            p.visit(v) ;
            varsFixed.addAll(v.getFixedUsageVars()) ;
            ordered.add(p) ;
            insertFilters(varsFixed) ;
        }
        // Add remaining, including filters that depend on optional variables.
        unknownFilterPlanElements.addAll(filterPlanElements) ;
        
//        // safe-but-silly
//        ordered.addAll(triples) ;
//        ordered.addAll(filters) ;
    }
    
    private void insertFilters(Set varsFixed)
    {
        for ( Iterator iter2 = filterPlanElements.iterator() ; iter2.hasNext() ; )
        {
            PlanFilter pc = (PlanFilter)iter2.next() ;
            Set z = PlanVarsMentioned.varMentioned(pc) ;
            if ( varsFixed.containsAll(z) )
            {
                ordered.add(pc) ;
                iter2.remove() ;
            }
        }
    }

    public void report(PrefixMapping pmap)
    {
        List x = reorder() ;
        for ( Iterator iter = x.iterator() ; iter.hasNext() ; )
        {
            PlanElement p = (PlanElement)iter.next() ;
            PlanFormatter.out(System.out, pmap, p) ;
        }
    }
    
    public List reorder()
    {
        List x = new ArrayList() ;
        x.addAll(ordered) ;
        x.addAll(otherPlanElements) ;
        x.addAll(unknownFilterPlanElements) ;
        return x ;
    }
}

/*
 * (c) Copyright 2005, 2006 Hewlett-Packard Development Company, LP
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in the
 *    documentation and/or other materials provided with the distribution.
 * 3. The name of the author may not be used to endorse or promote products
 *    derived from this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE AUTHOR ``AS IS'' AND ANY EXPRESS OR
 * IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES
 * OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED.
 * IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR ANY DIRECT, INDIRECT,
 * INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT
 * NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
 * DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
 * THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
 * (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF
 * THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */