/*
 * (c) Copyright 2005, 2006 Hewlett-Packard Development Company, LP
 * All rights reserved.
 * [See end of file]
 */

package com.hp.hpl.jena.query.engine1.compiler;

import java.util.Collection;
import java.util.regex.Pattern;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import com.hp.hpl.jena.graph.Node;
import com.hp.hpl.jena.graph.query.* ;
import com.hp.hpl.jena.query.core.Binding;
import com.hp.hpl.jena.query.engine1.ExecutionContext;
import com.hp.hpl.jena.query.expr.*;
import com.hp.hpl.jena.query.util.Utils;
import com.hp.hpl.jena.shared.JenaException;

/** A regular expression with additional support for evaluation inside
 * a Jena graph query handler.
 * 
 * @author Andy Seaborne
 * @version $Id: JenaRegex.java,v 1.14 2006/08/12 19:43:14 andy_seaborne Exp $
 */ 

public class JenaRegex implements Expression, Valuator
{
    private static Log log = LogFactory.getLog(JenaRegex.class) ;
    public static String regexSystem =   ExpressionFunctionURIs.Q_StringMatch ;
    public static String regexLanguage = PatternLiteral.rdql ;
    
    E_Regex regex ;                         // The original expression node.
    // regex(var, pattern literal(pattern, flags)) 
    
    JenaVar var;                                // Left/0th argument
    PatternLiteralImpl patternLiteral ;     // Right/1st argument

    JenaRegex(E_Regex regex, String var, String pat, String flags)
    { 
        if ( flags == null )
            flags = "" ;
        this.regex = regex ;
        this.var = new JenaVar(var) ;
        this.patternLiteral = new PatternLiteralImpl(pat, flags) ;
    }
    
    public boolean isApply()         { return true ; }
    public String getFun()           { return regexSystem ; }
    public int argCount()            { return 2; }
    
    public Expression getArg(int i)  
    {
        if ( i == 0 )
            return var ;
        if ( i == 1 )
            return patternLiteral ;
        return null;
    }

    // ---- Jena graph.query.Expression
    
    public boolean isVariable()      { return false; }
    public String getName()          { return null; } // For variables only

    public boolean isConstant()      { return false; }
    public Object getValue()         { return null; } // For constants

    public Valuator prepare(VariableIndexes vi)
    {
        var.prepare(vi) ;
        patternLiteral.prepare(vi) ;
        return this ;
    }

    // ---- Jena graph.query.Valuator

    /**
        Answer the result of evaluating the constraint expression; implements
        Expression.evalObject(*).
    */
    public Object evalObject( IndexValues iv )
    {
        log.warn("Unexpexpected call to "+Utils.className(this)+".evalObject - expected only evalBool calls") ;
        boolean b = evalBool(iv) ;
        return new Boolean(b) ;
    }

    /**
        Answer the result of evaluating the constraint expression as a
        primitive boolean value; implements Expression.evalBool(*).
    */
    public boolean evalBool( IndexValues iv )
    {
        Object obj = var.evalObject(iv) ;
        Node n = (Node)obj ;

        if ( log.isDebugEnabled() )
            log.debug("evalBool "+patternLiteral.getPatternString()+" // "+n) ;
        
        // Errors become "false" because this implementation is for a
        // filter of a single regular expression.
        
        if ( ! n.isLiteral() )  
            return false ;                      //throw new ExprEvalException("Not a string: "+n+" (regex)") ;
        if ( n.getLiteralDatatypeURI() != null )
            return false ;                      //throw new ExprEvalException("Not a plain string: "+n+" (regex)") ;
        if ( n.getLiteralLanguage() != null && ! n.getLiteralLanguage().equals("") )
            return false ;                      //throw new ExprEvalException("String with lang tag: "+n+" (regex)") ;
        
        RegexEngine engine = null ;
        try {
            engine = E_Regex.makeRegexEngine(patternLiteral.getPatternString(),  patternLiteral.getPatternModifiers()) ;
        } catch (Exception pEx)
        { throw new JenaException("JenaRegex: Pattern exception: "+pEx) ; }
        String xx = n.getLiteralLexicalForm() ;
        boolean b = engine.match(xx) ;
        return b  ;
    }

    // Worker
    static private int getMask(String mod)
    {
        if ( mod == null  )
            return 0 ;
        int mask = 0 ;
        for ( int i = 0 ; i < mod.length() ; i++ )
        {
            switch(mod.charAt(i))
            {
//                case 'i' : mask |= Perl5Compiler.CASE_INSENSITIVE_MASK; break;
//                case 'm' : mask |= Perl5Compiler.MULTILINE_MASK; break;
//                case 's' : mask |= Perl5Compiler.SINGLELINE_MASK; break;
//                case 'x' : mask |= Perl5Compiler.EXTENDED_MASK; break;
                
                //case 'i' : mask |= Pattern.CASE_INSENSITIVE;     break ;
                case 'i' :
                    mask |= Pattern.UNICODE_CASE ;
                    mask |= Pattern.CASE_INSENSITIVE;
                    break ;
                case 'm' : mask |= Pattern.MULTILINE ;           break ;
                case 's' : mask |= Pattern.DOTALL ;              break ;
                //case 'x' : mask |= Pattern.;  break ;

                // Parser should catch this.
                //default  :
            }
        }
        return mask ;
    }

    
    // ---- ARQ expr.Constraint interface
    public boolean isSatisfied(Binding binding, ExecutionContext execCxt)
    {
        //System.err.println("JenaRegex.isSatisfied") ;
        return regex.isSatisfied(binding, execCxt) ;
    }

    public void varsMentioned(Collection acc)
    {
        acc.add(var.getName()) ;
    }
    
    public String toString()
    {
        return regex.toString() ;
    }

    public boolean isExpr() { return false ; }

    public Expr getExpr() { return null ; }
}

class PatternLiteralImpl extends Expression.Base implements PatternLiteral, Valuator
{
    String pattern ;
    String modifiers ;
    
    PatternLiteralImpl(String pat, String mod) { pattern = pat ; modifiers = mod ; }
    
    public String getPatternString()       { return pattern; }
    public String getPatternModifiers()    { return modifiers ; }
    public String getPatternLanguage()     { return JenaRegex.regexLanguage ; }

    public Valuator prepare(VariableIndexes vi)  { return this ; }
    
    public boolean evalBool(IndexValues iv)      
    {
        LogFactory.getLog(PatternLiteralImpl.class).warn("Unexpected call to .evalBool") ;
        return false ;
    }
    public Object evalObject(IndexValues iv)
    { 
        LogFactory.getLog(PatternLiteralImpl.class).warn("Unexpected call to .evalObject") ;
        return this ;
    }
}

class JenaVar extends Expression.Variable implements Valuator
{
    VariableIndexes varIndexes ;
    String varName ;
    int index ;
    
    JenaVar(String name) { this.varName = name ; }
    //@Override
    public String getName() { return varName ; }

    // graph.query.Expression
    public Valuator prepare(VariableIndexes vi)
    {
        varIndexes = vi ;
        index = vi.indexOf(varName) ;
        return this ;
    }
    
    public boolean evalBool(IndexValues iv)
    { 
        LogFactory.getLog(JenaVar.class).warn("Unexpected call to .evalBool") ;
        return false ;
    }
    
    public Object evalObject(IndexValues iv)
    {
        Object obj = iv.get(index) ; 
        return obj ;
    }
}

/*
 * (c) Copyright 2005, 2006 Hewlett-Packard Development Company, LP
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in the
 *    documentation and/or other materials provided with the distribution.
 * 3. The name of the author may not be used to endorse or promote products
 *    derived from this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE AUTHOR ``AS IS'' AND ANY EXPRESS OR
 * IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES
 * OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED.
 * IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR ANY DIRECT, INDIRECT,
 * INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT
 * NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
 * DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
 * THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
 * (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF
 * THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */