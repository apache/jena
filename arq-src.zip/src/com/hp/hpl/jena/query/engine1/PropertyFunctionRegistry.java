/*
 * (c) Copyright 2005, 2006 Hewlett-Packard Development Company, LP
 * All rights reserved.
 * [See end of file]
 */

package com.hp.hpl.jena.query.engine1;

import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;

import com.hp.hpl.jena.graph.Node;
import com.hp.hpl.jena.query.Constants;
import com.hp.hpl.jena.query.vocabulary.ListMember;
import com.hp.hpl.jena.rdf.model.RDFNode;
import com.hp.hpl.jena.vocabulary.RDFS;

// Move PropertyFunctionRegistry somewhere?
public class PropertyFunctionRegistry
{
    static PropertyFunctionRegistry globalRegistry = null ;
    Map registry = new HashMap() ;  // Node => String
    
    public synchronized static PropertyFunctionRegistry standardRegistry()
    {
        PropertyFunctionRegistry reg = new PropertyFunctionRegistry() ;
        reg.loadStdDefs() ;
        return reg ;
    }

    public synchronized static PropertyFunctionRegistry get()
    {
        // Intialize if there is no registry already set 
        PropertyFunctionRegistry reg = 
            (PropertyFunctionRegistry)EngineConfig.getContext().get(EngineConfig.registryMagicProperties) ;
        if ( reg == null )
        {
            reg = standardRegistry() ;
            EngineConfig.getContext().set(EngineConfig.registryMagicProperties, reg) ;
        }
        return reg ;
    }
    
    private void loadStdDefs()
    {
        // TODO add SWAP list :in 
        //http://www.w3.org/2000/10/swap/list#in
        
        put(ListMember.member.asNode(),
                Constants.javaClassPrefix+"com.hp.hpl.jena.query.extension.library.list") ;
        put(RDFS.member.asNode(),
                Constants.javaClassPrefix+"com.hp.hpl.jena.query.extension.library.container") ;
    }
    
    /** Register a magic property and the backing extension URI. 
     *  Re-registering overwrites the old entry. 
     * 
     * @param uri          String URI for the extension
     * @param extension    Extension URI
     */
    public void put(String uri, String extension) { registry.put(Node.createURI(uri),extension) ; }

    private void put(Node node, String extension) { registry.put(node, extension) ; }

    /** Lookup by URI */
    public String get(String uri)
    { 
        return get(Node.create(uri)) ;
    }
    
    // Handling of "java:" property functions  is not done in the PropertyFunctionRegistry
    // see PropertyFunctions.magirProperties
    
    /** Lookup by node */
    public String get(Node node)
    { 
        return (String)registry.get(node) ;
    }
    
    /** Lookup by Property */
    public String get(RDFNode p)    { return get(p.asNode()) ; }

    /** Check by URI */
    public boolean contains(String uri)  { return contains(Node.create(uri)) ; }
    
    /** Check by node */
    public boolean contains(Node node)   { return registry.containsKey(node) ; }
    
    /** Check by Property */
    public boolean contains(RDFNode p)    { return contains(p.asNode()) ; }
    
    /** Remove by URI */
    public String remove(String uri) { return remove(Node.create(uri)) ; } 

    /** Remove by URI */
    public String remove(Node node) { return (String)registry.remove(node) ; } 
    
    /** Remove by URI */
    public String remove(RDFNode p) { return remove(p.asNode()) ; } 
    

    
    /** Iterate over URIs */
    public Iterator keys() { return registry.keySet().iterator() ; }

    
}

/*
 * (c) Copyright 2005, 2006 Hewlett-Packard Development Company, LP
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in the
 *    documentation and/or other materials provided with the distribution.
 * 3. The name of the author may not be used to endorse or promote products
 *    derived from this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE AUTHOR ``AS IS'' AND ANY EXPRESS OR
 * IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES
 * OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED.
 * IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR ANY DIRECT, INDIRECT,
 * INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT
 * NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
 * DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
 * THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
 * (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF
 * THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */