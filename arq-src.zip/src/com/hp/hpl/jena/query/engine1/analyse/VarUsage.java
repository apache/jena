/*
 * (c) Copyright 2005, 2006 Hewlett-Packard Development Company, LP
 * All rights reserved.
 * [See end of file]
 */

package com.hp.hpl.jena.query.engine1.analyse;

import java.util.HashSet;
import java.util.Iterator;
import java.util.Set;

import org.apache.commons.logging.LogFactory;

import com.hp.hpl.jena.graph.Node;
import com.hp.hpl.jena.graph.Triple;
import com.hp.hpl.jena.query.core.ARQInternalErrorException;
import com.hp.hpl.jena.query.engine1.PlanElement;
import com.hp.hpl.jena.query.engine1.PlanVisitor;
import com.hp.hpl.jena.query.engine1.plan.*;

public class VarUsage
{
    // ---- Structures
    // In every solution
     Set fixedUsageVars ;
    
    // May not be in every solution
    private Set optionalUsageVars ;
    
    // Constraints
    private Set constraintUsageVars ;

    public VarUsage()
    {
        this(new HashSet() , new HashSet() , new HashSet()) ;
    }
    
    public VarUsage(Set basicPatternVars,
                           Set optionalPatternVars,
                           Set constraintPatternVars)
    {
        this.fixedUsageVars = basicPatternVars ;
        this.optionalUsageVars = optionalPatternVars ;
        this.constraintUsageVars = constraintPatternVars ;
    }
    
    public void visit(PlanElement el) { el.visit(new Visitor()) ; }

    
    
    class Visitor implements PlanVisitor
    {
    // Basic patterns
    public void visit(PlanBlockTriples planElt)
    {
        for ( Iterator iter = planElt.triples() ; iter.hasNext() ; )
        {
            Triple t = (Triple)iter.next() ;
            addVarsFromTriple(fixedUsageVars, t) ;
            delVarsFromTriple(optionalUsageVars, t) ;
        }
    }

    public void visit(PlanBasicGraphPattern planElt)
    {
        for ( Iterator iter = planElt.iterator() ; iter.hasNext() ; )
        {
            PlanElement e = (PlanElement)iter.next() ;
            // Just pass in self because the right members are updated
            e.visit(this) ;
        }
    }
    
    public void visit(PlanTriplePattern planElt)
    {
        Triple t = planElt.getTriple() ;
        addVarsFromTriple(fixedUsageVars, t) ;
        delVarsFromTriple(optionalUsageVars, t) ;
    }

    // Graph combinations
    public void visit(PlanGroup planElt)
    {
        for ( Iterator iter = planElt.iterator() ; iter.hasNext() ; )
        {
            PlanElement e = (PlanElement)iter.next() ;
            // Just pass in self because the right members are updated
            e.visit(this) ;
        }
    }
    
    //  Create sub visitor - add to constraints

    // A vraibale is fixed even if mentioned in just one branch because all branches are tried,
    // hence no shadowing effects arise.
    
    public void visit(PlanUnion planElt)
    {
          for ( Iterator iter = planElt.getSubElements().iterator() ; iter.hasNext() ; )
          {
              PlanElement e = (PlanElement)iter.next() ;
              e.visit(this) ;
          }
    }
    
    // Create sub visitor - move fixed & optionals in to in this.options
    // Need to fix up for outer fixed vars in enclosing group
    public void visit(PlanOptional planElt)
    {
        // Fixed.
        if ( planElt.getFixed() != null )
            planElt.getFixed().visit(this) ;
        
        // Optional.
        
        VarUsage v = new VarUsage() ;
        v.visit(planElt.getOptional()) ;

        // Set different: v.getFixedUsageVars() \ this.getFixedUsageVars()
        v.getOptionalUsageVars().addAll(v.getFixedUsageVars()) ;
        v.getOptionalUsageVars().removeAll(this.getFixedUsageVars()) ;
        this.getOptionalUsageVars().addAll(v.getOptionalUsageVars()) ;
        
    }

    //  Create sub visitor - add to constraints  
    public void visit(PlanUnsaid planElt)
    {
        VarUsage v = new VarUsage(constraintUsageVars,
                                  constraintUsageVars,
                                  constraintUsageVars) ;
        v.visit(planElt.getSubElement()) ;
    }
    
    public void visit(PlanFilter planElt)
    {
        planElt.getExpr().varNamesMentioned(constraintUsageVars) ;
    }
    
    // Add node to fixed and recurse
    public void visit(PlanNamedGraph planElt)
    {
        Node n = planElt.getElement().getGraphNameNode() ;
        addVar(this.getFixedUsageVars(), n) ;
        planElt.getSubElement().visit(this) ;
    }
    

    public void visit(PlanOuterJoin planElt)
    {
        // This should not be called?
        LogFactory.getLog(VarUsage.class).warn("PlanOuterJoin - VarUsage - Should not be called" ) ;
        for ( Iterator iter = planElt.getPlanElements().iterator() ; iter.hasNext() ; )
        {
            PlanElement e = (PlanElement)iter.next() ;
            e.visit(this) ;
        }
    }


    // Other
    public void visit(PlanPropertyFunction planElt) {}
    public void visit(PlanExtension planElt) {}
    public void visit(PlanDataset planElt)   {}
    public void visit(PlanElementExternal planElt)
    { throw new ARQInternalErrorException("PlanExternal encountered") ; }

    
    // Solution sequence modifiers
    public void visit(PlanDistinct planElt) {}
    public void visit(PlanProject planElt) {}
    public void visit(PlanOrderBy planElt) {}
    public void visit(PlanLimitOffset planElt) {}

    
    private void addVarsFromTriple(Set acc, Triple t)
    {
        addVar(acc, t.getSubject()) ;
        addVar(acc, t.getPredicate()) ;
        addVar(acc, t.getObject()) ;
    }
    
    private void addVar(Set acc, Node n)
    {
        if ( n == null )
            return ;
        
        if ( n.isVariable() )
            acc.add(n.getName()) ;
    }
    
    private void delVarsFromTriple(Set acc, Triple t)
    {
        delVar(acc, t.getSubject()) ;
        delVar(acc, t.getPredicate()) ;
        delVar(acc, t.getObject()) ;
    }

    private void delVar(Set acc, Node n)
    {
        if ( n == null )
            return ;
        
        if ( n.isVariable() )
            acc.remove(n.getName()) ;
    }

    /** @return Returns the basicPatternVars. */
    public Set getFixedUsageVars()
    {
        return fixedUsageVars ;
    }

    /** @return Returns the constraintPatternVars. */
    public Set getConstraintUsageVars()
    {
        return constraintUsageVars ;
    }

    /** @return Returns the optionalPatternVars. */
    public Set getOptionalUsageVars()
    {
        return optionalUsageVars ;
    }
}



    public Set getConstraintUsageVars()
    {
        return constraintUsageVars ;
    }

    public Set getFixedUsageVars()
    {
        return fixedUsageVars ;
    }

    public Set getOptionalUsageVars()
    {
        return optionalUsageVars ;
    }
}

/*
 * (c) Copyright 2005, 2006 Hewlett-Packard Development Company, LP
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in the
 *    documentation and/or other materials provided with the distribution.
 * 3. The name of the author may not be used to endorse or promote products
 *    derived from this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE AUTHOR ``AS IS'' AND ANY EXPRESS OR
 * IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES
 * OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED.
 * IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR ANY DIRECT, INDIRECT,
 * INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT
 * NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
 * DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
 * THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
 * (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF
 * THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */