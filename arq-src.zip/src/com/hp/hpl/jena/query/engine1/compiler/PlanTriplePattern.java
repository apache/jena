/*
 * (c) Copyright 2005, 2006 Hewlett-Packard Development Company, LP
 * All rights reserved.
 * [See end of file]
 */

package com.hp.hpl.jena.query.engine1.compiler;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import com.hp.hpl.jena.graph.Triple;
import com.hp.hpl.jena.query.core.ElementTriplePattern;
import com.hp.hpl.jena.query.engine.QueryIterator;
import com.hp.hpl.jena.query.engine1.*;

/* This class isn't used - ElementGroup, or the SPARQL parser, should have put all
 * single triple patterns into basic graph patterns.   
 * retained "for the record" and to catch gracefully any misuse.  
 */

public class PlanTriplePattern extends PlanElementBase
{
    private static Log log = LogFactory.getLog(ElementTriplePattern.class) ;
    private static int warnCount = 0 ;
    
    ElementTriplePattern elementTriple ;

    public static PlanElement make(Plan plan, ElementTriplePattern el)
    { return new PlanTriplePattern(plan, el) ; }

    private PlanTriplePattern(Plan plan, ElementTriplePattern el)
    {
        super(plan) ;
        if ( warnCount < 10 )
            log.info("PlanTriplePattern used unexpectedly: "+el) ;
        warnCount++ ;
        elementTriple = el ;
    }
    
    public Triple getTriple() { return elementTriple.getTriple() ; }
    
    public QueryIterator build(QueryIterator input, ExecutionContext execCxt)
    {
        LogFactory.getLog(ElementTriplePattern.class).info("Odd : .build called") ;
        if ( elementTriple == null )
        {
            log.warn("Triple is null") ;
            return new QueryIterNullIterator(execCxt) ;
        }
        
        // Doesn't happen normally because the parsers creates BasicGraphPatterns
        // Might happen for a programmatically created query 
        return toBlockTriples().build(input, execCxt) ;
    } 

    public PlanBlockTriples toBlockTriples()
    {
        PlanBlockTriples cBase = new PlanBlockTriples(getPlan()) ;
        cBase.addTriple(elementTriple.getTriple()) ;
        return cBase ;
    }
    
    public void visit(PlanVisitor visitor) { visitor.visit(this) ; }
}

/*
 * (c) Copyright 2005, 2006 Hewlett-Packard Development Company, LP
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in the
 *    documentation and/or other materials provided with the distribution.
 * 3. The name of the author may not be used to endorse or promote products
 *    derived from this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE AUTHOR ``AS IS'' AND ANY EXPRESS OR
 * IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES
 * OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED.
 * IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR ANY DIRECT, INDIRECT,
 * INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT
 * NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
 * DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
 * THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
 * (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF
 * THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */