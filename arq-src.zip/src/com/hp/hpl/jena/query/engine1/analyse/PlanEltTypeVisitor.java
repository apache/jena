/*
 * (c) Copyright 2005, 2006 Hewlett-Packard Development Company, LP
 * All rights reserved.
 * [See end of file]
 */

package com.hp.hpl.jena.query.engine1.analyse;

import java.util.*;

import com.hp.hpl.jena.query.core.ARQInternalErrorException;
import com.hp.hpl.jena.query.engine1.PlanVisitor;
import com.hp.hpl.jena.query.engine1.plan.*;


public class PlanEltTypeVisitor implements PlanVisitor
{
    // Accumulators
    List fixedPlanElt    = new ArrayList();
    List optionalPlanElt = new ArrayList();
    List filterPlanElt   = new ArrayList();
    List groupPlanElt    = new ArrayList(); // Include union and group
    List otherPlanElt    = new ArrayList();
    
    public PlanEltTypeVisitor()
    { }
    
    // Basic patterns
    public void visit(PlanBlockTriples planElt)   { fixedPlanElt.add(planElt) ; }
    
    public void visit(PlanBasicGraphPattern planElt)
    { System.err.println("PlanEltTypeVisitor visits PlanBasicGraphPattern") ; }
    
    public void visit(PlanTriplePattern planElt) { fixedPlanElt.add(planElt) ; }

    public void visit(PlanGroup planElt)         { groupPlanElt.add(planElt) ; }
    public void visit(PlanUnion planElt)         { groupPlanElt.add(planElt) ; }
    
    public void visit(PlanOptional planElt)      { optionalPlanElt.add(planElt) ; }

    public void visit(PlanUnsaid planElt)        { otherPlanElt.add(planElt) ; }
    
    public void visit(PlanFilter planElt)        { filterPlanElt.add(planElt) ; }
    
    // Depend on the nature of its subelement (which is a group)  
    public void visit(PlanNamedGraph planElt)    { groupPlanElt.add(planElt) ; }
    

    public void visit(PlanOuterJoin planElt)     { groupPlanElt.add(planElt) ; }


    // Other
    public void visit(PlanExtension planElt)     { otherPlanElt.add(planElt) ; }
    public void visit(PlanDataset planElt)         { otherPlanElt.add(planElt) ; }
    public void visit(PlanElementExternal planElt)         { throw new ARQInternalErrorException("PlanExternal encountered") ; }
    
    // Solution sequence modifiers
    // NB Distinct occurs as outer join.
    public void visit(PlanDistinct planElt)      { groupPlanElt.add(planElt) ; }
    public void visit(PlanProject planElt)       { otherPlanElt.add(planElt) ; }
    public void visit(PlanOrderBy planElt)       { otherPlanElt.add(planElt) ; }
    public void visit(PlanLimitOffset planElt)   { otherPlanElt.add(planElt) ; }
}

/*
 * (c) Copyright 2005, 2006 Hewlett-Packard Development Company, LP
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in the
 *    documentation and/or other materials provided with the distribution.
 * 3. The name of the author may not be used to endorse or promote products
 *    derived from this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE AUTHOR ``AS IS'' AND ANY EXPRESS OR
 * IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES
 * OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED.
 * IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR ANY DIRECT, INDIRECT,
 * INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT
 * NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
 * DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
 * THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
 * (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF
 * THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */