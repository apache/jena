/*
 * (c) Copyright 2005, 2006 Hewlett-Packard Development Company, LP
 * All rights reserved.
 * [See end of file]
 */

package com.hp.hpl.jena.query.engine1.analyse;

import java.util.*;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

//import com.hp.hpl.jena.query.core.*;
import com.hp.hpl.jena.query.engine1.PlanElement;
import com.hp.hpl.jena.query.engine1.PlanFormatter;
import com.hp.hpl.jena.query.engine1.plan.PlanGroup;
import com.hp.hpl.jena.query.engine1.plan.PlanOuterJoin;
import com.hp.hpl.jena.shared.PrefixMapping;


public class AnalyseOrderSets
{
    static Log log = LogFactory.getLog(AnalyseOrderSets.class) ;
    
    PlanEltTypeVisitor eltTypes ; 
//    List fixedElements = new ArrayList() ;
//    List optionalElements = new ArrayList() ;
//    List filterElements = new ArrayList() ;
    
    // ------------------------------------------
    
    Map elsFixedVars = new HashMap() ; // Element => Set of vars used
    Map elsOptVars   = new HashMap() ; // Element => Set of vars used
    
    Map fixedVars    = new HashMap() ; // Var => set of plan elements, fixed vars
    Map varOpts      = new HashMap() ; // Var => set of plan elements, optional vars
    
    // Set of sets of plan elements of common reachability.
    Set equivSets = new HashSet() ; 
    
    // Input
    PlanGroup planGroup ;
    
//    static public List reorder(PlanGroup pGrp)
//    {
//        AnalyseOrderSets a = new AnalyseOrderSets(pGrp) ;
//        return a.reorder() ;
//    }
    
    public AnalyseOrderSets(PlanGroup cElt)
    {
        planGroup = cElt ;
        buildInitialStructures() ;
        analyse() ;
    }
    
    public Set getEquivalenceSets() { return equivSets ; }
    
    private void buildInitialStructures()
    {
        if ( planGroup.getSubElements().size() == 1 )
            return ;
        
        eltTypes = new PlanEltTypeVisitor() ;

        for ( Iterator iter = planGroup.iterator() ; iter.hasNext() ; )
        {
            PlanElement e = (PlanElement)iter.next() ;
            e.visit(eltTypes) ;
        }            
        
        // ---- Calculate usage of variables
        
        Set allFixedVars = new HashSet() ;
        for ( Iterator iter = planGroup.iterator() ; iter.hasNext() ; )
        {
            PlanElement e = (PlanElement)iter.next() ;
            VarUsageVisitor v = new VarUsageVisitor() ;
            e.visit(v) ;
            
            // Create element => vars used maps
            elsFixedVars.put(e, v.getFixedUsageVars()) ; 
            //          This includes the locally varying variables which may be fixed gloablly.
            elsOptVars.put(e, v.getOptionalUsageVars()) ; 
            allFixedVars.addAll(v.getFixedUsageVars()) ;
            
            // Create var => used where maps
            for ( Iterator iterFixedVar = v.getFixedUsageVars().iterator() ; iterFixedVar.hasNext() ; )
            {
                String vn = (String)iterFixedVar.next() ;
                //System.out.println("Fixed: "+vn) ;
                insert(fixedVars, vn, e) ;
            }
            
            for ( Iterator iterOptVar = v.getOptionalUsageVars().iterator() ; iterOptVar.hasNext() ; )
            {
                String vn = (String)iterOptVar.next() ;
                //System.out.println("Opt:   "+vn) ;
                insert(varOpts, vn, e) ;
            }
        }
        // In the VarUsageVisitor, variables can be both fixed and optional.
        // Remove any optionals that are also fixed.
        
        //varOpts.removeAllKeys()
        for ( Iterator iter = allFixedVars.iterator() ; iter.hasNext() ; )
        {
            String vn = (String)iter.next() ;
            //((Set)elsOptVars.get(e)).iterator()
            varOpts.remove(vn) ;
        }
    }
    
    private  void analyse()
    {
        if ( planGroup.numSubElements() == 1 )
            return ;
        //log.info("Group of "+elGroup.getElements().size()) ;
        
        // Variables we have seen so far (don't do again)
        Set seenVar = new HashSet() ;
        
        // For all optional variables do:
        for ( Iterator iter = varOpts.keySet().iterator() ; iter.hasNext() ; )
        {
            String var = (String)iter.next() ;
            //System.out.println("Opt var:"+var) ;
            // Has var been done?
            if ( seenVar.contains(var)) continue ;
            Set equiv = new HashSet() ;
            combine(equiv, var, seenVar, varOpts, elsOptVars) ;
            
            if ( equiv.size() > 0)
                equivSets.add(equiv) ;
            else
                log.warn("Found a zero sized reachabliltiy set for var ?"+var) ;
        }
    }
    
    // Recursively build the reachable elements set for varName.
    private static void combine(Set acc, String varName, Set seenVar, Map varOpts, Map elsOptVars)
    {
        // Avoid loops.
        if ( seenVar.contains(varName) )
            return ;
        
        //System.out.println("Combine/"+varName) ;
        seenVar.add(varName) ;
        
        // Get the plan elements for this variable.
        Set els = (Set)varOpts.get(varName) ;
        if ( els == null )
            // This varName is optional - fixed somewhere else
            return ;
        
        // For each element using this variable:
        for ( Iterator iter = els.iterator() ; iter.hasNext() ; )
        {
            PlanElement e = (PlanElement)iter.next() ;
            if ( acc.contains(e) )
                // May have been added because of a different variable. 
                continue ;
            acc.add(e) ;
            
            // For each variable in this element - transitively follow.
            for ( Iterator iter2 = ((Set)elsOptVars.get(e)).iterator() ; iter2.hasNext() ; )
            {
                String vn = (String)iter2.next() ;
                combine(acc, vn, seenVar, varOpts, elsOptVars) ;
            }
            
        }
    }
    
    public List reorder()
    {
        if ( planGroup.numSubElements() == 1 )
            return planGroup.getSubElements() ;

        List elements = new ArrayList() ;

        elements.addAll(eltTypes.fixedPlanElt) ;
        elements.addAll(eltTypes.groupPlanElt) ;
        elements.addAll(eltTypes.filterPlanElt) ;
//        if ( eltTypes.otherPlanElt.size() > 0 )
//        {
//            log.warn("Unknown plan elements") ;
//            for ( Iterator iter = eltTypes.otherPlanElt.iterator() ; iter.hasNext() ; )
//            {
//                PlanElement p = (PlanElement)iter.next() ;
//                System.out.println(p+"") ;
//            }
//        }
        elements.addAll(eltTypes.otherPlanElt) ;
            
            
        // ---- eltTypes.optionalPlanElt
        
        // Do optionals which reachable set is = 1
        for ( Iterator iter = equivSets.iterator() ; iter.hasNext() ; )
        {
            Set equiv  = (Set)iter.next() ;
            if ( equiv.size() == 1 )
            {
                PlanElement p = (PlanElement)equiv.iterator().next() ;
                // TODO Remove this test - it exists because a union may have optional variables and it will have been added in groupPlanElt.
                if ( !elements.contains(p) ) 
                    elements.add(p) ;
            }
            if ( equiv.size() == 0 )
                log.warn("Optional reachability set of size zero") ;
        }
        
        // Do all 
        for ( Iterator iter = equivSets.iterator() ; iter.hasNext() ; )
        {
            Set equiv  = (Set)iter.next() ;
            if ( equiv.size() > 1 )
            {
                PlanElement p = PlanOuterJoin.make(planGroup.getContext(), equiv) ;
                elements.add(p) ;
            }
        }
        return elements ;
    }
    
    public void report(PrefixMapping pmap)

    {
        if ( planGroup.numSubElements() == 1 )
            return ;
        
        //System.out.println("#Equivalence sets: "+equivSets.size()) ;
        for ( Iterator iter = equivSets.iterator() ; iter.hasNext() ; )
        {
            Set equiv  = (Set)iter.next() ;
            if ( equiv.size() == 1 )
                continue ; 
            System.out.println("Equivalence: ") ;
            
            for ( Iterator elIter = equiv.iterator() ; elIter.hasNext() ; )
            {
                PlanElement e = (PlanElement)elIter.next() ;
                PlanFormatter.out(System.out, pmap, e) ;
            }
            //System.out.println() ;
        }
        
       System.out.println() ;
        
        // Check a plan element is in exactly one equivalence set.
        for ( Iterator iter = planGroup.iterator() ; iter.hasNext() ; )
        {
            PlanElement p = (PlanElement)iter.next() ;
            int count = 0 ;
            for ( Iterator iter2 = equivSets.iterator() ; iter2.hasNext() ; )
            {
                Set equiv  = (Set)iter2.next() ;
                if ( equiv.contains(p) )
                    count++ ;
            }
            if ( count > 1)
            {
                System.out.println("Count = "+count) ;
                PlanFormatter.out(System.out, pmap, p) ;
            }
        }
        
        System.out.println() ;
        List x = reorder() ;

        System.out.println() ;
        System.out.println("Group plan:") ;
        for ( Iterator iter = x.iterator() ; iter.hasNext() ; )
        {
            PlanElement p = (PlanElement)iter.next() ;
            PlanFormatter.out(System.out, pmap, p) ;
        }
    }
    
    private void insert(Map map, Object key, Object value)
    {
        if ( map.get(key) == null )
            map.put(key, new HashSet()) ;
        ((Set)map.get(key)).add(value) ;
    }
    //        // ---- Old code - for reachability sets of optionals.
    //        
    //        for ( Iterator iter = planGroup.getPlanElements().listIterator() ; iter.hasNext() ; ) 
    //        {
    //            PlanElement e = (PlanElement)iter.next() ;
    //            if ( elsFixedVars.get(e) == null )
    //                elsFixedVars.put(e, new HashSet()) ;
    //            if ( elsOptVars.get(e) == null )
    //                elsOptVars.put(e, new HashSet()) ;
    //
    //            if ( e instanceof PlanBasePattern || e instanceof PlanTriplePattern )
    //            {
    //                Set y = PlanVarsMentioned.varMentioned(e) ;
    //                ((Set)elsFixedVars.get(e)).addAll(y) ;
    //                
    //                for ( Iterator iter2 = y.iterator() ; iter2.hasNext() ; )
    //                {
    //                    String var = (String)iter2.next() ;
    //                    if ( fixedVars.get(var) == null )
    //                        fixedVars.put(var, new HashSet()) ;
    //                    ((Set)fixedVars.get(var)).add(e) ;
    //                }
    //                continue ;
    //            }
    //            
    //            // Checking
    //            if ( e instanceof PlanOptional )
    //                continue ;
    //            if ( e instanceof PlanConstraints )
    //                continue ;
    //            if ( e instanceof PlanUnion )
    //                // Tricky
    //                continue ;
    //            if ( e instanceof PlanNamedGraph )
    //                continue ;
    //            if ( e instanceof PlanUnsaid )
    //                continue ;
    //            if ( e instanceof PlanGroup )
    //                continue ;
    //            
    //            log.info("Can't process a "+Utils.className(e)) ;
    //        }
    //        
    //        // Get the fixed vars.
    //        Set fixed = fixedVars.keySet() ;
    //        
    //        for ( Iterator iter = planGroup.getPlanElements().listIterator() ; iter.hasNext() ; ) 
    //        {
    //            PlanElement e = (PlanElement)iter.next() ;
    //            if ( e instanceof PlanOptional )
    //            {
    //                Set y = PlanVarsMentioned.varMentioned(e) ;
    //                y = SetUtils.difference(y, fixed) ;
    //                if ( y.size() == 0 )
    //                    continue ;
    //                ((Set)elsOptVars.get(e)).addAll(y) ;
    //                // For each optional variable, record var => set => element 
    //                for ( Iterator iter2 = y.iterator() ; iter2.hasNext() ; )
    //                {
    //                    String var = (String)iter2.next() ;
    //                    if ( varOpts.get(var) == null )
    //                        varOpts.put(var, new HashSet()) ;
    //                    ((Set)varOpts.get(var)).add(e) ;
    //                }
    //                continue ;
    //            }
    //        }

}

/*
 * (c) Copyright 2005, 2006 Hewlett-Packard Development Company, LP
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in the
 *    documentation and/or other materials provided with the distribution.
 * 3. The name of the author may not be used to endorse or promote products
 *    derived from this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE AUTHOR ``AS IS'' AND ANY EXPRESS OR
 * IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES
 * OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED.
 * IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR ANY DIRECT, INDIRECT,
 * INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT
 * NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
 * DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
 * THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
 * (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF
 * THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */