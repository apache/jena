/*
 * (c) Copyright 2006 Hewlett-Packard Development Company, LP
 * All rights reserved.
 * [See end of file]
 */

package com.hp.hpl.jena.query.engine1.compiler;

import java.util.ArrayList;
import java.util.List;

import com.hp.hpl.jena.graph.Triple;
import com.hp.hpl.jena.query.core.ARQConstants;
import com.hp.hpl.jena.query.core.ElementExtension;
import com.hp.hpl.jena.query.engine1.EngineConfig;
import com.hp.hpl.jena.query.engine1.PlanElement;
import com.hp.hpl.jena.query.engine1.PropertyFunctionRegistry;
import com.hp.hpl.jena.query.engine1.plan.PlanExtension;
import com.hp.hpl.jena.query.expr.Expr;
import com.hp.hpl.jena.query.util.Context;
import com.hp.hpl.jena.query.util.ExprUtils;

public class PropertyFunctions
{
   
    public static PlanElement magicProperty(Context context, Triple t)
    { return magicProperty(chooseRegistry(context), context, t) ; }
    
    public static PlanElement magicProperty(PropertyFunctionRegistry registry, Context context, Triple t)
    {
        String extURI = registry.get(t.getPredicate()) ;

        if ( extURI == null )
        {
            if ( ! t.getPredicate().isURI() ) return null ;
            if ( ! t.getPredicate().getURI().startsWith(ARQConstants.javaClassURIScheme) ) 
                return null ;
            extURI = t.getPredicate().getURI() ;
        }

        List args = new ArrayList() ; // expressions

        Expr sExpr = ExprUtils.nodeToExpr(t.getSubject()) ;
        Expr oExpr = ExprUtils.nodeToExpr(t.getObject()) ;

        args.add(sExpr) ;
        args.add(oExpr) ;

        ElementExtension eExt = new ElementExtension(extURI, args, null) ;
        PlanElement e2 = PlanExtension.make(context, eExt) ;
        return e2 ;
    }
    
    
    
    static private PropertyFunctionRegistry chooseRegistry(Context context)
    {
        // Get from the Plan context 
        PropertyFunctionRegistry registry =
            (PropertyFunctionRegistry)context.get(EngineConfig.registryMagicProperties) ;
        // Else global
        if ( registry == null )
            registry = PropertyFunctionRegistry.get() ;
        return registry ;
    }
}

/*
 * (c) Copyright 2006 Hewlett-Packard Development Company, LP
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in the
 *    documentation and/or other materials provided with the distribution.
 * 3. The name of the author may not be used to endorse or promote products
 *    derived from this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE AUTHOR ``AS IS'' AND ANY EXPRESS OR
 * IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES
 * OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED.
 * IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR ANY DIRECT, INDIRECT,
 * INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT
 * NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
 * DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
 * THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
 * (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF
 * THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */