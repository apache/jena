/*
 * (c) Copyright 2004, 2005, 2006 Hewlett-Packard Development Company, LP
 * [See end of file]
 */

package com.hp.hpl.jena.query.engine1.plan;

import java.util.* ;

import com.hp.hpl.jena.graph.Node;
import com.hp.hpl.jena.query.core.Binding;
import com.hp.hpl.jena.query.core.BindingBase;
import com.hp.hpl.jena.query.engine.QueryIterator;
import com.hp.hpl.jena.query.engine1.ExecutionContext;
import com.hp.hpl.jena.query.engine1.iterator.QueryIterConvert;

/** A binding that is fixed - used in calculating DISTINCT result sets.
 *  .hashCode and .equals are overidden for value-equals semantics.
 * 
 * @author   Andy Seaborne
 * @version  $Id: BindingImmutable.java,v 1.2 2006/06/30 14:52:45 andy_seaborne Exp $
 */


public class BindingImmutable extends BindingBase
{
    List vars ;
    List values ;
    private int calcHashCode ;    

    /**
     * @param projectVars    The projection variables.
     * @param original       Binding to use
     */
    
    public BindingImmutable(Collection projectVars, Binding original)
    {
        super(null) ; 
        this.vars = new ArrayList(projectVars) ;
        values = new ArrayList(projectVars.size()) ;
        calcHashCode = 0 ; 
        for ( Iterator iter = projectVars.iterator() ; iter.hasNext() ; )
        {
            String varName = (String)iter.next() ;
            Object n = original.get(varName) ;

            vars.add(varName) ;
            values.add(n) ; // Includes nulls.
            
            if ( n != null )
                // Independent of variable order.
                calcHashCode = calcHashCode^n.hashCode()^varName.hashCode() ; 
        }
    }
        
    protected void add1(String name, Node node)
    { throw new UnsupportedOperationException("BindingImmutable.add") ; }

    protected Iterator names1() { return vars.listIterator() ; }
    
    protected boolean contains1(String name)
    {
        Object tmp = get1(name) ;
        return tmp != null ;
    }

    protected Node get1(String name)
    {
        int i = vars.indexOf(name) ;
        if (i < 0 )
            return null ;
        return (Node)values.get(i) ;
    }

    public boolean equals(Object obj)
    {
        if ( obj == null )
            return false ;
        
        if ( ! ( obj instanceof BindingImmutable) )
            return false ;
        BindingImmutable b = (BindingImmutable)obj ;
        if ( b.hashCode() != this.hashCode())
            return false ;
        
        if ( this.vars.size() != b.vars.size() )
            // Mismatch in the variables.
            return false ;
        
        Iterator iter = this.vars.listIterator() ;
        for ( ; iter.hasNext() ; )
        {
            String varName = (String)iter.next() ; 
            Object obj1 = this.get(varName) ;
            Object obj2 = b.get(varName) ;
            if ( obj1 == null && obj2 == null )
                continue ;
            if (obj1 == null )
                return false ;      // obj2 not null
            if (obj2 == null )
                return false ;      // obj1 not null

            if ( !obj1.equals(obj2) )
                return false ;
        }
        return true ;
    }
    
    public int hashCode()
    {
        return calcHashCode ;
    }
    
    protected void checkAdd1(String vn, Node node) { }
    
    // Use QueryIterProject
    public static QueryIterator makeConverterIterator(Collection vars, QueryIterator cIter, ExecutionContext context)
    {
        return new QueryIterConvert(cIter, new Convert(vars), context) ;
    }
    
    public static class Convert implements QueryIterConvert.Converter
    {
        Collection vars  ;
        public Convert(Collection vars) { this.vars = vars ; }
        
        public Binding convert(Binding binding)
        {
            return new BindingImmutable(vars, binding) ;
        }
    }
}

/*
 *  (c) Copyright 2004, 2005, 2006 Hewlett-Packard Development Company, LP
 *  All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in the
 *    documentation and/or other materials provided with the distribution.
 * 3. The name of the author may not be used to endorse or promote products
 *    derived from this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE AUTHOR ``AS IS'' AND ANY EXPRESS OR
 * IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES
 * OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED.
 * IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR ANY DIRECT, INDIRECT,
 * INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT
 * NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
 * DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
 * THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
 * (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF
 * THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */
