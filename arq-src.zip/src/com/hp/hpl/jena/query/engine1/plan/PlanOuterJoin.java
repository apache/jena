/*
 * (c) Copyright 2005, 2006 Hewlett-Packard Development Company, LP
 * All rights reserved.
 * [See end of file]
 */

package com.hp.hpl.jena.query.engine1.plan;

import java.util.*;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import com.hp.hpl.jena.query.engine.QueryIterator;
import com.hp.hpl.jena.query.engine1.*;
import com.hp.hpl.jena.query.engine1.analyse.PlanVarsMentioned;


public class PlanOuterJoin extends PlanElement0
{
    static Log log = LogFactory.getLog(PlanOuterJoin.class) ;
    Set planElements ;
    PlanElement planElement ;
    
    public static PlanElement make(Plan plan, Set equiv)
    {
        //return new PlanOuterJoin(plan, equiv) ;
        PlanElement p = permute(plan, equiv) ;
        Set vars = PlanVarsMentioned.varMentioned(p) ;
        p = PlanDistinct.make(plan, p, vars) ;
        return p ;
    }

    private PlanOuterJoin(Plan plan, Set planElements)
    {
        super(plan) ;
        this.planElements = planElements ;
        planElement = permute(getPlan(), planElements) ;
        
    }
    
    public Set getPlanElements() { return planElements ; } 
    
    public QueryIterator build(QueryIterator input, ExecutionContext execCxt)
    {
        return planElement.build(input, execCxt) ;
    }
    
    private static PlanElement permute(Plan plan, Set planElements)
    {
        // Do as a union of all possibilities
        if ( planElements.size() != 2 )
        {
            log.fatal("Can only permute 2 elements - not "+planElements.size()) ;
            return null ;
        }
        Iterator iter = planElements.iterator() ;
        PlanElement x1 = (PlanElement)iter.next() ;
        PlanElement x2 = (PlanElement)iter.next() ;
        
        List u1 = new ArrayList() ;
        u1.add(x1) ;
        u1.add(x2) ;
        PlanGroup pg1 = PlanGroup.make(plan, u1, false) ;

        List u2 = new ArrayList() ;
        u2.add(x2) ;
        u2.add(x1) ;
        PlanGroup pg2 = PlanGroup.make(plan, u2, false) ;
        
        List u = new ArrayList() ;
        u.add(pg1) ;
        u.add(pg2) ;
        PlanElement pUnion = PlanUnion.make(plan, u) ; 
        return pUnion ;
    }

    public void visit(PlanVisitor visitor)
    { visitor.visit(this) ; }

    public PlanElement apply(Transform transform) { return null ; } //transform.transform(this) ; } 

    public PlanElement copy()
    {
        return make(getPlan(), planElements) ;
    }
}

/*
 * (c) Copyright 2005, 2006 Hewlett-Packard Development Company, LP
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in the
 *    documentation and/or other materials provided with the distribution.
 * 3. The name of the author may not be used to endorse or promote products
 *    derived from this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE AUTHOR ``AS IS'' AND ANY EXPRESS OR
 * IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES
 * OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED.
 * IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR ANY DIRECT, INDIRECT,
 * INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT
 * NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
 * DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
 * THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
 * (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF
 * THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */