/*
 * (c) Copyright 2004, 2005, 2006 Hewlett-Packard Development Company, LP
 * [See end of file]
 */

package com.hp.hpl.jena.query;

import java.io.OutputStream;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Set;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import com.hp.hpl.jena.graph.Node;

import com.hp.hpl.jena.query.core.*;
import com.hp.hpl.jena.query.serializer.Serializer;

import com.hp.hpl.jena.query.util.*;
import com.hp.hpl.jena.query.util.IndentedWriter;
import com.hp.hpl.jena.query.util.IndentedLineBuffer;
import com.hp.hpl.jena.query.util.FmtUtils;
import com.hp.hpl.jena.query.util.RelURI;

import com.hp.hpl.jena.query.expr.Expr ;

import com.hp.hpl.jena.shared.PrefixMapping;
import com.hp.hpl.jena.shared.impl.PrefixMappingImpl;

/** The data structure for a query as presented externally.
 *  There are two ways of creating a query - use the parser to turn
 *  a string description of the query into the executable form, and
 *  the programmatic way (the parser is calling the programmatic
 *  operations driven by the quyery string).  The declarative approach
 *  of passing in a string is preferred.
 *
 * Once a query is built, it can be passed to the QueryFactory to produce a query execution engine.
 * @see QueryExecutionFactory
 * @see ResultSet
 * 
 * @author		Andy Seaborne
 * @version 	$Id: Query.java,v 1.69 2006/04/11 14:02:35 andy_seaborne Exp $
 */

public class Query implements Cloneable
{
    static { ARQ.init() ; /* Ensure everything has started properly */ }
    static Log log = LogFactory.getLog(Query.class) ;
    
    public static final int QueryTypeUnknown    = -123 ;
    public static final int QueryTypeSelect     = 111 ;
    public static final int QueryTypeConstruct  = 222 ;
    public static final int QueryTypeDescribe   = 333 ;
    public static final int QueryTypeAsk        = 444 ;
    int queryType = QueryTypeUnknown ; 
    
    // If no model is provided explicitly, the query engine will load
    // a model from the URL.  Never a list of zero items.
    
    List graphURIs = new ArrayList() ;
    List namedGraphURIs = new ArrayList() ;
    
    ElementBlock queryBlock = null ;
    Syntax syntax = Syntax.syntaxSPARQL ; // Default
    
    public static long NOLIMIT = Long.MIN_VALUE ;
    long resultLimit   = NOLIMIT ;
    long resultOffset  = NOLIMIT ;
    List orderBy       = null ;
    public static int ASCENDING  = 1 ; 
    public static int DESCENDING = -1 ;

    boolean strictQuery = true ;
    
    /// SELECT/DESCRIBE/CONSTRUCT *
    protected boolean queryResultStar        = false ;
    // SELECT
    // The names of variables wanted by the caller
    protected List resultVars                = new ArrayList() ;     // Type in list: String name
    protected boolean distinct               = false ;
    
    // CONSTRUCT
    protected Template constructTemplate  = null ;
    
    // DESCRIBE
    // Any URIs/QNames in the DESCRIBE clause
    // Also uses resultVars
    protected List resultNodes               = new ArrayList() ;     // Type in list: Node
    
    // Was a base URI explicitly set?
    protected boolean seenBaseURI = false ;
    protected String baseURI = null ;

    protected PrefixMapping prefixMap = new PrefixMappingImpl() ;
    
    // ---- static methods for making a query
    
    /** Create a blank query.  The application is expected to complete the query parts needed
     *  by calling the various "add" operations later,
     */

    public Query()
    {
        syntax = Syntax.syntaxSPARQL ;
    }
    
    public void setQueryType(int qType)         { queryType = qType ; }
    public int getQueryType()                   { return queryType ; }
    
    public void setStrict(boolean isStrict)
    { 
        strictQuery = isStrict ;
        
        if ( strictQuery )
            initStrict() ;
        else
            initLax() ;
    }
    
    public boolean isStrict()                { return strictQuery ; }
    
    private void initStrict()
    {
//        if ( prefixMap.getGlobalPrefixMapping() == globalPrefixMap )
//            prefixMap.setGlobalPrefixMapping(null) ;
    }

    private void initLax()
    {
//        if ( prefixMap.getGlobalPrefixMapping() == null )
//            prefixMap.setGlobalPrefixMapping(globalPrefixMap) ;
    }
    
    public void setDistinct(boolean b) { distinct = b ; }
    public boolean isDistinct()       { return distinct ; }
    
    /** @return Returns the syntax. */
    public Syntax getSyntax()         { return syntax ; }

    /** @param syntax The syntax to set. */
    public void setSyntax(Syntax syntax)  { this.syntax = syntax ; }

    public long getLimit()             { return resultLimit ; } 
    public void setLimit(long limit)   { resultLimit = limit ; }
    public boolean hasLimit()          { return resultLimit != NOLIMIT ; }
    
    public long getOffset()            { return resultOffset ; } 
    public void setOffset(long offset) { resultOffset = offset ; }
    public boolean hasOffset()         { return resultOffset != NOLIMIT ; }
    
    public boolean hasOrderBy()        { return orderBy != null && orderBy.size() > 0 ; }
    
    public void addOrderBy(SortCondition condition)
    {
        if ( orderBy == null )
            orderBy = new ArrayList() ;

        orderBy.add(condition) ;
    }
    public void addOrderBy(Expr expr, int direction)
    {
        SortCondition sc = new SortCondition(expr, direction) ;
        addOrderBy(sc) ;
    }
    
    public void addOrderBy(Node var, int direction)
    { 
        if ( ! var.isVariable() )
            throw new QueryException("Not a variable: "+var) ;
        SortCondition sc = new SortCondition(var, direction) ;
        addOrderBy(sc) ;
    }
    
    public void addOrderBy(String varName, int direction)
    { 
        varName = Var.canonical(varName) ;
        SortCondition sc = new SortCondition(varName, direction) ;
        addOrderBy(sc) ;
    }

    public List getOrderBy()           { return orderBy ; }
    
    public boolean isSelectType()      { return queryType == QueryTypeSelect ; }
    public boolean isConstructType()   { return queryType == QueryTypeConstruct ; }
    public boolean isDescribeType()    { return queryType == QueryTypeDescribe ; }
    public boolean isAskType()         { return queryType == QueryTypeAsk ; }
    public boolean isUnknownType()     { return queryType == QueryTypeUnknown ; }

    /** Answer whether the query had SELECT/DESCRIBE/CONSTRUCT *
     * @return boolean as to whether a * result form was seen
     */ 
    public boolean isQueryResultStar() { return queryResultStar ; }

    /**Set whether the query had SELECT/DESCRIBE/CONSTRUCT *
     * 
     * @param isQueryStar 
     */
    public void setQueryResultStar(boolean isQueryStar) { queryResultStar = isQueryStar ; }
    
    public void setQueryElement(Element elt)
    {
        if ( queryBlock == null )
            queryBlock = new ElementBlock(null, null) ;
        queryBlock.setPatternElement(elt) ;
    }
//    public QueryElement getQueryElement() { return queryElement ; }
    

    public void setQueryBlock(ElementBlock block)
    {
        queryBlock = block ; 
    }
    
    public ElementBlock getQueryBlock() { return queryBlock ; }
    
    
    /** Location of the source for the data.  If the model is not set,
     *  then the QueryEngine will attempt to load the data from these URIs
     *  into the default (unamed) graph.
     */
    public void addGraphURI(String s)
    {
        if ( graphURIs == null )
            graphURIs = new ArrayList() ;
        //initBaseURI() ;
        //RelURI.resolve(s, baseURI) ;
        graphURIs.add(s) ;
    }

    /** Location of the source for the data.  If the model is not set,
     *  then the QueryEngine will attempt to load the data from these URIs
     *  as named graphs in the dataset.
     */
    public void addNamedGraphURI(String s)
    {
        if ( namedGraphURIs == null )
            namedGraphURIs = new ArrayList() ;
        //initBaseURI() ;
        //RelURI.resolve(s, baseURI) ;
        namedGraphURIs.add(s) ;
    }
    
    /** Return the list of URIs (strings) for the unnamed graph
     * 
     * @return List of strings
     */
    
    public List getGraphURIs() { return graphURIs ; }

    /** Return the list of URIs (strings) for the named graphs
     * 
     * @return List of strings
     */
    
    public List getNamedGraphURIs() { return namedGraphURIs ; }

    /** Return true if the query has either some graph
     * URIs or some named graph URIs in its description.
     * This does not mean these URIs will be used - just that
     * they are noted as part of the query. 
     */ 
    
    public boolean hasDatasetDescription()
    {
        if ( getGraphURIs() != null && getGraphURIs().size() > 0 )
            return true ;
        if ( getNamedGraphURIs() != null && getNamedGraphURIs().size() > 0 )
            return true ;
        return false ;
    }
    
    // ---- SELECT

    /** Return a list of the variables requested (SELECT) */
    public List getResultVars() { return resultVars ; }
    /** Add a projection variable to a SELECT query */
    public void addResultVar(String varName)
    {
        varName = Var.canonical(varName) ;
        if ( !resultVars.contains(varName) )
            resultVars.add(varName);
    }

    public void addResultVar(Node v)
    {
        if ( !v.isVariable() )
            throw new QueryException("Not a variable: "+v) ;
        addResultVar(v.getName()) ;
    }
    
    public void addDescribeNode(Node node)
    {
        if ( node.isVariable() ) { addResultVar(node) ; return ; }
        if ( node.isURI() ) { addResultURIs(node) ; return ; }
        if ( node.isLiteral() )
            throw new QueryException("Result node is a literal: "+FmtUtils.stringForNode(node)) ;
        throw new QueryException("Result node not recognized: "+FmtUtils.stringForNode(node)) ;
    }

    // ---- CONSTRUCT 
    
    /** Get the template pattern for a construct query */ 
    public Template getConstructTemplate() 
    { 
        return constructTemplate ;
    
    }
    
    /** Add a triple patterns for a construct query */ 
    public void setConstructTemplate(Template templ)  { constructTemplate = templ ; }

    // ---- DESCRIBE
    
    /** Get the result list (things wanted - not the results themselves)
     *  of a DESCRIBE query. */ 
    public List getResultURIs() { return resultNodes ; }
    
    /** Add a result for a DESCRIBE query */
    public void addResultURIs(Node node)
    {
        if ( node.isLiteral() )
            throw new QueryException("Result URI is a literal: "+FmtUtils.stringForNode(node)) ;
        if ( !resultNodes.contains(node) )
            resultNodes.add(node);
    }

    
    private boolean resultVarsSet = false ; 
    /** Fix up when the query has "*" (when SELECT * or DESCRIBE *)
     *  and for a construct query.  Idempotent.
     */
    public void setResultVars()
    {
        if ( resultVarsSet )
            return ;
        resultVarsSet = true ;
        
        if ( getQueryBlock() == null )
        {
            if ( ! this.isDescribeType() )
                log.warn("setResultVars(): no query block") ;
            return ;
        }
        
        if ( resultVars.size() != 0 )
        {
            //log.warn("setResultVars(): Result vars already set") ;
            return ;
        }
        
        if ( isSelectType() )
        {
            if ( isQueryResultStar() )
                findAndAddNamedVars() ;
        }
        
        if ( isConstructType() )
        {
            // All named variables are in-scope
            findAndAddNamedVars() ;
        }
        
        if ( isDescribeType() )
        {
            if ( isQueryResultStar() )
                findAndAddNamedVars() ;
        }

//        if ( isAskType() )
//        {}
    }
    
    private void findAndAddNamedVars()
    {
        // All query variables, including ones from bNodes in the query.
        Set queryVars = getQueryBlock().varsMentioned() ;
        
        for ( Iterator iter = queryVars.iterator() ; iter.hasNext() ; )
        {
            String varName = (String)iter.next() ;
            // Selectable variable?
            // Not a bNodes or a system variable 
            // or anything starting with a marker character
            // Note that there is no ? or $ in the variable name.
            
            // Java 1.5 ism.
            //int ch = varName.codePointAt(0) ;
            
            // Only works with basic plane, not surrogates.
            char ch = varName.charAt(0) ;

            if ( Character.isLetter(ch) )
                //iter.remove() ;
                addResultVar(varName) ;
        }
    }

    
    /**
     * @return True if the query has an explicitly set base URI. 
     */
    public boolean explicitlySetBaseURI() { return seenBaseURI ; }

    /**
     * @return Returns the baseURI.
     */
    public String getBaseURI()
    {
        return baseURI;
    }
    /**
     * @param baseURI The baseURI to set.
     */
    public void setBaseURI(String baseURI)
    {
        this.baseURI = baseURI;
        this.seenBaseURI = true ;
    }
    
    void initParserBaseURI() { initParserBaseURI(null) ; }
    void initParserBaseURI(String base)
    {
        if ( baseURI != null )
            return ;
        
        baseURI =  RelURI.chooseBaseURI(base) ;
    }
    
    // ---- Query prefixes
    
	/** Set a prefix for this query */
	public void setPrefix(String prefix, String expansion)
	{
        try {
            prefixMap.setNsPrefix(prefix, expansion) ;
        } catch (PrefixMapping.IllegalPrefixException ex)
        {
            log.warn("Illegal prefix mapping(ignored): "+prefix+"=>"+expansion) ;
        }
	}	

    /** @deprecated Use getPrefixMapping */
    public PrefixMapping getPrefixMap() { return getPrefixMapping(); }

	/** Return the prefix map from the parsed query */ 
	public PrefixMapping getPrefixMapping() { return prefixMap ; }
    /** Set the mapping */
    public void setPrefixMapping(PrefixMapping pmap ) { prefixMap = pmap ; }

//    /** Return the prefix map from the parsed query */ 
//    public PrefixMapping getLocalPrefixMap() { return prefixMap.getLocalPrefixMapping() ; }
//
//    public static PrefixMapping getGlobalPrefixMap() { return globalPrefixMap ; }

    
	/** Lookup a prefix for this query, including the default prefixes */
    public String getPrefix(String prefix)
    {
        return prefixMap.getNsPrefixURI(prefix) ;
    }
    
    /** Expand QName 
     * 
     * @param qname  The QName to be expanded
     * @return URI, or null if not expanded.
     */

    public String expandQName(String qname)
    {
        String s = prefixMap.expandPrefix(qname) ;
        if ( s.equals(qname) )
            return null ;
        return s ;
    }
    
    
    /** Use the prefix map to turn a URI into a qname, or return the original URI */
    
    public String shortForm(String uri)
    {
        return prefixMap.shortForm(uri) ;
    }

    
    public void visit(QueryVisitor visitor)
    {
        visitor.startVisit(this) ;
        visitor.visitResultForm(this) ;
        visitor.visitBase(this) ;
        visitor.visitPrefixes(this) ;
        if ( this.isSelectType() )
            visitor.visitSelectResultForm(this) ;
        if ( this.isConstructType() )
            visitor.visitConstructResultForm(this) ;
        if ( this.isDescribeType() )
            visitor.visitDescribeResultForm(this) ;
        if ( this.isAskType() )
            visitor.visitAskResultForm(this) ;
        visitor.visitDatasetDecl(this) ;
        visitor.visitQueryPattern(this) ;
        visitor.visitOrderBy(this) ;
        visitor.visitLimit(this) ;
        visitor.visitOffset(this) ;
        visitor.finishVisit(this) ;
    }

    // With Java 1.5, this can be returns Query.
    public Object clone() { return cloneQuery() ; }
    
    public Query cloneQuery()
    {
        // A little crude.
        IndentedLineBuffer buff = new IndentedLineBuffer() ;
        serialize(buff, getSyntax()) ;
        String qs = buff.toString() ;
        return QueryFactory.create(qs) ;
    }
    
    // ---- Query canonical syntax
    
    // Reverse of parsing : should produce a string that parses to an equivalent query
    // "Equivalent" => gives the same results on any model  
    public String toString()
    { return serialize() ; }
    
    /** Must align with .equals */
    private int hashcode = -1 ;
    public int hashCode()
    { 
        if ( hashcode == -1 )
        {
            hashcode = QueryHashCode.calc(this) ;
            if ( hashcode == -1 )
                hashcode = Integer.MIN_VALUE/2 ;
        }
        return hashcode ;
    }
    
    /** Are two queries equals - tests shape and details.
     * Equality means that the queries do the same thing, including
     * same variables, in the same places.  Being unequals does
     * <b>not</b> mean the queries do different things.  
     * 
     * For example, reordering a group or union
     * means that that a query is different.
     *  
     * Two instances of a query parsed from the same string are equal. 
     */
    
    public boolean equals(Object other)
    { 
        if ( other == null ) return false ;

        if ( ! ( other instanceof Query ) )
            return false ;
        return QueryCompare.equals(this, (Query)other) ;
    }
    
//    public static boolean sameAs(Query query1, Query query2)
//    { return query1.sameAs(query2) ; }  
    
    public String serialize()
    {
        IndentedLineBuffer buff = new IndentedLineBuffer() ;
        serialize(buff) ;
        return buff.toString();
    }
    
    /** Output the query
     * @param out  OutputStream
     */
    public void serialize(OutputStream out) { Serializer.serialize(this, out) ; }
    
    /** Output the query
     * 
     * @param out     OutputStream
     * @param syntax  Syntax URI
     */
    
    public void serialize(OutputStream out, Syntax syntax) { Serializer.serialize(this, out, syntax) ; }

    /** Format the query into the buffer
     * 
     * @param buff    IndentedLineBuffer
     */
    
    public void serialize(IndentedLineBuffer buff) { Serializer.serialize(this, buff) ; }
    
    /** Format the query
     * 
     * @param buff       IndentedLineBuffer in which to place the unparsed query
     * @param outSyntax  Syntax URI
     */
    
    public void serialize(IndentedLineBuffer buff, Syntax outSyntax) { Serializer.serialize(this, buff, outSyntax) ; }

    /** Format the query
     * 
     * @param writer  IndentedWriter
     */
    
    public void serialize(IndentedWriter writer) { Serializer.serialize(this, writer) ; }

    /** Format the query
     * 
     * @param writer     IndentedWriter
     * @param outSyntax  Syntax URI
     */
    
    public void serialize(IndentedWriter writer, Syntax outSyntax)
    {
        Serializer.serialize(this, writer, outSyntax) ;
    }
}

/*
 *  (c) Copyright 2004, 2005, 2006 Hewlett-Packard Development Company, LP
 *  All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in the
 *    documentation and/or other materials provided with the distribution.
 * 3. The name of the author may not be used to endorse or promote products
 *    derived from this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE AUTHOR ``AS IS'' AND ANY EXPRESS OR
 * IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES
 * OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED.
 * IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR ANY DIRECT, INDIRECT,
 * INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT
 * NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
 * DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
 * THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
 * (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF
 * THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */
