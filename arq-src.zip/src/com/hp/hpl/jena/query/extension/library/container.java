/*
 * (c) Copyright 2005, 2006 Hewlett-Packard Development Company, LP
 * All rights reserved.
 * [See end of file]
 */

package com.hp.hpl.jena.query.extension.library;

import java.util.*;

import org.apache.commons.logging.*;

import com.hp.hpl.jena.graph.Graph;
import com.hp.hpl.jena.graph.Node;
import com.hp.hpl.jena.query.QueryFatalException;
import com.hp.hpl.jena.query.core.Binding;
import com.hp.hpl.jena.query.core.Binding1;
import com.hp.hpl.jena.query.engine.QueryIterator;
import com.hp.hpl.jena.query.engine1.*;
import com.hp.hpl.jena.query.engine1.iterator.QueryIterNullIterator;
import com.hp.hpl.jena.query.engine1.iterator.QueryIterPlainWrapper;
import com.hp.hpl.jena.query.engine1.iterator.QueryIterYieldN;
import com.hp.hpl.jena.query.expr.Expr;
import com.hp.hpl.jena.query.expr.NodeValue;
import com.hp.hpl.jena.query.extension.ExtUtils;
import com.hp.hpl.jena.query.extension.Extension2;
import com.hp.hpl.jena.query.util.GraphUtils;
import com.hp.hpl.jena.query.util.Utils;

/** container - super class of bag/alt/seq 
 * 
 * 
 * @author Andy Seaborne
 * @version $Id: container.java,v 1.13 2006/06/15 17:07:35 andy_seaborne Exp $
 */ 

public class container extends Extension2
{
    private static Log log = LogFactory.getLog(container.class) ;
    Node typeNode = null ;      // Null means don't check type.
    
    public container() { this.typeNode = null ; }

    protected container(Node typeURI) { this.typeNode = typeURI ; }
    

//  @Override
    protected QueryIterator exec(Expr container, Expr member, Binding binding, ExecutionContext execCxt)
    {
        Graph graph = getExecutionContext().getActiveGraph() ;
        
        // Check container - value only. 
        Node containerNode = null ;
        container = ExtUtils.evalToExpr(container, binding) ;
        
        if (container.isVariable() )
            throw new QueryFatalException(Utils.className(this)+": Arg 1 not bound (not implemented yet)") ;

        if ( container.isConstant() )
            containerNode = container.getConstant().asNode() ;

        if ( containerNode == null )
            throw new QueryFatalException(Utils.className(this)+": Arg 1 is too hard : "+container) ;

//        if ( ! GraphUtils.isContainer(graph, containerNode) )
//            return new QueryIterNullIterator(getContext()) ;
        
        member = ExtUtils.evalToExpr(member, binding) ;
        // Check member - variable or a value 
        if ( member == null )
            throw new QueryFatalException(Utils.className(this)+": Arg 2 is strange : "+member) ;

        if ( ! member.isVariable() && ! member.isConstant() )
            throw new QueryFatalException(Utils.className(this)+": Arg 2 is too hard : "+member) ;
            
        if ( member.isVariable() )
        {
            String varName = member.getVarName() ; 
            // 2 pass - not efficient
            // Variable - find the members.
            Collection x = GraphUtils.containerMembers(graph, containerNode, typeNode) ;
            if ( x == null )
                // Wrong type.
                return new QueryIterNullIterator(getExecutionContext()) ;
            
            List bindings = new ArrayList() ;
            for ( Iterator iter = x.iterator() ; iter.hasNext() ; )
            {
                Node n = (Node)iter.next() ;
                Binding b = new Binding1(varName, n, binding) ;
                bindings.add(b) ;
                
            }
            // Turn into a QueryIterator of extra bindings.
            return new QueryIterPlainWrapper(bindings.iterator(), getExecutionContext()) ;
        }
        
        // Value / Constant - a plain test really except it counts
        Node n = ((NodeValue)member).asNode() ;
        int count = GraphUtils.countContainerMember(graph, containerNode, typeNode, n) ;
        return new QueryIterYieldN(count, binding, getExecutionContext()) ;
    }

}

/*
 * (c) Copyright 2005, 2006 Hewlett-Packard Development Company, LP
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in the
 *    documentation and/or other materials provided with the distribution.
 * 3. The name of the author may not be used to endorse or promote products
 *    derived from this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE AUTHOR ``AS IS'' AND ANY EXPRESS OR
 * IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES
 * OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED.
 * IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR ANY DIRECT, INDIRECT,
 * INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT
 * NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
 * DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
 * THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
 * (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF
 * THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */