/*
 * (c) Copyright 2005, 2006 Hewlett-Packard Development Company, LP
 * All rights reserved.
 * [See end of file]
 */

package com.hp.hpl.jena.query.extension.library;

import java.io.PrintWriter;
import java.io.PrintStream;
import java.util.List;

import org.apache.commons.logging.*;

import com.hp.hpl.jena.query.core.Binding;
import com.hp.hpl.jena.query.engine.QueryIterator;
import com.hp.hpl.jena.query.extension.ExtensionBaseEvalArgs;
import com.hp.hpl.jena.query.extension.ExtensionSingleton;
import com.hp.hpl.jena.query.util.ExprUtils;
import com.hp.hpl.jena.util.FileUtils;

/** Print expressions - really just an example of an extension.
 * 
 * @author Andy Seaborne
 * @version $Id: print.java,v 1.3 2005/12/26 20:08:18 andy_seaborne Exp $
 */ 

public class print extends ExtensionBaseEvalArgs
{
    private static Log log = LogFactory.getLog(print.class) ;
    
    private static PrintWriter out = FileUtils.asPrintWriterUTF8(System.out) ; 
    static public void setStream(PrintStream stream) { out = FileUtils.asPrintWriterUTF8(stream) ; }  

    //@Override
    public void build(List args, String uri) {}

    //@Override
    public QueryIterator execEvaluated(List args, Binding binding) 
    {
        if ( args.size() == 0 )
            out.println(binding.toString()) ;
        else
            out.println(ExprUtils.joinList(args, " ")) ;
        out.flush() ;
        return new ExtensionSingleton(binding) ;
    }
}

/*
 * (c) Copyright 2005, 2006 Hewlett-Packard Development Company, LP
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in the
 *    documentation and/or other materials provided with the distribution.
 * 3. The name of the author may not be used to endorse or promote products
 *    derived from this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE AUTHOR ``AS IS'' AND ANY EXPRESS OR
 * IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES
 * OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED.
 * IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR ANY DIRECT, INDIRECT,
 * INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT
 * NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
 * DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
 * THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
 * (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF
 * THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */