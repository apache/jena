/*
 * (c) Copyright 2005, 2006 Hewlett-Packard Development Company, LP
 * All rights reserved.
 * [See end of file]
 */

package com.hp.hpl.jena.query.extension.library;

import java.util.*;

import com.hp.hpl.jena.query.QueryBuildException;
import com.hp.hpl.jena.query.core.Binding;
import com.hp.hpl.jena.query.engine.QueryIterator;
import com.hp.hpl.jena.query.engine1.*;
import com.hp.hpl.jena.query.engine1.iterator.QueryIterPlainWrapper;
import com.hp.hpl.jena.query.expr.Expr;
import com.hp.hpl.jena.query.expr.NodeValue;
import com.hp.hpl.jena.query.extension.Extension;
import com.hp.hpl.jena.query.util.Utils;


/** Extension that groups its input iterator - EXPERIMENTAL-UNFINISHED
 * 
 * @author Andy Seaborne
 * @version $Id: group.java,v 1.30 2006/09/03 18:57:17 andy_seaborne Exp $
 */
public class group implements Extension
{
    ExecutionContext execContext ;
    Map grouped = new HashMap() ; // Var => set of bindings
    
    public void build(String uri, List args)
    {
        if ( args.size() == 0 )
            throw new QueryBuildException("Extension "+Utils.className(this)+" takes arguments") ;

    }
 
    public QueryIterator exec(QueryIterator input, List args, String uri, ExecutionContext execCxt)
    {
        execContext = execCxt ;
        Expr expr = (Expr)args.get(0) ;
        QueryIterator qIter = new QueryIterGroup(input, expr, new Count(), execCxt) ;
        return qIter ;
    }
}


interface Aggregate
{
    public void start() ;
    public void finish() ;
    public void calc(Binding binding) ;
    public NodeValue get() ;
}

class Count implements Aggregate
{
    int count = 0 ;

    public void start() { count = 0 ; }
    public void finish() {} 
    public void calc(Binding binding) { count++ ; }
    public NodeValue get() { return NodeValue.makeNodeInteger(count)  ; }
}


class QueryIterGroup extends QueryIterPlainWrapper
{
    static int varNameCount = 1 ;
    int ind = varNameCount ; 
    String varName = "AGG"+(varNameCount++) ;
    
    Aggregate agg ;
    
    QueryIterGroup(QueryIterator input, Expr expr, Aggregate agg, ExecutionContext execCxt)
    { 
        super(null) ;
        List x = makeList(input, expr, agg) ;
        setIterator(x.iterator()) ;
    }
    
    private List makeList(QueryIterator input, Expr expr, Aggregate agg)
    {
        Map groups = new HashMap() ;
        
        // Group it.  Should run a bunch of aggregators in parallel in this loop.
        for ( ; input.hasNext() ; )
        {
            Binding binding = input.nextBinding() ;
            NodeValue val = expr.eval(binding, super.getExecContext()) ;
            if ( ! groups.containsKey(val) )
                groups.put(val, new ArrayList()) ;
            List list = (List)groups.get(val) ;
            list.add(binding) ;
        }
        
        // The new rows
        List list = new ArrayList() ;
        for ( Iterator iter = groups.keySet().iterator() ; iter.hasNext() ; )
        {
            NodeValue val = (NodeValue)iter.next() ;
            List x = (List)groups.get(val) ;
            agg.start() ;
            Binding binding = null ;
            for ( Iterator iter2 = x.iterator() ; iter2.hasNext() ; )
            {
                Binding b = (Binding)iter2.next() ;
                if ( binding == null )
                    binding = b ;
                agg.calc(b) ;
            }
            agg.finish() ;
            if ( binding != null )
            {
                binding.add(varName, agg.get().asNode()) ;
                list.add(binding) ;
            }
        }
        return list ; 
    }
}



/*
 * (c) Copyright 2005, 2006 Hewlett-Packard Development Company, LP
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in the
 *    documentation and/or other materials provided with the distribution.
 * 3. The name of the author may not be used to endorse or promote products
 *    derived from this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE AUTHOR ``AS IS'' AND ANY EXPRESS OR
 * IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES
 * OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED.
 * IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR ANY DIRECT, INDIRECT,
 * INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT
 * NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
 * DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
 * THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
 * (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF
 * THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */