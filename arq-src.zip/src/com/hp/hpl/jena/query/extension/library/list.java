/*
 * (c) Copyright 2005, 2006 Hewlett-Packard Development Company, LP
 * All rights reserved.
 * [See end of file]
 */

package com.hp.hpl.jena.query.extension.library;

import java.util.*;

import org.apache.commons.logging.*;

import com.hp.hpl.jena.graph.Graph;
import com.hp.hpl.jena.graph.Node;
import com.hp.hpl.jena.query.QueryFatalException;
import com.hp.hpl.jena.query.core.Binding;
import com.hp.hpl.jena.query.core.Binding1;
import com.hp.hpl.jena.query.engine.QueryIterator;
import com.hp.hpl.jena.query.engine1.*;
import com.hp.hpl.jena.query.expr.Expr;
import com.hp.hpl.jena.query.extension.Extension2;
import com.hp.hpl.jena.query.util.GraphUtils;
import com.hp.hpl.jena.query.util.Utils;

/** List membership. 
 * 
 * @author Andy Seaborne
 * @version $Id: list.java,v 1.14 2006/02/02 13:38:02 andy_seaborne Exp $
 */ 

public class list extends Extension2
{
    private static Log log = LogFactory.getLog(list.class) ;

    //@Override
    protected QueryIterator exec(Expr list, Expr member, Binding binding, ExecutionContext execCxt)
    {
//        Node nList = null ;
//        if ( list.isConstant() )
//            nList = list.getConstant().getNode() ;
//        else if ( list.isVariable() )
//        {
//            if ( binding.contains(list.getVarName()) )
//                nList = binding.get(list.getVarName()) ;
//        }
        
        Node nList = evalIfPossible(list, binding, execCxt) ;

        String itemVarName = member.getVarName() ;  // May be null - not a var
        
        // Case : arg 1 (the list) is bound and arg 2 not bound => generate possibilities
        // Case : arg 1 is bound and arg 2 is bound => test for membership.
        
        Graph graph = getExecutionContext().getActiveGraph() ;
        
        if ( nList != null )
        {
            // evalIfPossible()
            if ( itemVarName != null )
            {
                List members = GraphUtils.listMembers(graph, nList) ;
                return new MemberIterator(binding, itemVarName, members.iterator(), execCxt) ;
            }
            else
            {
                Node x = member.eval(binding, execCxt).asNode() ;
                int count = GraphUtils.countListMember(graph, nList, x) ;
                return new QueryIterYieldN(count, binding) ;
//                boolean found = GraphUtils.isListMember(graph, nList, x) ;
//                if ( found )
//                    return new ExtensionSingleton(binding) ;
//                else
//                    return new QueryIterNullIterator(null) ;
            }
        }
        
        // nList == null : unbound variable.
        throw new QueryFatalException(Utils.className(this)+": The list not bound (not implemented yet)") ; 
    }


}

// TODO Extract as QueryIterAddValues
class MemberIterator extends QueryIter
{
    Binding binding ;
    String varName ;
    Iterator members ;
    
    public MemberIterator(Binding binding, String varName, Iterator members, ExecutionContext execCxt)
    {
        super(execCxt) ;
        this.binding = binding ;
        this.varName = varName ;
        this.members = members ;
    }

    //@Override
    protected boolean hasNextBinding()
    {
        return members.hasNext() ;
    }

    //@Override
    protected Binding moveToNextBinding()
    {
        Node n = (Node)members.next() ;
        Binding b = new Binding1(varName, n, binding) ;
        return b ;
    }

    //@Override
    protected void closeIterator()
    { }
}

/*
 * (c) Copyright 2005, 2006 Hewlett-Packard Development Company, LP
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in the
 *    documentation and/or other materials provided with the distribution.
 * 3. The name of the author may not be used to endorse or promote products
 *    derived from this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE AUTHOR ``AS IS'' AND ANY EXPRESS OR
 * IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES
 * OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED.
 * IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR ANY DIRECT, INDIRECT,
 * INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT
 * NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
 * DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
 * THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
 * (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF
 * THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */