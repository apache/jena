/*
 * (c) Copyright 2004, 2005, 2006 Hewlett-Packard Development Company, LP
 * [See end of file]
 */

package com.hp.hpl.jena.query.engine;
import java.util.*;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import com.hp.hpl.jena.graph.Graph;
import com.hp.hpl.jena.graph.Node;
import com.hp.hpl.jena.graph.Triple;
import com.hp.hpl.jena.query.*;
import com.hp.hpl.jena.query.core.*;
import com.hp.hpl.jena.query.describe.DescribeHandler;
import com.hp.hpl.jena.query.describe.DescribeHandlerRegistry;
import com.hp.hpl.jena.query.engine1.EngineConfig;
import com.hp.hpl.jena.query.engine1.ExecutionContext;
import com.hp.hpl.jena.query.engine1.QueryEngineUtils;
import com.hp.hpl.jena.query.engine1.iterator.QueryIter;
import com.hp.hpl.jena.query.util.*;
import com.hp.hpl.jena.rdf.model.*;
import com.hp.hpl.jena.shared.PrefixMapping;
import com.hp.hpl.jena.util.FileManager;

/**
 * @author     Andy Seaborne
 * @version    $Id: QueryEngineBase.java,v 1.1 2006/12/08 16:54:01 andy_seaborne Exp $
 */
 
public abstract class QueryEngineBase implements QueryExecution, QueryExecutionGraph
{
    private static Log log = LogFactory.getLog(QueryEngineBase.class) ;
    
    protected Query query ;

    static int queryCount = 0 ;
    protected boolean queryExecutionInitialised = false ;
    protected boolean queryExecutionClosed = false ;
    protected int idQueryExecution ;
    
    protected QueryIterator resultsIter ;
    private Context context ;
    private ExecutionContext execContext = null ; 
    protected QuerySolution startBinding = null ; 
    private FileManager fileManager = null ;
    private Dataset      dataset = null ;         // Set extenally
    private DatasetGraph datasetGraph = null ;    // The graph equivalent
    
    protected QueryEngineBase(Query q, Context context)
    {
        // System initialized by now : Query class ensures ARQ initialized.
        if ( context == null )
            context = new Context(EngineConfig.getContext()) ;
        query = q ;
        idQueryExecution = (++queryCount) ;
        this.context = context ;
    }
    
    public Query getQuery() { return query ; }
    
    /** Initialise a query execution.  
     * Does not build the plan though.
     * May be called before exec.
     * If it has not be called, the query engine will initialise
     * itself during the exec() method.
     */

    protected void init()
    {
        if (queryExecutionInitialised)
            return;

        startInitializing() ;
        
        // Fixup query.
        query.setResultVars() ;

        // Set the dataset (graph form) 
        DatasetGraph dsg = null ;
        if ( getDataset() == null )
            dsg = buildDatasetForQuery() ;
        else
        {
            if ( getDataset().getDefaultModel() == null )
                log.warn("Default model is null in the dataset") ;
            dsg = new DataSourceGraphImpl(getDataset()) ;
        }
        datasetGraph = dsg ;
        // Create query execution context
        execContext = new ExecutionContext(context, getQuery(), datasetGraph.getDefaultGraph(), datasetGraph) ;
        
        queryExecutionInitialised = true ;
        finishInitializing() ;
    }
    
    protected void startInitializing()
    {}

    protected void finishInitializing()
    {}
    
    /** Called if a query execution needs a dataset : not called if a dataset has been
     * explicitly set (see also QueryEngineRegistry) 
     */
    protected DatasetGraph buildDatasetForQuery()
    {
        if ( ( query.getGraphURIs() == null || query.getGraphURIs().size() == 0 ) &&
             ( query.getNamedGraphURIs() == null || query.getNamedGraphURIs().size() == 0 ) )
        {
            //Query.log.warn("No data for query (no URL, no model)");
            throw new QueryExecException("No model for query");
        }
        
        String baseURI = query.getBaseURI() ;
        if ( baseURI == null )
            baseURI = RelURI.chooseBaseURI() ;
        log.debug("init: baseURI for query is: "+baseURI) ; 
        
        DatasetGraph dsg =
            DatasetUtils.createDatasetGraph(query.getGraphURIs(),
                                            query.getNamedGraphURIs(),
                                            fileManager, baseURI ) ;
        return dsg ;
    }
    
    public void setInitialBinding(QuerySolution rb) { startBinding = rb ; }
    public void setFileManager(FileManager fm) { fileManager = fm ; }

    /**
     * @return Returns the dataset.
     */
    public Dataset getDataset()
    {
        return dataset;
    }
    /**
     * @param dataset The dataset to set.
     */
    public void setDataset(Dataset dataset)
    {
        this.dataset = dataset;
    }
    
    /** @return Return the parameters associated with this QueryEngine */
    public Context getContext() { return context ; }

    /** @return Return the parameters associated with this QueryEngine */
    public ExecutionContext getExecContext() { return execContext ; }

    /** Execute the query and get back an iterato rof bindings (graph level) */
    public QueryIterator exec()
    {
        return execInternalGraph() ;
    }
    
    
    /** Execute a query and get back the results.
     * @return ResultSet
     */
    public ResultSet execSelect()
    {
        if ( ! query.isSelectType() )
            throw new QueryExecException("Attempt to have ResultSet from a "+labelForQuery(query)+" query") ; 
        init() ;
        return execInternal() ;
    }


    // Construct
    public Model execConstruct()
    { return execConstruct(GraphUtils.makeJenaDefaultModel()) ; }
    
    public Model execConstruct(Model model)
    {
        if ( ! query.isConstructType() )
            throw new QueryExecException("Attempt to get a CONSTRUCT model from a "+labelForQuery(query)+" query") ;
        // This causes there to be no PROJECT around the pattern.
        // That in turn, exposes the initial bindings.  
        query.setQueryResultStar(true) ;
        
        ResultSet qRes = execInternal() ;

        // Prefixes for result
        insertPrefixesInto(model) ;
        Set set = new HashSet() ;
        Template template = query.getConstructTemplate() ;
        
        // Build each template substitution as triples.
        for ( ; qRes.hasNext() ; )
        {
            Map bNodeMap = new HashMap() ;
            QuerySolution qs = qRes.nextSolution() ;
            ResultBinding rb = (ResultBinding)qs ;
            template.subst(set, bNodeMap, rb.getBinding()) ; 
        }
        
        // Convert and merg into Model.
        for ( Iterator iter = set.iterator() ; iter.hasNext() ; )
        {
            Triple t = (Triple)iter.next() ;
            Statement stmt = QueryEngineUtils.tripleToStatement(model, t) ;
            if ( stmt != null )
                model.add(stmt) ;
        }
        
        this.close() ;
        return model ;
    }

    public Model execDescribe()
    { return execDescribe(GraphUtils.makeJenaDefaultModel()) ; }

    
    public Model execDescribe(Model model)
    {
        if ( ! query.isDescribeType() )
            throw new QueryExecException("Attempt to get a DESCRIBE result from a "+labelForQuery(query)+" query") ; 
        query.setQueryResultStar(true) ;
        
        Set set = new HashSet() ;
        
        ResultSet qRes = execInternal() ;
        
        // Prefixes for result (after initialization)
        insertPrefixesInto(model) ;
        if ( qRes != null )
        {
            for ( ; qRes.hasNext() ; )
            {
                QuerySolution rb = qRes.nextSolution() ;
                for ( Iterator iter = query.getResultVars().iterator() ; iter.hasNext() ; )
                {
                    String varName = (String)iter.next() ;
                    RDFNode n = rb.get(varName) ;
                    set.add(n) ;
                }
            }
        }
        
        if ( query.getResultURIs() != null )
        {
            // Any URIs in the DESCRIBE
            for ( Iterator iter = query.getResultURIs().iterator() ; iter.hasNext() ; )
            {
                Node n = (Node)iter.next() ;
                RDFNode rNode = NodeUtils.convertGraphNodeToRDFNode(n, dataset.getDefaultModel()) ;
                set.add(rNode) ;
            }
        }

        // Notify start of describe phase
        
        DescribeHandlerRegistry dhReg = DescribeHandlerRegistry.get() ;
        for ( Iterator handlers = dhReg.handlers() ; handlers.hasNext() ; )
        {
            DescribeHandler dh = (DescribeHandler)handlers.next() ;
            dh.start(model, execContext) ;
        }
        
        // Do describe for each resource found.
        
        for (Iterator iter = set.iterator() ; iter.hasNext() ;)
        {
            RDFNode n = (RDFNode)iter.next() ;
        
            if ( n instanceof Resource )
            {
                Iterator handlers = dhReg.handlers() ;
                for ( ; handlers.hasNext() ; )
                {
                    DescribeHandler dh = (DescribeHandler)handlers.next() ;
                    dh.describe((Resource)n) ;
                }
            }
            else
                // Can't describe literals
                continue ;
        }
        
        // Notify end of describe phase
        for ( Iterator handlers = dhReg.handlers() ; handlers.hasNext() ; )
        {
            DescribeHandler dh = (DescribeHandler)handlers.next() ;
            dh.finish() ;
        }

        this.close() ;
        return model ; 
    }
    
    public boolean execAsk()
    {
        if ( ! query.isAskType() )
            throw new QueryExecException("Attempt to have boolean from a "+labelForQuery(query)+" query") ; 

        init() ;

        ResultSet results = execInternal() ;
        boolean r = results.hasNext() ;
        this.close() ;
        return r ; 
    }

    private ResultSet execInternal()
    {
        init() ;
        query.setResultVars() ;
        if ( query.getQueryPattern() == null )
            // No WHERE part to query
            return null ;
        
        resultsIter = execInternalGraph() ;
        
        Model model = null ;
        if ( dataset != null )
            model = dataset.getDefaultModel() ;
        if ( model == null )
        {
            Graph g = datasetGraph.getDefaultGraph() ;
            if ( g != null )
                model = ModelFactory.createModelForGraph(g) ;
            else
                model = null ;
        }
        
        // Not mods.projectVars which is List<Var>
        ResultSetStream rStream = new ResultSetStream(query.getResultVars(), model, resultsIter) ;
        
        // Set flags (the plan has the elements for solution modifiers)
        if ( query.hasOrderBy() )
            rStream.setOrdered(true) ;
        if ( query.isDistinct() )
            rStream.setDistinct(true) ;
        return rStream ;
    }
    
    private QueryIterator execInternalGraph()
    {
        init() ;
        Modifiers mods = getModifiers() ;
        Plan plan = queryToPlan(query, mods, query.getQueryPattern()) ;
        QueryIterator qIter = plan.iterator() ;
        resultsIter = qIter ;
        return resultsIter ;
    }
    
    protected Modifiers getModifiers()
    {
        Modifiers mods = new Modifiers(query) ;
        if ( query.isConstructType() )
            // Need to expose the initial bindings - no projection at all. 
            mods.projectVars = null ;
        return mods ;
    }
    
    static public class Modifiers
    {
        // And construct needs to avoid a projection.
        public long start ;
        public long length ;
        public boolean distinct ;
        public List projectVars ;      // Null for no projection
        public List orderConditions ;
        
        public Modifiers(Query query)
        {
            start = query.getOffset() ;
            length = query.getLimit() ;
            distinct = query.isDistinct() ;
            // TODO Var.varList(query.getResultVars()) ;
            projectVars = query.getResultVars() ;
            orderConditions = query.getOrderBy() ;
        }
    }

//    private void build() { build(false) ; }
//    
//    private void build(boolean surpressProject) { }
    
    // Further out ...
    
    /** Turn a query into a Plan - a thing that can produce the query iterator. */
    
    protected abstract 
    Plan queryToPlan(Query query, Modifiers modifiers, Element pattern) ;
    
    /** Abnormal end of this execution  */
    public void abort()
    {
        // The close operation below does not mind if the
        // query has not been exhausted.
        close(true) ;
    }

    /** Normal end of use of this execution  */
    public void close()
    {
        close(true) ;
    }
    
    /** End execution: if the iteration is already exhusted,
     * the main iterator will already be closed (and also for 
     * ASK, DESCRIBE, CONSTRUCT queries).  
     * 
     * @param forceClose Whether to shut the iterator anyway.
     */
    private void close(boolean forceClose)
    {
        if ( queryExecutionClosed )
            return ;
        
        if ( ! queryExecutionInitialised )
        {
            log.warn("Closing a query that has not been run") ;
            return ;
        }
        
        // If not forced close, the results iterator should have autoclosed already.
        if ( forceClose )
        {
            if ( resultsIter != null )
                resultsIter.close() ;
            resultsIter = null ;
        }
        
        // Now check for open iterators
        Iterator iter = execContext.listOpenIterators() ;
        while(iter.hasNext())
        {
            QueryIterator qIterOpen = (QueryIterator)iter.next() ;
            if ( qIterOpen instanceof QueryIter )
            {
                QueryIter qIterBase = (QueryIter)qIterOpen ;
                log.warn("Open iterator: "+qIterBase.getIteratorNumber()+" "+qIterOpen) ;
            }
            else
                log.warn("Open iterator: "+qIterOpen) ;
        }
        
        // Close it anyway
        if ( resultsIter != null )
            resultsIter.close() ;
        resultsIter = null ;
        queryExecutionClosed = true ;
    }
    
    private void insertPrefixesInto(Model model)
    {
        try {
            // Load the models prefixes first
            PrefixMapping m = datasetGraph.getDefaultGraph().getPrefixMapping() ;
            model.setNsPrefixes(m) ;
            
            // Then add the queries (just the declared mappings)
            // so the query declarations override the data sources. 
            model.setNsPrefixes(query.getPrefixMapping()) ;

        } catch (Exception ex)
        {
            log.warn("Exception in insertPrefixes: "+ex.getMessage(), ex) ;
        }
    }
    
    static private String labelForQuery(Query q)
    {
        if ( q.isSelectType() )     return "SELECT" ; 
        if ( q.isConstructType() )  return "CONSTRUCT" ; 
        if ( q.isDescribeType() )   return "DESCRIBE" ; 
        if ( q.isAskType() )        return "ASK" ;
        return "<<unknown>>" ;
    }
}

/*
 *  (c) Copyright 2004, 2005, 2006 Hewlett-Packard Development Company, LP
 *  All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in the
 *    documentation and/or other materials provided with the distribution.
 * 3. The name of the author may not be used to endorse or promote products
 *    derived from this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE AUTHOR ``AS IS'' AND ANY EXPRESS OR
 * IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES
 * OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED.
 * IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR ANY DIRECT, INDIRECT,
 * INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT
 * NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
 * DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
 * THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
 * (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF
 * THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */
