/*
 * (c) Copyright 2004, 2005, 2006 Hewlett-Packard Development Company, LP
 * [See end of file]
 */

package com.hp.hpl.jena.query.expr;

import com.hp.hpl.jena.query.core.Binding;
import com.hp.hpl.jena.query.engine1.ExecutionContext;

/** A function that has a single argument */
 
public abstract class ExprFunction1 extends ExprFunction
{
    Expr expr = null ;
    String opSymbol ;
    String opName ;

    protected ExprFunction1(Expr expr, String fName) { this(expr, fName, null) ; }
    
    protected ExprFunction1(Expr expr, String fName, String opSign)
    {
        super(fName, opSign) ;
        this.expr = expr ;
    }

    public Expr getArg() { return expr ; }

    public Expr getArg(int i)
    {
        if ( i == 1 )
            return expr ; 
        return null ;
    }
    
    public int hashCode()
    {
        return getFunctionSymbol().hashCode() ^
               getArg().hashCode() ;
    }

    public int numArgs() { return 1 ; }
    
    // ---- Evaluation
    
    final public NodeValue eval(Binding binding, ExecutionContext execCxt)
    {
        NodeValue s = evalSpecial(binding, execCxt) ;
        if ( s != null )
            return s ;
        
        NodeValue x = expr.eval(binding, execCxt) ;
        return eval(x) ;
    }
    
    public abstract NodeValue eval(NodeValue v) ;
    
    // Allow special cases.
    protected NodeValue evalSpecial(Binding binding, ExecutionContext execCxt) { return null ; } 
    
    final public Expr copySubstitute(Binding binding, int copyMode)
    {
        Expr e = copySubstituteWorker(expr, binding, copyMode) ;
        
        if ( copyMode == ExprNode.COPY_MODE_REDUCE_EXPR )
        {
            try {
                // Can evaluate now.
                if ( e.isConstant() )
                    return eval(e.getConstant()) ;
            } catch (ExprEvalException ex) { /* Drop through */ }
        }
        return copy(e) ;
    }

    // ---- Duplication
    
    // Avoid reflection later
    // Assumes a constructor of one Expr
    public abstract Expr copy(Expr expr) ;
    
//    final public Expr copy(Expr expr)
//    {
//        try
//        {
//            Constructor c = this.getClass().getConstructor(new Class[]{Expr.class}) ;
//            Object obj = c.newInstance(new Object[]{expr}) ;
//            return (Expr)obj ; 
//        } catch (Exception ex)
//        {
//            throw new ARQInternalErrorException("Failed to clone '"+this+"': "+ex.getMessage()) ;
//        }
//    }
}

/*
 *  (c) Copyright 2004, 2005, 2006 Hewlett-Packard Development Company, LP
 *  All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in the
 *    documentation and/or other materials provided with the distribution.
 * 3. The name of the author may not be used to endorse or promote products
 *    derived from this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE AUTHOR ``AS IS'' AND ANY EXPRESS OR
 * IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES
 * OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED.
 * IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR ANY DIRECT, INDIRECT,
 * INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT
 * NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
 * DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
 * THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
 * (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF
 * THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */
