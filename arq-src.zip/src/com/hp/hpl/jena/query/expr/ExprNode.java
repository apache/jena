/*
 * (c) Copyright 2004, 2005, 2006 Hewlett-Packard Development Company, LP
 * [See end of file]
 */

package com.hp.hpl.jena.query.expr;

import java.util.Collection;

import com.hp.hpl.jena.query.serializer.FmtExprARQ;
import com.hp.hpl.jena.query.core.Constraint ;
import com.hp.hpl.jena.query.core.Binding ;
import com.hp.hpl.jena.query.engine1.ExecutionContext;
import com.hp.hpl.jena.query.expr.nodevalue.Functions;
import com.hp.hpl.jena.query.util.IndentedLineBuffer ;


/** A node that is a constraint expression that can be evaluated
 * An Expr is already a Constraint - ExprNode is the base implementation
 * of all Expr classes that provides the Constraint machinary.
 * 
 * @author Andy Seaborne
 * @version $Id: ExprNode.java,v 1.26 2006/06/05 17:55:09 andy_seaborne Exp $
 */
 
public abstract class ExprNode implements Expr , Constraint
{
    // --- interface Constraint 
    public boolean isSatisfied(Binding binding,
                               ExecutionContext execCxt)
    {
        try {
            NodeValue v = eval(binding, execCxt) ;
            boolean b = Functions.effectiveBooleanValue(v) ;
            return b ;
        }
        catch (ExprEvalException ex)
        { 
            return false ;
        }
    }

    public boolean isExpr() { return true ; }
    public final Expr getExpr()   { return this ; }
    
    // --- interface Constraint
    
    public abstract NodeValue eval(Binding binding, ExecutionContext execCxt) ; 
    
    public void varsMentioned(Collection acc)
    {
        VarsVisitor vv = new VarsVisitor(acc) ;
        ExprWalker.walk(vv, this) ;
    }
    
    public abstract int     hashCode() ;
    public abstract boolean equals(Object other) ;
    /** Deep copy with substitution */ 
    public abstract Expr    copySubstitute(Binding binding) ;
    
    // ---- Default implementations
    public boolean isVariable() { return false ; }
    public String getVarName()  { return null ; } //throw new ExprException("Expr.getVarName called on non-variable") ; } 
    public NodeVar getVar()     { return null ; } //throw new ExprException("Expr.getVar called on non-variable") ; }
    
    public boolean isConstant() { return false ; }
    public NodeValue getConstant() { return null ; } // throw new ExprException("Expr.getConstant called on non-constant") ; }
    // ---- 
    
    public String toString()
    {
        IndentedLineBuffer buff = new IndentedLineBuffer() ;
        ExprVisitor v = new FmtExprARQ(buff.getIndentedWriter(), null) ;
        this.visit(v) ;
        return buff.toString() ;
    }
}

/*
 *  (c) Copyright 2004, 2005, 2006 Hewlett-Packard Development Company, LP
 *  All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in the
 *    documentation and/or other materials provided with the distribution.
 * 3. The name of the author may not be used to endorse or promote products
 *    derived from this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE AUTHOR ``AS IS'' AND ANY EXPRESS OR
 * IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES
 * OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED.
 * IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR ANY DIRECT, INDIRECT,
 * INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT
 * NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
 * DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
 * THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
 * (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF
 * THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */
