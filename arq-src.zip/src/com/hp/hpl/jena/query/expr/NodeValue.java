/*
 * (c) Copyright 2004, 2005, 2006 Hewlett-Packard Development Company, LP
 * [See end of file]
 */

package com.hp.hpl.jena.query.expr;

import java.math.BigDecimal;
import java.math.BigInteger;
import java.util.Calendar;

import com.hp.hpl.jena.query.ARQ;
import com.hp.hpl.jena.query.expr.nodevalue.*;

import org.apache.commons.logging.*;

import com.hp.hpl.jena.query.core.ARQInternalErrorException;
import com.hp.hpl.jena.query.core.Binding;
import com.hp.hpl.jena.query.engine1.ExecutionContext;
import com.hp.hpl.jena.query.serializer.SerializationContext;
import com.hp.hpl.jena.query.util.*;
import com.hp.hpl.jena.graph.Node ;
import com.hp.hpl.jena.graph.impl.LiteralLabel;
import com.hp.hpl.jena.datatypes.DatatypeFormatException;
import com.hp.hpl.jena.datatypes.RDFDatatype;
import com.hp.hpl.jena.datatypes.TypeMapper;
import com.hp.hpl.jena.datatypes.xsd.XSDDatatype;
import com.hp.hpl.jena.datatypes.xsd.XSDDateTime;

import com.hp.hpl.jena.vocabulary.XSD;
import com.hp.hpl.jena.shared.PrefixMapping;
import com.hp.hpl.jena.shared.impl.JenaParameters;


public abstract class NodeValue extends ExprNode
{
    /* Naming:
     * getXXX => plain accessor
     * asXXX =>  force to the required thing if necessary. 
     * 
     * Implementation notes:
     * 
     * 1. There is little point delaying turning a node into its value.
     *    Because a NodeValue is being created, it is almost certainly
     *    going to be used for it's value, so processing the datatype
     *    can be done at creation time for no loss of efficiency but
     *    it is clearer.
     *    
     * 2. Conversely, delaying turing a value into a graph node is
     *    valuable because intmediates, like the result of 2+3, will not
     *    be needed as nodes unless assignment (and there is no assignment
     *    in SPARQL even if there is for ARQ). 
     *    Node level operations like str() don't need a full node.
     *      
     * 3. The XQuery/Xpath functions and operations are implemented in
     *    a separate class Function for convenience.
     *    
     * 4. Note that SPARQL "=" is "known to be sameValeuAs". Similarly "!=" is
     *    known to be different.  And "not(=)" is different from "!="
     *    
     * 5. To add a new number type:
     *    Add sub type into nodevalue.NodeValueXXX
     *    Add Functions.add/subtract/etc code and compareNumeric
     *    Add to compare code
     *    Fix TestExprNumeric
     *    Write lots of tests.
     *    Library code Maths1 and Maths2 for maths functions
     */
    
    // Effective boolean value rules.
    //   boolean: value of the boolean 
    //   string: length(string) > 0 is true
    //   numeric: number != Nan && number != 0 is true
    // http://www.w3.org/TR/xquery/#dt-ebv
    
    private static Log log = 
        LogFactory.getLog(NodeValue.class) ;
    
    // ---- Constants and initializers / public
    
    public static boolean VerboseWarnings = true ;
    public static boolean VerboseExceptions = false ;
    
    private static final boolean sameValueAsString = JenaParameters.enablePlainLiteralSameAsString ;
    private static RefBoolean enableRomanNumerals = new RefBoolean(ARQ.enableRomanNumerals, false) ;
    private static RefBoolean strictSPARQL = new RefBoolean(ARQ.strictSPARQL, false) ;
    
    public static final BigInteger IntegerZERO = new BigInteger("0") ; // Java-1.5 :: BigInteger.ZERO ;
    public static final BigDecimal DecimalZERO = new BigDecimal("0") ; // Java-1.5 :: BigDecimal.ZERO ;

    public static final NodeValue TRUE   = NodeValue.makeNode("true", XSDDatatype.XSDboolean) ;
    public static final NodeValue FALSE  = NodeValue.makeNode("false", XSDDatatype.XSDboolean) ;
    
    // ---- State
    
    private Node node = null ;     // Null used when a value has not be turned into a Node.
    
    // Don't create direct - the static builders manage the value/node relationship 
    protected NodeValue() { super() ; }
    protected NodeValue(Node n) { super() ; node = n ; } 
    
//    protected makeNodeValue(NodeValue nv)
//    {
//        if ( v.isNode() )    { ... }
//        if ( v.isBoolean() ) { ... }
//        if ( v.isInteger() ) { ... }
//        if ( v.isDouble() )  { ... }
//        if ( v.isDecimal() ) { ... }
//        if ( v.isString() )  { ... }
//        if ( v.isDate() )    { ... } 
//        log.warn("Unknown NodeValue in constructor: "+v) ;
//    }

    // ----------------------------------------------------------------
    // ---- Construct NodeValue without a graph node.
    
    public static NodeValue makeInteger(long i)
    { return new NodeValueInteger(i) ; }
    
    public static NodeValue makeInteger(BigInteger i)
    { return new NodeValueInteger(i) ; }

    public static NodeValue makeInteger(String lexicalForm)
    { return new NodeValueInteger(new BigInteger(lexicalForm)) ; }

    public static NodeValue makeFloat(float f)
    { return new NodeValueFloat(f) ; }
    
    public static NodeValue makeDouble(double d)
    { return new NodeValueDouble(d) ; }

    public static NodeValue makeString(String s) 
    { return new NodeValueString(s) ; }

    public static NodeValue makeDecimal(BigDecimal d)
    { return new NodeValueDecimal(d) ; }
  
    public static NodeValue makeDecimal(long i)
    //{ return new NodeValueDecimal(new BigDecimal(i)) ; } // Java 1.5-ism - the long constructor.  If 1.4, type promotion to double :-( 
    { return new NodeValueDecimal(BigDecimal.valueOf(i)) ; }
  
    public static NodeValue makeDecimal(double d)
    { return new NodeValueDecimal(new BigDecimal(d)) ; }   // java 1.5 ; use BigDecimal.valueOf(double)
  
    public static NodeValue makeDecimal(String lexicalForm)
    { return NodeValue.makeNode(lexicalForm, XSDDatatype.XSDdecimal) ; }

    public static NodeValue makeDateTime(String lexicalForm)
    { return NodeValue.makeNode(lexicalForm, XSDDatatype.XSDdateTime) ; }
    
    public static NodeValue makeDateTime(Calendar cal)
    { return new NodeValueDateTime(cal) ; }

    public static NodeValue makeDate(String lexicalForm)
    { return NodeValue.makeNode(lexicalForm, XSDDatatype.XSDdate) ; }
    
    public static NodeValue makeDate(Calendar cal)
    { return new NodeValueDate(cal) ; }

    public static NodeValue makeBoolean(boolean b)
    { return b ? NodeValue.TRUE : NodeValue.FALSE ; }
    
    public static NodeValue booleanReturn(boolean b)
    { return b ? NodeValue.TRUE : NodeValue.FALSE ; }

    // ----------------------------------------------------------------
    // ---- Construct NodeValue from graph nodes 

    public static NodeValue makeNode(Node n)
    {
        NodeValue nv = nodeToNodeValue(n) ;
        return nv ;
    }
                               
    public static NodeValue makeNode(String lexicalForm, XSDDatatype dtype)
    {
        Node n = Node.createLiteral(lexicalForm, null, dtype) ;
        NodeValue nv = NodeValue.makeNode(n) ;
        return nv ;
    }

    // Convenience - knows that lang tags aren't allowed with datatypes.
    public static NodeValue makeNode(String lexicalForm, String langTag, Node datatype)
    {
        String uri = (datatype==null) ? null : datatype.getURI() ;
        return makeNode(lexicalForm, langTag,  uri) ;
    }

    public static NodeValue makeNode(String lexicalForm, String langTag, String datatype)
    {
        if ( datatype != null && datatype.equals("") )
            datatype = null ;
        
        if ( langTag != null && datatype != null )
            // raise??
            log.warn("Both lang tag and datatype defined (lexcial form '"+lexicalForm+"')") ;
        
        Node n = null ; 
        
        if ( datatype != null)
        {
            RDFDatatype dType = TypeMapper.getInstance().getSafeTypeByName(datatype) ;
            n = Node.createLiteral(lexicalForm, null, dType) ;
        }
        else
            n = Node.createLiteral(lexicalForm, langTag, null) ;
        return NodeValue.makeNode(n) ;
    }
    
    // ----------------------------------------------------------------
    // ---- Construct NodeValue with graph node and value. 

    public static NodeValue makeNodeBoolean(boolean b)
    { return b ? NodeValue.TRUE : NodeValue.FALSE ; }

    public static NodeValue makeNodeBoolean(String lexicalForm)
    {
        NodeValue nv = makeNode(lexicalForm, null, XSD.xboolean.getURI()) ;
        return nv ;
    }
    
    public static NodeValue makeNodeInteger(long v)
    {
        NodeValue nv = makeNode(Long.toString(v), null, XSD.integer.getURI()) ;
        return nv ;
    }
    
    public static NodeValue makeNodeInteger(String lexicalForm)
    {
        NodeValue nv = makeNode(lexicalForm, null, XSD.integer.getURI()) ;
        return nv ;
    }
    
    public static NodeValue makeNodeFloat(float f)
    {
        NodeValue nv = makeNode(Utils.stringForm(f), null, XSD.xfloat.getURI()) ;
        return nv ;
    }
    
    public static NodeValue makeNodeFloat(String lexicalForm)
    {
        NodeValue nv = makeNode(lexicalForm, null, XSD.xdouble.getURI()) ;
        return nv ;
    }
    
    public static NodeValue makeNodeDouble(double v)
    {
        NodeValue nv = makeNode(Utils.stringForm(v), null, XSD.xdouble.getURI()) ;
        return nv ;
    }
    
    public static NodeValue makeNodeDouble(String lexicalForm)
    {
        NodeValue nv = makeNode(lexicalForm, null, XSD.xdouble.getURI()) ;
        return nv ;
    }
    
    public static NodeValue makeNodeDecimal(BigDecimal decimal)
    {
        // Java 1.5-ism
        //NodeValue nv = makeNode(decimal.toPlainString(), null, XSD.decimal.getURI()) ;
        NodeValue nv = makeNode(Utils.stringForm(decimal), null, XSD.decimal.getURI()) ;
        return nv ;
    }

    public static NodeValue makeNodeDecimal(String lexicalForm)
    {
        NodeValue nv = makeNode(lexicalForm, null, XSD.decimal.getURI()) ;
        return nv ;
    }
    
    public static NodeValue makeNodeString(String string)
    {
        NodeValue nv = makeNode(string, null, (String)null) ;
        return nv ;
    }
    
    public static NodeValue makeNodeDateTime(Calendar date)
    {
        //XSDDateTime dt = new XSDDateTime(date) ;
        String lex = Utils.calendarToXSDDateTimeString(date) ;
        NodeValue nv = makeNode(lex, XSDDatatype.XSDdateTime) ;
        return nv ;
    }
    
    public static NodeValue makeNodeDateTime(String lexicalForm)
    {
        NodeValue nv = makeNode(lexicalForm, XSDDatatype.XSDdateTime) ;
        return nv ;
    }
    
    public static NodeValue makeNodeDate(Calendar date)
    {
        //XSDDateTime dt = new XSDDateTime(date) ;
        String lex = Utils.calendarToXSDDateString(date) ;
        NodeValue nv = makeNode(lex, XSDDatatype.XSDdate) ;
        return nv ;
    }
    
    public static NodeValue makeNodeDate(String lexicalForm)
    {
        NodeValue nv = makeNode(lexicalForm, XSDDatatype.XSDdate) ;
        return nv ;
    }
    
   // ----------------------------------------------------------------
   // ---- Expr interface
    
    public NodeValue eval(Binding binding, ExecutionContext execCxt)
    { return this ; }

    // NodeValues are immutable so no need to duplicate.
    public Expr copySubstitute(Binding binding, boolean foldConstants)
    {  // return this ; 
        Node n = asNode() ;
        return makeNode(n) ;
    }
    
    // New version
    public NodeValue evalNodeValue(Binding binding, ExecutionContext execCxt)
    {
         //return this ;
        System.err.println("eval - convert back to NodeValue") ;
        return null ;
    }

    public Node evalNode(Binding binding, ExecutionContext execCxt)
    {
        return asNode() ;
    }

    
    public boolean isConstant() { return true ; }

    public NodeValue getConstant()     { return this ; }
    
    // ----------------------------------------------------------------
    // ---- sameValueAs and comparison
    
    // Classes of comparision
    // Used incompatable, strict case ("<" etc)
    private static final int CLASS_UNDEF     = -5 ;
    
    // Disjoint value spaces : dateTime and dates are not comparable 
    private static final int CLASS_NUM       = 10 ;
    private static final int CLASS_DATETIME  = 11 ;
    private static final int CLASS_DATE      = 12 ;
    private static final int CLASS_STRING    = 13 ;
    private static final int CLASS_BOOLEAN   = 14 ;
    
    // Always possible in the general case (sorting)
    private static final int CLASS_NODE      = 15 ;

    /** Return true if the two NodeValues are known to be the same else false. */
    public static boolean sameValueAs(NodeValue nv1, NodeValue nv2)
    {
        // Currently csalled from E_Equals (only)
        if ( nv1 == null || nv2 == null )
            //raise(new ExprEvalException("Attempt to notSameValueAs on null") ;
            new ARQInternalErrorException("Attempt to sameValueAs on null") ;
        
        int compType = classifyOP(nv1, nv2, true) ;
        switch (compType)
        {
            case CLASS_NUM:        return Functions.compareNumeric(nv1, nv2) == 0 ;
            case CLASS_DATETIME:   return Functions.compareDateTime(nv1, nv2) == 0 ;
            case CLASS_DATE:       return Functions.compareDate(nv1, nv2) == 0 ;
            case CLASS_STRING:     return Functions.compareString(nv1, nv2) == 0 ;
            case CLASS_BOOLEAN:    return Functions.compareBoolean(nv1, nv2) == 0 ;
            case CLASS_NODE:
                // Unknown types - this will compare lexical forms and datatypes
                return nv1.getNode().equals(nv2.getNode()) ; 
            default:
            {
                // Not comparable (e.g. number and non number)
                // But everything is node-comparable so internal error
                //raise(new ExprEvalException("Can't sameValueAs "+nv1+" and "+nv2)) ;
                //return false ;
                throw new ARQInternalErrorException("Can't sameValueAs "+nv1+" and "+nv2) ;
            }
        }
    }
    
    /** Return true if the two NodeValues are known to be different else false.
     *  This is different from not(sameValueAs) for unknown datatypes.
     */
    public static boolean notSameValueAs(NodeValue nv1, NodeValue nv2)
    {
        // Currently called from E_NotEquals (only)

        if ( nv1 == null || nv2 == null )
            //raise(new ExprEvalException("Attempt to notSameValueAs on null") ;
            new ARQInternalErrorException("Attempt to notSameValueAs on null") ;
        
        int compType = classifyOP(nv1, nv2, true) ;

        switch (compType)
        {
            case CLASS_NUM:        return Functions.compareNumeric(nv1, nv2) != 0 ;
            case CLASS_DATETIME:   return Functions.compareDateTime(nv1, nv2) != 0 ;
            case CLASS_DATE:       return Functions.compareDate(nv1, nv2) != 0 ;
            case CLASS_STRING:     return Functions.compareString(nv1, nv2) != 0 ;
            case CLASS_BOOLEAN:    return Functions.compareBoolean(nv1, nv2) != 0 ;
            case CLASS_NODE:
                if ( nv1.hasKnownValue() &&  nv2.hasKnownValue() )
                    // Has a known value but can't compare
                    //   => disjoint value spaces => notSameValue => true
                    return true ;
                
                // Two nodes, at least one of unknown value type are != if and only if we
                // positively know them to be unequal.
                // (So things can be both "not =" and "not !=")
                
                // TODO Sort out notSameValueAs and sameValueAs 
                // Here if, different datatypes, then error (maybe the same - don't know)
                // Error throwing greatly simplifies this code.
                
                // Simplify.
                // Cases to consider:
                // 1/ literal != non-literal
                // 2/ Plain literal != unknown type
                // 3/ Lang tags.
                //return false ;
                
                
                Node n1 = nv1.getNode() ;
                Node n2 = nv2.getNode() ;
                
                if ( ! nv1.getNode().isLiteral() || ! n2.isLiteral() ) 
                    return !(n1.equals(nv2.getNode())) ;
                
                String dt1 = n1.getLiteralDatatypeURI() ;
                String dt2 = n2.getLiteralDatatypeURI() ;
                
                if ( sameValueAsString )
                {
                    // Force to plain string.
                    if ( dt1 != null && dt1.equals(XSDDatatype.XSDstring.getURI()) )
                        dt1 = null ;
                    if ( dt2 != null && dt2.equals(XSDDatatype.XSDstring.getURI()) )
                        dt2 = null ;
                }
                
                String lex1 = n1.getLiteralLexicalForm() ;
                String lex2 = n2.getLiteralLexicalForm() ;
                
                String lang1 = n1.getLiteralLanguage() ;
                if ( lang1 == null )
                    lang1 = "" ;
                
                String lang2 = n2.getLiteralLanguage() ;
                if ( lang2 == null )
                    lang2 = "" ;

                // ---- No datatype or xsd:String
                if ( dt1 == null && dt2 == null )
                {
                    // One had a lang tag?
                    if ( lang1.equals("") && lang2.equals("") )
                    {
                        log.warn("Internal error: Should be string comparisons, not unknown literals types") ;
                        return ! lex1.equals(lex2) ;
                    }
                    
                    if ( ! lang1.equals(lang2) )
                        // Different lang tags - must be different
                        return true ;
                    // Same lang tags
                    return ! lex1.equals(lex2) ;
                }
                
                // One datatype, one plain string (possibly with language tag) => not same
                // Not xsd:string
                
                if ( dt1 == null && dt2 != null )
                    return true ;
                
                if ( dt2 == null && dt1 != null )
                    return true ;
                
                // Two datatypes (not xsd:string)
                if ( ! dt1.equals(dt2) )
                    // Different unknown datatypes - not known to be different.
                    return false ;
                    
                // Tricky case - literals of unknown type but same datatype.
                // We do not know definitely that these two are different values
                // Maybe two lexical forms for the same value.
                // So "not equal" is in both cases:
                // 1 - Same lexical form => postively the same so notSameValueAs => false
                // 2 - Different lexicial forms => no idea => not known to be different => false
                
                return false ; 
                
            default:
            {
                throw new ARQInternalErrorException("Failed to carry out a noSameValueAs test") ;
            }
        }
        
    }

    // ----------------------------------------------------------------
    // compare
    // TODO Convert to use nodes - merge with NodeUtils code.
    
    /** Compare by value if possible else compare by kind/type/lexical form 
     *  Only use when you want an ordering regardless of form of NodeValue.
     *  It is more usual to use NodeValue.compare
     * @param nv1
     * @param nv2
     * @return negative, 0, or postive for less than, equal, greater than.  
     */

    public static int compareAlways(NodeValue nv1, NodeValue nv2)
    {
        try {
        return  compare(nv1, nv2, true) ;
        } catch (ExprNotComparableException ex)
        {
            nv1.forceToNode() ;
            nv2.forceToNode() ;
            return NodeUtils.compareNodesByKindTypeLexical(nv1.getNode(), nv2.getNode()) ;
        }
    }
    
    /** Compare by value (and only value) if possible.
     *  Supports <, <=, >, >= but not = nor != (which are sameValueAs and notSameValueAs)
     * @param nv1
     * @param nv2
     * @return negative, 0 , or positive for not possible, less than, equal, greater than.
     * @throws ExprEvalException  
     */
    public static int compare(NodeValue nv1, NodeValue nv2)
    {
        if ( nv1 == null || nv2 == null )
            //raise(new ExprEvalException("Attempt to notSameValueAs on null") ;
            new ARQInternalErrorException("Attempt to compare on null") ;
        int x = compare(nv1, nv2, false) ;
        return x ;
    }
    
    private static int compare(NodeValue nv1, NodeValue nv2, boolean generalCompare)
    {
        if ( nv1 == null && nv2 == null )
            return Expr.CMP_EQUAL ;
        
        if ( nv1 == null )
            return Expr.CMP_LESS ;
        if ( nv2 == null )
            return Expr.CMP_GREATER ;
        
        int compType = classifyOP(nv1, nv2, generalCompare) ;
        
        // Booleans only comapre when sorting.
        if ( compType == CLASS_BOOLEAN && ! generalCompare )
            compType = CLASS_UNDEF ;
        
        
        switch (compType)
        {
            case CLASS_NUM:        return Functions.compareNumeric(nv1, nv2) ;
            case CLASS_DATETIME:   return Functions.compareDateTime(nv1, nv2) ;
            case CLASS_DATE:       return Functions.compareDate(nv1, nv2) ;
            case CLASS_STRING:     return Functions.compareString(nv1, nv2) ;
            case CLASS_BOOLEAN:    return Functions.compareBoolean(nv1, nv2) ;
            case CLASS_NODE:
                // Drop through when unknown (not comparable) types.
            default:
            {
                if ( ! generalCompare )
                    raise(new ExprNotComparableException("Can't compare "+nv1+" and "+nv2)) ;
                throw new ExprNotComparableException("Can't compare "+nv1+" and "+nv2) ;
            }
        }
    }

    private static int classifyOP(NodeValue nv1, NodeValue nv2, boolean mayForce)
    {
        int x = classifyStrict(nv1, nv2) ;
        if ( x == CLASS_UNDEF && mayForce )
        {
            nv1.forceToNode() ;
            nv2.forceToNode() ;
            x = CLASS_NODE ;
        }
        return x ; 
    }
    
    private static int classifyStrict(NodeValue nv1, NodeValue nv2)
    {
        int c1 = classify(nv1) ;
        int c2 = classify(nv2) ;
        if ( c1 == c2 ) return c1 ;
        return CLASS_UNDEF ;
    }
        
    private static int classify(NodeValue nv)
    {
        if ( nv.isNumber() )   return CLASS_NUM ;
        if ( nv.isDateTime() ) return CLASS_DATETIME ;
        
        if ( ! strictSPARQL.getValue() )
            if ( nv.isDate() )
                return CLASS_DATE ;
        if ( nv.isString())    return CLASS_STRING ;
        if ( nv.isBoolean())   return CLASS_BOOLEAN ;
        return CLASS_NODE ;
    }
        
    // ----------------------------------------------------------------
    // ---- Node operations
    
    public static Node toNode(NodeValue nv)
    {
        if ( nv == null )
            return null ;
        return nv.asNode() ;
    }
        
    public final Node asNode()
    { 
        if ( node == null )
            node = makeNode() ;
        return node ;
    }
    protected abstract Node makeNode() ;
    
    public Node getNode() { return node ; }
    
    public boolean hasNode() { return node != null ; }

    // ----------------------------------------------------------------
    // ---- Subclass operations 
    
    // One of the known types. 
    public boolean hasKnownValue()    { return isBoolean() || isNumber() || isString() || isDateTime() || isDate() ; }
    
    //Don't forget: dynamicNumberConversion
    
    public boolean isBoolean()     { return false ; } 
//    public boolean isBooleanValue()      { return false ; }
//    public boolean isBooleanBEV()
//    { return isBooleanValue() || isNumber() || isString() ; }

    public boolean isString()      { return false ; } 

    public boolean isNumber()      { return false ; }
    public boolean isInteger()     { return false ; }
    public boolean isDecimal()     { return false ; }
    public boolean isFloat()       { return false ; }
    public boolean isDouble()      { return false ; }
    
    public boolean isDateTime()    { return false ; }
    public boolean isDate()        { return false ; }
    // getters
    
    public boolean getBoolean()
    { raise(new ExprEvalException("Not a boolean: "+this)) ; return false ; }
    
    public String      getString()   { raise(new ExprEvalException("Not a string: "+this)) ; return null ; }
    public BigInteger  getInteger()  { raise(new ExprEvalException("Not an int: "+this)) ; return null ; }
    public BigDecimal  getDecimal()  { raise(new ExprEvalException("Not a decimal: "+this)) ; return null ; }
    public float       getFloat()    { raise(new ExprEvalException("Not a float: "+this)) ; return Float.NaN ; }
    public double      getDouble()   { raise(new ExprEvalException("Not a double: "+this)) ; return Double.NaN ; }
    public Calendar    getDateTime() { raise(new ExprEvalException("Not a dateTime: "+this)) ; return null ; }
    public Calendar    getDate()     { raise(new ExprEvalException("Not a date: "+this)) ; return null ; }

//    // ---- Force to a type : Needed? 
//    
//    public boolean asBoolean() { raise(new ExprEvalException("Not compatible with boolean: "+this)) ; return false ; } 
//
//    //public String asString() { raise(new ExprEvalException("Not a string: "+this)) ; return null ; }
//
//    public long asInteger()  { raise(new ExprEvalException("Not compatible with integer: "+this)) ; return -999 ; }
//    public double asDouble() { raise(new ExprEvalException("Not compatible with double: "+this)) ; return Double.NaN ; }
//    public float asFloat()   { raise(new ExprEvalException("Not compatible with float: "+this)) ; return Float.NaN ; }
//    public BigDecimal asDecimal() { raise(new ExprEvalException("Not compatible with decimal: "+this)) ; return null ; }
//    public Calendar asDate() { raise(new ExprEvalException("Not compatible with a date: "+this)) ; return null ; }
    

    // ----------------------------------------------------------------
    // ---- Setting : used when a node is used to make a NodeValue
    
    private static NodeValue nodeToNodeValue(Node node)
    {
        if ( ! node.isLiteral() )
            // Not a literal - no value to extract
            return new NodeValueNode(node) ;

        boolean hasLangTag = ( node.getLiteralLanguage() != null && ! node.getLiteralLanguage().equals("")) ;
        boolean isPlainLiteral = ( node.getLiteralDatatypeURI() == null && ! hasLangTag ) ; 
            
        if ( isPlainLiteral )
            return new NodeValueString(node.getLiteralLexicalForm(), node) ;

        if ( hasLangTag )
        {
            if ( node.getLiteralDatatypeURI() != null )
            {
                if ( NodeValue.VerboseWarnings )
                    log.warn("Lang tag and datatype (datatype ignored)") ;
                else if ( log.isDebugEnabled() )
                    log.debug("Lang tag and datatype (datatype ignored)") ; 
            }
            return new NodeValueNode(node) ;
        }

        // Typed literal
        LiteralLabel lit = node.getLiteral() ;
        
        
        // This includes type testing
        if ( ! lit.getDatatype().isValidLiteral(lit) )
        {
            if ( NodeValue.VerboseWarnings )
            {
                String tmp =  FmtUtils.stringForNode(node, PrefixMapping.Standard) ;
                log.warn("Datatype format exception: "+tmp) ;
            }
            else if ( log.isDebugEnabled() )
            {
                String tmp =  FmtUtils.stringForNode(node, PrefixMapping.Standard) ;
                log.debug("Datatype format exception: "+tmp) ;
            }
            // Invalid lexical form.
            return new NodeValueNode(node) ;
        }
        
        NodeValue nv = _setByValue(node) ;
        if ( nv != null )
            return nv ;
            
        // No idea.  
        if ( log.isDebugEnabled() )
            log.debug("Unrecognized literal: "+node) ;
        return new NodeValueNode(node) ;
        //raise(new ExprException("NodeValue.nodeToNodeValue: Unknown Node type: "+n)) ;
             
    }

    // Returns null for unrecognized literal.
    private static NodeValue _setByValue(Node node)
    {
        LiteralLabel lit = node.getLiteral() ;
        
        try { // DatatypeFormatException - should not happen

            if ( sameValueAsString && XSDDatatype.XSDstring.isValidLiteral(node.getLiteral()) ) 
                    // String - plain or xsd:string
                return new NodeValueString(lit.getLexicalForm(), node) ;
            
            // Otherwise xsd:string is like any other unknown datatype.
            // Ditto literals with language tags (which are handled by nodeToNodeValue)
            
            // isValidLiteral is a value test - not a syntactic test.  
            // This makes a diffeence in that "1"^^xsd:decimal" is a
            // valid literal for xsd:integer (all other cases are subtypes of xsd:integer)
            // which we want to become integer anyway).

            // Order here is promotion order integer-decimal-float-double
            
            if ( ! node.getLiteralDatatype().equals(XSDDatatype.XSDdecimal) ) 
            {
                if ( XSDDatatype.XSDinteger.isValidLiteral(lit) )
                {
                    // Includes subtypes (int, byte, postiveInteger etc).
                    // NB Known to be valid for type by now
                    long i = ((Number)lit.getValue()).longValue() ;
                    return new NodeValueInteger(i, node) ;
                }
            }
            
            if ( XSDDatatype.XSDdecimal.isValidLiteral(lit) )
            {
                BigDecimal decimal = new BigDecimal(lit.getLexicalForm()) ;
                return new NodeValueDecimal(decimal, node) ;
            }
            
            if ( XSDDatatype.XSDfloat.isValidLiteral(lit) )
            {
                // NB If needed, call to floatValue, then assign to double.
                // Gets 1.3f != 1.3d right
                float f = ((Number)lit.getValue()).floatValue() ;
                return new NodeValueFloat(f, node) ;
            }

            if ( XSDDatatype.XSDdouble.isValidLiteral(lit) )
            {
                double d = ((Number)lit.getValue()).doubleValue() ;
                return new NodeValueDouble(d, node) ;
            }

            if ( XSDDatatype.XSDdateTime.isValidLiteral(lit) ) 
            {
                XSDDateTime dateTime = (XSDDateTime)lit.getValue() ;
                return new NodeValueDateTime(dateTime.asCalendar(), node) ;
            }
            
            if ( !strictSPARQL.getValue() && XSDDatatype.XSDdate.isValidLiteral(lit) )
            {
                // Jena datatype support works on masked dataTimes. 
                XSDDateTime dateTime = (XSDDateTime)lit.getValue() ;
                return new NodeValueDate(dateTime.asCalendar(), node) ;
            }
            
            if ( XSDDatatype.XSDboolean.isValidLiteral(lit) )
            {
                boolean b = ((Boolean)lit.getValue()).booleanValue() ;
                return new NodeValueBoolean(b, node) ;
            }
            
            // If wired into the TypeMapper via RomanNumeralDatatype.enableAsFirstClassDatatype
//            if ( RomanNumeralDatatype.get().isValidLiteral(lit) )
//            {
//                int i = ((RomanNumeral)lit.getValue()).intValue() ;
//                return new NodeValueInteger(i) ; 
//            }
            
            // Not wired in - crude test but works always
            if ( !strictSPARQL.getValue() && enableRomanNumerals.getValue() )
            {
                if ( lit.getDatatypeURI().equals(RomanNumeralDatatype.get().getURI()) )
                {
                    Object obj = RomanNumeralDatatype.get().parse(lit.getLexicalForm()) ;
                    if ( obj instanceof Integer )
                        return new NodeValueInteger(((Integer)obj).longValue()) ; 
                    if ( obj instanceof RomanNumeral )
                        return new NodeValueInteger( ((RomanNumeral)obj).intValue() ) ;
                    throw new ARQInternalErrorException("DatatypeFormatException: Roman numeral is unknown class") ;
                }
            }            
            
        } catch (DatatypeFormatException ex)
        {
            // Should have been caught earlier by special test in nodeToNodeValue
            throw new ARQInternalErrorException("DatatypeFormatException: "+lit, ex) ;
        }
        return null ;
    }
    
    // ----------------------------------------------------------------
    
    // Point to catch all exceptions.
    public static void raise(ExprException ex)
    {
        if ( log.isDebugEnabled() )
            log.debug("Exception: "+ex.getMessage()) ;
        throw ex ; 
    }

    public void visit(ExprVisitor visitor) { visitor.visit(this) ; }

    private void forceToNode()
    {
        if ( node == null ) 
            node = asNode() ;
        
        if ( node == null )
            raise(new ExprEvalException("Not a node: "+this)) ;
    }
    
    // ---- Formatting (suitable for SPARQL syntax).
    // Usually done by being a Node and formatting that.
    // In desperation, will try toString() (no quoting)
    
    public final String asUnquotedString()
    { return asString() ; }

    public final String asQuotedString()
    { return asQuotedString(null) ; }

    public final String asQuotedString(SerializationContext context)
    { 
        // If possible, make a node and use that as the formatted output.
        if ( node == null )
            node = asNode() ;
        if ( node != null )
            return FmtUtils.stringForNode(node, context) ;
        return toString() ;
    }

    // Convert to a string  - usually overridden.
    public String asString()
    {
        // Do not call .toString() 
        forceToNode() ;
        return NodeFunctions.str(node) ;
    }
    
    public int hashCode() {
        forceToNode() ;
        return asNode().hashCode() ;
    }
   
    public boolean equals(Object other)
    {
        if ( other == null ) return false ;

        if ( ! ( other instanceof NodeValue ) )
            return false ;

        NodeValue nv = (NodeValue)other ;
        // TODO Use Functions.compare??
        // This is compare?
        
        if ( isInteger() && nv.isInteger() )
            return this.getInteger().equals(nv.getInteger()) ;
        if ( isBoolean() && nv.isBoolean() )
            return this.getBoolean() == nv.getBoolean() ;
        
        if ( isDecimal() && nv.isDecimal() )
            return this.getDecimal().compareTo(nv.getDecimal()) == 0 ;

        if ( isFloat() && nv.isFloat() )
            return this.getFloat() == nv.getFloat() ;
        
        if ( isDouble() && nv.isDouble() )
            return this.getDouble() == nv.getDouble() ;
        
        if ( isDateTime() && nv.isDateTime() )
            return this.getDateTime().equals(nv.getDateTime()) ;
        if ( isString() && nv.isString() )
            return this.getString().equals(nv.getString()) ;
        
        // Force to nodes
        asNode() ;
        nv.asNode() ;
        if ( getNode() != null && nv.getNode() != null )
            return this.getNode().equals(nv.getNode()) ;

        //raise(new ExprTypeException("Unknown value: "+this)) ;
        return false ;
    }

    public String toString()
    { 
        return asQuotedString() ;
    }
}

/*
 *  (c) Copyright 2004, 2005, 2006 Hewlett-Packard Development Company, LP
 *  All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in the
 *    documentation and/or other materials provided with the distribution.
 * 3. The name of the author may not be used to endorse or promote products
 *    derived from this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE AUTHOR ``AS IS'' AND ANY EXPRESS OR
 * IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES
 * OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED.
 * IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR ANY DIRECT, INDIRECT,
 * INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT
 * NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
 * DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
 * THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
 * (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF
 * THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */
