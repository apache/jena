/*
 * (c) Copyright 2006 Hewlett-Packard Development Company, LP
 * All rights reserved.
 * [See end of file]
 */

package com.hp.hpl.jena.query.engine2;

import java.util.ArrayList;
import java.util.List;

import com.hp.hpl.jena.query.core.Binding;
import com.hp.hpl.jena.query.engine.QueryIterator;
import com.hp.hpl.jena.query.engine1.ExecutionContext;
import com.hp.hpl.jena.query.engine1.iterator.*;
import com.hp.hpl.jena.query.engine1.plan.BindingImmutable;
import com.hp.hpl.jena.query.engine2.table.TableSimple;
import com.hp.hpl.jena.query.expr.Expr;

public class EvaluatorFactory
{
    public static Evaluator create(ExecutionContext context) { return new EvaluatorSimple(context) ; }

    static class EvaluatorSimple implements Evaluator
    {
        // Simple, slow, correct

        private ExecutionContext context ;
        boolean debug = false ;

        EvaluatorSimple(ExecutionContext context)
        {
            this.context = context ;
        }

        public ExecutionContext getExecContext()
        { return context ; }

        private Table joinWorker(Table tableLeft, Table tableRight, boolean leftJoin, Expr condition)
        {
            // Conditional LeftJoin is (left, Filter(expr, Join(left, right)))
            // This is done in matchRightLeft

            // Have an iterator that yields one-by-one.
            QueryIterator left = tableLeft.iterator(context) ;
            QueryIterConcat output = new QueryIterConcat(context) ;
            for ( ; left.hasNext() ; )
            {
                Binding b = left.nextBinding() ;
                QueryIterator x = tableRight.matchRightLeft(b, leftJoin, condition, context) ;
                if ( x == null )
                    continue ;
                output.add(x) ;
            }
            tableLeft.close() ;
            tableRight.close() ;
            return new TableSimple(output) ;
        }

        public Table join(Table tableLeft, Table tableRight)
        {
            if ( debug )
            {
                System.out.println("Join") ;
                tableLeft.dump() ;
                tableRight.dump() ;
            }
            return joinWorker(tableLeft, tableRight, false, null) ;
        }

        public Table leftJoin(Table tableLeft, Table tableRight, Expr expr)
        {
            if ( debug )
            {
                System.out.println("Left Join") ;
                tableLeft.dump() ;
                tableRight.dump() ;
                if ( expr != null )
                    System.out.println(expr.toString()) ;
            }
            
            return joinWorker(tableLeft, tableRight, true, expr) ;
        }

        public Table restriction(Expr expression, Table table)
        {
            if ( debug )
            {
                System.out.println("Restriction") ;
                System.out.println(expression.toString()) ;
                table.dump() ;
            }
            // TODO Make this streaming.
            QueryIterator iter = table.iterator(context) ;
            List output = new ArrayList() ;
            for ( ; iter.hasNext() ; )
            {
                Binding b = iter.nextBinding() ;
                if ( expression.isSatisfied(b, context) )
                    output.add(b) ;
            }
            return new TableSimple(new QueryIterPlainWrapper(output.iterator(), context)) ;
        }

        public Table union(Table tableLeft, Table tableRight)
        {
            if ( debug )
            {
                System.out.println("Union") ;
                tableLeft.dump() ;
                tableRight.dump() ;
            }
            QueryIterConcat output = new QueryIterConcat(context) ;
            output.add(tableLeft.iterator(context)) ;
            output.add(tableRight.iterator(context)) ;
            return new TableSimple(output) ;
        }

        public Table order(Table table, List conditions)
        {
            QueryIterator qIter = table.iterator(getExecContext()) ;
            qIter = new QueryIterSort(qIter, conditions, getExecContext()) ;
            return new TableSimple(qIter) ;
        }

        public Table project(Table table, List vars)
        {
            QueryIterator qIter = table.iterator(getExecContext()) ;
            qIter = new QueryIterProject(qIter, vars, getExecContext()) ;
            return new TableSimple(qIter) ;
        }

        public Table distinct(Table table, List vars)
        {
            QueryIterator qIter = table.iterator(getExecContext()) ;
            qIter = BindingImmutable.create(vars, qIter, context) ;
            qIter = new QueryIterDistinct(qIter, getExecContext()) ;
            return new TableSimple(qIter) ;
        }

        public Table slice(Table table, long start, long length)
        {
            QueryIterator qIter = table.iterator(getExecContext()) ;
            qIter = new QueryIterLimitOffset(qIter, start, length, getExecContext()) ;
            return new TableSimple(qIter) ;
        }
        
        
        
//        public Table graph(Node node, Table table)
//        {
//            throw new ARQNotImplemented("TableEngineSimple.graph") ;
//        }
    }

}

/*
 * (c) Copyright 2006 Hewlett-Packard Development Company, LP
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in the
 *    documentation and/or other materials provided with the distribution.
 * 3. The name of the author may not be used to endorse or promote products
 *    derived from this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE AUTHOR ``AS IS'' AND ANY EXPRESS OR
 * IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES
 * OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED.
 * IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR ANY DIRECT, INDIRECT,
 * INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT
 * NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
 * DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
 * THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
 * (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF
 * THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */