/*
 * (c) Copyright 2006 Hewlett-Packard Development Company, LP
 * All rights reserved.
 * [See end of file]
 */

package com.hp.hpl.jena.query.engine2.op;

import com.hp.hpl.jena.query.engine.QueryIterator;
import com.hp.hpl.jena.query.engine1.ExecutionContext;
import com.hp.hpl.jena.query.engine1.plan.PlanElementExternalBase;
import com.hp.hpl.jena.query.engine2.Table;

public class PlanElementOp extends PlanElementExternalBase
{
    Op op ;
    public PlanElementOp(Op op) { this.op = op ; }
    
    public QueryIterator build(QueryIterator input, ExecutionContext execCxt)
    {
        // This does not work - suppose the top is a filter.
        Op thisOp = op ;
//        
//        if ( thisOp instanceof Op2 )
//        {
//            Op2 op2 = (Op2)thisOp;
//            if ( op2.getLeft() instanceof TableUnit )
//                op2.setLeft(new TableSimple(input)) ;
//        }
//        else
//        {
//            Table inputTable = new TableSimple(input) ;  
//            thisOp = new OpJoin(inputTable, thisOp) ;
//        }

        // Assume the input is the root.
        // Else do the join thing below.
        
        if ( ! input.hasNext() )
            System.err.println("Warning: input is empty");
        else
        {
            input.nextBinding() ;
            if ( input.hasNext() )
                System.err.println("Warning: input has 2+ elements");
        }
        input.close();
        
        Table t = thisOp.eval(TableEngineFactory.create(execCxt)) ;
        
        return t.iterator(execCxt) ;
    }
}

/*
 * (c) Copyright 2006 Hewlett-Packard Development Company, LP
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in the
 *    documentation and/or other materials provided with the distribution.
 * 3. The name of the author may not be used to endorse or promote products
 *    derived from this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE AUTHOR ``AS IS'' AND ANY EXPRESS OR
 * IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES
 * OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED.
 * IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR ANY DIRECT, INDIRECT,
 * INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT
 * NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
 * DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
 * THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
 * (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF
 * THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */