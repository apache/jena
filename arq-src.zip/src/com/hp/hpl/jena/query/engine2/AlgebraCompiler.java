/*
 * (c) Copyright 2006 Hewlett-Packard Development Company, LP
 * All rights reserved.
 * [See end of file]
 */

package com.hp.hpl.jena.query.engine2;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import com.hp.hpl.jena.graph.Node;
import com.hp.hpl.jena.query.core.*;
import com.hp.hpl.jena.query.engine2.op.*;
import com.hp.hpl.jena.query.expr.Expr;
import com.hp.hpl.jena.query.util.Context;
import com.hp.hpl.jena.query.util.Utils;

public class AlgebraCompiler 
{
    // TODO Cope with incoming input QueryIterator
    
    protected Context context ;
    public AlgebraCompiler(Context context) {this.context  = context ; }
    
    public static Op compile(Element elt, Context context)
    {
        return new AlgebraCompiler(context).compileFixedElement(elt) ;
    }

//    public PlanElement compileElement(Element el)
//    {
//        if ( ! ( el instanceof ElementGroup ) )
//            // Punt to QueryEngine1?
//            //return QueryPatternCompiler.makePlan(context, el) ;
//            throw new ARQInternalErrorException("Algebra: can only compile a group") ;
//        ElementGroup elg = (ElementGroup)el ;
//        Op op = compile(elg) ;
//   
//        if ( verbose )
//            OpWriter.out(System.out, op) ;
//        
//        return new PlanElementOp(op) ;
//    }
    
    protected Op compile(ElementBasicGraphPattern el)
    {
        Op op = new OpBGP(el.getTriples(), el) ;
        return op ;
    }


    protected Op compile(ElementUnion el)
    { 
        if ( el.getElements().size() == 1 )
        {
            Element subElt = (Element)el.getElements().get(0) ;
            ElementGroup elg = (ElementGroup)subElt ;
            return compile(elg) ;
        }
        
        Op current = null ;
        
        for (Iterator iter = el.getElements().listIterator() ; iter.hasNext() ; )
        {
            Element subElt = (Element)iter.next() ;
            ElementGroup elg = (ElementGroup)subElt ;
            Op op = compile(elg) ;
            if ( current == null )
                current = op ;
            else
                current = new OpUnion(current, op) ;
        }
        return current ;
    }

    protected Op compile(ElementGroup groupElt)
    {
        List filters = new ArrayList() ;
        Op current = TableFactory.createUnit() ;
        
        for (Iterator iter = groupElt.getElements().listIterator() ; iter.hasNext() ; )
        {
            Element elt = (Element)iter.next() ;
            
            if (  elt instanceof ElementFilter )
            {
                ElementFilter f = (ElementFilter)elt ; 
                filters.add(f.getExpr()) ;
                continue ;
            }
            
            if ( elt instanceof ElementOptional )
            {
                ElementOptional eltOpt = (ElementOptional)elt ;
                Element subElt = eltOpt.getOptionalElement() ;
                Op op = compileFixedElement(subElt) ;
                Expr expr = null ;
                if ( op instanceof OpFilter )
                {
                    OpFilter f = (OpFilter)op ;
                    Op sub = f.getSubOp() ;
                    if ( sub instanceof OpFilter )
                        broken("compile/Optional/nested filters - unfinished") ; 
                    expr = f.getExpr() ;
                    op = sub ;
                }
                current = OpLeftJoin.create(current, op, expr) ;
                continue ;
            }

            if ( elt instanceof ElementGroup || 
                 elt instanceof ElementBasicGraphPattern ||
                 elt instanceof ElementNamedGraph ||
                 elt instanceof ElementUnion )
            {
                Op op = compileFixedElement(elt) ;
                current = OpJoin.create(current, op) ;
                continue ;
            }
            
            broken("compile/group: not a fixed element, optional or filter: "+Utils.className(elt)) ;
        }
        
        for ( Iterator iter = filters.iterator() ; iter.hasNext() ; )
        {
            // avoid filter(filter(...)) by having a static to make filters.
            Expr expr = (Expr)iter.next();
            if ( current == null )
                current = TableFactory.createUnit() ;
            current = OpFilter.filter(expr, current) ;
        }
        
        return current ;
    }

    protected Op compile(ElementNamedGraph eltGraph)
    {
        Node graphNode = eltGraph.getGraphNameNode() ;
        Op sub = compileFixedElement(eltGraph.getElement()) ;
        return new OpGraph(graphNode, sub) ;
    }

    protected Op compileFixedElement(Element elt)
    {
        // Visitor with a result.  Easier in Java5.
      if ( elt instanceof ElementBasicGraphPattern )
          return compile((ElementBasicGraphPattern)elt) ; 
      
      if ( elt instanceof ElementUnion )
          return compile((ElementUnion)elt) ;

      if ( elt instanceof ElementGroup )
          return compile((ElementGroup)elt) ;

      if ( elt instanceof ElementNamedGraph )
          return compile((ElementNamedGraph)elt) ; 

      broken("compileFixedElement/Not a fixed element: "+Utils.className(elt)) ;
      return null ;
    }

    private void broken(String msg)
    {
        System.err.println("AlgebraCompiler: "+msg) ;
        throw new ARQInternalErrorException(msg) ;
    }
}

/*
 * (c) Copyright 2006 Hewlett-Packard Development Company, LP
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in the
 *    documentation and/or other materials provided with the distribution.
 * 3. The name of the author may not be used to endorse or promote products
 *    derived from this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE AUTHOR ``AS IS'' AND ANY EXPRESS OR
 * IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES
 * OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED.
 * IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR ANY DIRECT, INDIRECT,
 * INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT
 * NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
 * DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
 * THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
 * (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF
 * THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */