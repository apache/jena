/*
 * (c) Copyright 2006 Hewlett-Packard Development Company, LP
 * All rights reserved.
 * [See end of file]
 */

package com.hp.hpl.jena.query.engine2;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Stack;

import com.hp.hpl.jena.query.core.*;
import com.hp.hpl.jena.query.engine.QueryIterator;
import com.hp.hpl.jena.query.engine1.PlanElement;
import com.hp.hpl.jena.query.engine1.iterator.QueryIterSingleton;
import com.hp.hpl.jena.query.engine1.plan.PlanBasicGraphPattern;
import com.hp.hpl.jena.query.engine2.op.*;
import com.hp.hpl.jena.query.expr.Expr;
import com.hp.hpl.jena.query.util.Context;
import com.hp.hpl.jena.query.util.Utils;

public class AlgebraCompiler 
{
    // TODO Cope with incoming input QueryIterator on :: PlanElementOp
    // TODO Sort group into fixed, filter and optionals
    // TODO Optional: including the complicated filter case
    // TODO : Optional/Group rewrites
    
    protected Context context ;
    private Stack retStack = new Stack() ;
    
    static class Block
    {
        List conjuncts = new ArrayList() ; 
        List filters   = new ArrayList() ;
        List optionals = new ArrayList() ;
    }
    
    
    public AlgebraCompiler(Context context) {this.context  = context ;}
    
    public static PlanElement compileElement(Element el, Context context)
    {
        return new AlgebraCompiler(context).compileElement(el) ;
    }
    
    public PlanElement compileElement(Element el)
    {
        if ( ! ( el instanceof ElementGroup ) )
            throw new ARQInternalErrorException("Algebra: can only compile a group") ;
        ElementGroup elg = (ElementGroup)el ;
        Op op = compile(elg) ;
        
        OpWriter.out(System.out, op) ;
        
        return new PlanElementOp(op) ;
    }
    
    Op compile(ElementBasicGraphPattern el)
    {
        PlanElement planElt = PlanBasicGraphPattern.make(context, el) ;
        Op op = new OpPlanElement(planElt) ;
        return op ;
    }


    Op compile(ElementUnion el)
    { 
        if ( el.getElements().size() == 1 )
        {
            Element subElt = (Element)el.getElements().get(0) ;
            ElementGroup elg = (ElementGroup)subElt ;
            return compile(elg) ;
        }
        
        Op current = null ;
        
        for (Iterator iter = el.getElements().listIterator() ; iter.hasNext() ; )
        {
            Element subElt = (Element)iter.next() ;
            ElementGroup elg = (ElementGroup)subElt ;
            Op op = compile(elg) ;
            if ( current == null )
                current = op ;
            else
                current = new OpUnion(current, op) ;
        }
        return current ;
    }


    Op compile(ElementGroup el)
    {
//      if ( el.getElements().size() == 1 )
//      return compileOneELement((Element)el.getElements().get(0)) ;
        
        Op current = null ;
        // Not null but "to be filled"
        List blocks = groupToBlocks(el) ;
        for (Iterator iter = blocks.listIterator() ; iter.hasNext() ; )
        {
            Block block = (Block)iter.next();
            current = compileBlock(current, block) ;
        }
        return current ;
        
    }
        
        
    private Op compileBlock(Op current, Block block)
    {
        // Simple, canonical form
        for (Iterator iter = block.conjuncts.listIterator() ; iter.hasNext() ; )
        {
            Element el = (Element)iter.next();
            Op op = compileFixedElement(el) ;
            current = createJoin(current, op) ;
        }
        
        for (Iterator iter = block.filters.listIterator() ; iter.hasNext() ; )
        {
            // avoid filter(filter(...)) by having a static to make filters.
            Expr expr = (Expr)iter.next();
            // If null?
            current = OpFilter.filter(expr, current) ;
        }
        
        for (Iterator iter = block.optionals.listIterator() ; iter.hasNext() ; )
        {
            ElementOptional eltOpt = (ElementOptional)iter.next();

            if ( eltOpt.getFixedElement() != null )
                broken("compileBlock/Non-null fixed optional") ;
            Element elt = eltOpt.getOptionalElement() ;
            Op op = compileFixedElement(elt) ;
            Expr expr = null ;
            if ( op instanceof OpFilter )
            {
                OpFilter f = (OpFilter)op ;
                Op sub = f.getOp() ;
                if ( sub instanceof OpFilter )
                    broken("compileBlock/Optional/nested filters - unfinished") ; 
                expr = f.getExpr() ;
                op = sub ;
            }
            
            current = new OpLeftJoin(current, op, expr) ;
        }
        return current ;
    }

    private Op createJoin(Op left, Op right)
    {
        if ( left == null )
            return right ;
        return new OpJoin(left, right) ;
    }
    
    
    private Op compileFixedElement(Element elt)
    {
        // Visitor with a result.  Easier in Java5.
      if ( elt instanceof ElementBasicGraphPattern )
          return compile((ElementBasicGraphPattern)elt) ; 
      
      if ( elt instanceof ElementUnion )
      {
          broken("compileFixedElement/ElementUnion") ;
      }

      if ( elt instanceof ElementGroup )
          return compile((ElementGroup)elt) ; 

      broken("compileFixedElement/Not a fixed element: "+Utils.className(elt)) ;
      return null ;
    }

    
    private List groupToBlocks(ElementGroup el)
    {
        List blocks = new ArrayList() ;
        Block block = new Block() ;
        blocks.add(block) ;
        
        boolean inOptionalPart = false ; 
        for (Iterator iter = el.getElements().listIterator() ; iter.hasNext() ; )
        {
            Element groupElt = (Element)iter.next() ;
            if ( groupElt instanceof ElementOptional )
            {
                // End block
                inOptionalPart = true ;
                block.optionals.add(groupElt) ;
                continue ;
            }
            
            // Optional part, conmjunctive element => new block 
            if ( inOptionalPart )
            {
                block = new Block() ;
                blocks.add(block) ;
            }
                
            if (  groupElt instanceof ElementFilter )
            {
                ElementFilter f = (ElementFilter)groupElt ; 
                block.filters.add(f.getExpr()) ;
                continue ;
            }
            
            block.conjuncts.add(groupElt) ;
        }
        return blocks ;
    }

    private void broken(String msg)
    {
        System.err.println("AlgebraCompilerVisitor: "+msg) ;
        throw new ARQInternalErrorException(msg) ;
    }
}

class A
{
    static QueryIterator makeRoot()
    {
        Binding rootBinding = BindingBase.createRootBinding() ;
        QueryIterator initialIter = new QueryIterSingleton(rootBinding, null) ;
        return initialIter ;
    }
    
    static Op makeOpUnit()
    {
        Binding rootBinding = BindingBase.createRootBinding() ;
        QueryIterator initialIter = new QueryIterSingleton(rootBinding, null) ;
        return new TableUnit() ;
    }

}

/*
 * (c) Copyright 2006 Hewlett-Packard Development Company, LP
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in the
 *    documentation and/or other materials provided with the distribution.
 * 3. The name of the author may not be used to endorse or promote products
 *    derived from this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE AUTHOR ``AS IS'' AND ANY EXPRESS OR
 * IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES
 * OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED.
 * IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR ANY DIRECT, INDIRECT,
 * INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT
 * NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
 * DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
 * THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
 * (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF
 * THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */