/*
 * (c) Copyright 2006 Hewlett-Packard Development Company, LP
 * All rights reserved.
 * [See end of file]
 */

package com.hp.hpl.jena.query.engine2.op;

import java.io.OutputStream;
import java.util.Iterator;

import com.hp.hpl.jena.graph.Node;
import com.hp.hpl.jena.graph.Triple;
import com.hp.hpl.jena.query.engine2.Table;
import com.hp.hpl.jena.query.engine2.table.TableUnit;
import com.hp.hpl.jena.query.expr.Expr;
import com.hp.hpl.jena.query.util.ExprUtils;
import com.hp.hpl.jena.query.util.FmtUtils;
import com.hp.hpl.jena.query.util.IndentedWriter;

public class OpWriter
{
    public static final String startMarker = "(" ;
    public static final String finishMarker = ")" ;
    
    public static void out(OutputStream out, Op op)
    {
        out(new IndentedWriter(out), op) ;
    }

    public static void out(IndentedWriter iWriter, Op op)
    {
        op.visit(new OpWriterWorker(iWriter)) ;
        //iWriter.ensureStartOfLine() ;
        iWriter.flush();
    }
    
    static class OpWriterWorker implements OpVisitor
    {
        IndentedWriter out ;
        public OpWriterWorker(IndentedWriter out) { this.out = out ; }
        
        private void visitOp2(String label, Op2 op, Expr expr)
        {
            start(label) ;
            printOp(op.getLeft()) ;

            //out.println() ; 
            out.ensureStartOfLine() ;

            printOp(op.getRight()) ;

            out.ensureStartOfLine() ;
            //out.println() ; 

            if ( expr != null )
            {
                out.print("(expr ") ;
                ExprUtils.fmtSPARQL(out, expr) ;
                out.println(" )") ;
            }
            finish() ;
        }

        private void visitOp1(String label, Op1 op)
        {
            start(label) ;
            printOp(op.getSubOp()) ;
            finish() ;
        }

        public void visit(OpQuadPattern opQuadP)
        { 
            start("quadpattern") ;
            //boolean first
            for ( Iterator iter = opQuadP.getQuads().listIterator() ; iter.hasNext() ;)
            {
               Quad quad = (Quad)iter.next() ;
               formatQuad(quad) ;
               out.println() ;
            }
            finish() ;
        }
        
        public void visit(OpBGP opBGP)
        {
            start("basicgraphpattern") ;
            //boolean first
            for ( Iterator iter = opBGP.getPattern().listIterator() ; iter.hasNext() ;)
            {
               Triple t = (Triple)iter.next() ;
               formatTriple(t) ;
               out.println() ;
            }
            finish() ;
        }
        
        public void visit(OpJoin opJoin)
        { visitOp2("Join", opJoin, null) ; }

        public void visit(OpLeftJoin opLeftJoin)
        { visitOp2("LeftJoin", opLeftJoin, opLeftJoin.getExpr()) ; }
        
    
        public void visit(OpUnion opUnion)
        { visitOp2("Union", opUnion, null) ; } 
    
        public void visit(OpFilter opFilter)
        { 
            start("filter", false) ;
            out.print(" ") ;
            Expr expr = opFilter.getExpr() ;
            if ( expr == null )
                out.print("(null expr)") ;
            else
                ExprUtils.fmtSPARQL(out, expr) ;
            out.println();
            printOp(opFilter.getSubOp()) ;
            finish() ;
        }
    
        public void visit(OpGraph opGraph)
        {
            start("Graph", false) ;
            out.print(" ") ;
            out.println(FmtUtils.stringForNode(opGraph.getNode())) ;
            out.incIndent() ;
            opGraph.getSubOp().visit(this) ;
            finish() ;
        }

        public void visit(Table table)
        {
            if ( table instanceof TableUnit )
            {
                out.print("(unit table)") ;
                return ;
            } 
                
            if ( table == null )
                out.print("(null table)") ;
            else
                out.print("(table)") ;
            
        }
        
        public void visit(OpPlanElement element)
        {
            out.println("(OpPlanElement") ;
            out.incIndent() ;
            String x = element.getPlanElement().toString() ;
            if ( x.endsWith("\n") )
                x = x.substring(0, x.length()-2) ;
            out.print(x) ;
            finish() ;
        }

        public void visit(OpDatasetNames dsNames)
        {

            out.print("(TableDatasetNames") ;
            out.print(" "); 
            out.print(slotToString(dsNames.getGraphNode())) ;
        }

        public void visit(OpExt opExt)
        {
            //start("OpExt") ;
            opExt.output(out) ;
            //finish() ;
        }

        private void start(String label)
        { start(label, true) ; }

        private void start(String label, boolean newline)
        {

            out.print(startMarker) ;
            out.print(label) ;
            if ( newline ) out.println();
            out.incIndent() ;
        }
        
        private void finish()
        {
            out.decIndent() ;
            out.print(finishMarker) ;
        }
        
        private void printOp(Op op)
        {
            if ( op == null )
                out.print("(null)") ;
            else
                op.visit(this) ;
        }
        
        private void formatTriple(Triple tp)
        {
            out.print(slotToString(tp.getSubject())) ;
            out.print(" ") ;
            out.print(slotToString(tp.getPredicate())) ;
            out.print(" ") ;
            out.print(slotToString(tp.getObject())) ;
        }

        private void formatQuad(Quad qp)
        {
            out.print(slotToString(qp.getGraph())) ;
            out.print(" ") ;
            out.print(slotToString(qp.getSubject())) ;
            out.print(" ") ;
            out.print(slotToString(qp.getPredicate())) ;
            out.print(" ") ;
            out.print(slotToString(qp.getObject())) ;
        }

        private String slotToString(Node n)
        {
            return FmtUtils.stringForNode(n/*, context*/) ;
        }

    }
}

/*
 * (c) Copyright 2006 Hewlett-Packard Development Company, LP
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in the
 *    documentation and/or other materials provided with the distribution.
 * 3. The name of the author may not be used to endorse or promote products
 *    derived from this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE AUTHOR ``AS IS'' AND ANY EXPRESS OR
 * IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES
 * OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED.
 * IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR ANY DIRECT, INDIRECT,
 * INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT
 * NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
 * DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
 * THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
 * (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF
 * THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */