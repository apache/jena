/*
 * (c) Copyright 2006 Hewlett-Packard Development Company, LP
 * All rights reserved.
 * [See end of file]
 */

package com.hp.hpl.jena.query.engine2.op;

import java.io.OutputStream;

import com.hp.hpl.jena.query.engine2.Table;
import com.hp.hpl.jena.query.expr.Expr;
import com.hp.hpl.jena.query.util.ExprUtils;
import com.hp.hpl.jena.query.util.IndentedWriter;

public class OpWriter
{
    public static void out(OutputStream out, Op op)
    {
        out(new IndentedWriter(out), op) ;
    }

    public static void out(IndentedWriter iWriter, Op op)
    {
        op.visit(new OpWriterWorker(iWriter)) ;
        iWriter.println();
        iWriter.flush();
    }

    
    static class OpWriterWorker implements OpVisitor
    {
        IndentedWriter out ;
        public OpWriterWorker(IndentedWriter out) { this.out = out ; }
        
        private void visitOp2(String label, Op2 op, Expr expr)
        {
            out.println("("+label) ;
            out.incIndent() ;
            printOp(op.getLeft()) ;
            out.println() ; 
            printOp(op.getRight()) ;
            out.println() ; 
            if ( expr != null )
            {
                out.print("(expr ") ;
                ExprUtils.fmtSPARQL(out, expr) ;
                out.println(" )") ;
            }
            out.decIndent() ;
            out.print(")") ;
        }

        private void visitOp1(String label, Op1 op)
        {
            out.println("("+label) ;
            out.incIndent() ;
            printOp(op.getOp()) ;
            out.print(")") ;
        }

        
        public void visit(OpJoin opJoin)
        { visitOp2("Join", opJoin, null) ; }

        public void visit(OpLeftJoin opLeftJoin)
        { visitOp2("LeftJoin", opLeftJoin, opLeftJoin.getExpr()) ; }
        
    
        public void visit(OpUnion opUnion)
        { visitOp2("Union", opUnion, null) ; } 
    
        public void visit(OpFilter opFilter)
        { 
            out.println("(filter") ;
            out.incIndent() ;
            Expr expr = opFilter.getExpr() ;
            if ( expr == null )
                out.println("(null expr)") ;
            else
                ExprUtils.fmtSPARQL(out, expr) ;
            out.println();
            printOp(opFilter.getOp()) ;
            out.print(")") ;
        }
    
        public void visit(Table table)
        {
            if ( table == null )
                out.println("(null table)") ;
            else
                out.println("(table)") ;
        }
        
        public void visit(OpPlanElement element)
        {
            out.println("(OpPlanElement") ;
            out.incIndent() ;
            String x = element.getPlanElement().toString() ;
            if ( x.endsWith("\n") )
                x = x.substring(0, x.length()-2) ;
            out.print(x) ;
            out.decIndent() ;
            out.println();
            out.print(")") ;
        }

        private void printOp(Op op)
        {
            if ( op == null )
                out.print("(null)") ;
            else
                op.visit(this) ;
        }
    }
}

/*
 * (c) Copyright 2006 Hewlett-Packard Development Company, LP
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in the
 *    documentation and/or other materials provided with the distribution.
 * 3. The name of the author may not be used to endorse or promote products
 *    derived from this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE AUTHOR ``AS IS'' AND ANY EXPRESS OR
 * IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES
 * OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED.
 * IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR ANY DIRECT, INDIRECT,
 * INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT
 * NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
 * DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
 * THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
 * (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF
 * THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */