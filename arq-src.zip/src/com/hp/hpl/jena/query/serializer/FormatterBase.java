/*
 * (c) Copyright 2004, 2005, 2006 Hewlett-Packard Development Company, LP
 * All rights reserved.
 * [See end of file]
 */

package com.hp.hpl.jena.query.serializer;
import java.util.Iterator;
import java.util.List;

import com.hp.hpl.jena.graph.Node;
import com.hp.hpl.jena.graph.Triple;
import com.hp.hpl.jena.query.util.FmtUtils;
import com.hp.hpl.jena.query.util.IndentedWriter;

/** 
 * @author Andy Seaborne
 * @version $Id: FormatterBase.java,v 1.7 2006/07/02 11:03:19 andy_seaborne Exp $
 */

public abstract class FormatterBase
{
    IndentedWriter out ;
    SerializationContext context ;
    FormatterBase(IndentedWriter _out, SerializationContext _context)
    {
        out = _out ;
        context = _context ; 
    }
    
    public void startVisit()  {}
    public void finishVisit() { out.flush() ; }
    
    // Utilities
    
    protected void formatTriples(List triples)
    {
        boolean first = true ;
        for ( Iterator iter = triples.iterator() ; iter.hasNext() ; )
        {
            if ( ! first )
                out.println() ;
            Triple t = (Triple)iter.next() ; 
            formatTriple(t) ;
            out.print(" .") ;
            first = false ;
        }
    }
    
    protected void formatTriple(Triple tp)
    {
        out.print(slotToString(context, tp.getSubject())) ;
        out.print(" ") ;
        out.print(slotToString(context, tp.getPredicate())) ;
        out.print(" ") ;
        out.print(slotToString(context, tp.getObject())) ;
    }
    
    protected String slotToString(SerializationContext context, Node n)
    {
        return FmtUtils.stringForNode(n, context) ;
    }


}

/*
 * (c) Copyright 2004, 2005, 2006 Hewlett-Packard Development Company, LP
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in the
 *    documentation and/or other materials provided with the distribution.
 * 3. The name of the author may not be used to endorse or promote products
 *    derived from this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE AUTHOR ``AS IS'' AND ANY EXPRESS OR
 * IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES
 * OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED.
 * IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR ANY DIRECT, INDIRECT,
 * INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT
 * NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
 * DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
 * THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
 * (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF
 * THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */