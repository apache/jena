/*
 * (c) Copyright 2004, 2005, 2006 Hewlett-Packard Development Company, LP
 * All rights reserved.
 * [See end of file]
 */

package com.hp.hpl.jena.query.serializer;

import java.util.Iterator;

import com.hp.hpl.jena.query.core.*;
import com.hp.hpl.jena.query.expr.Expr ;
import com.hp.hpl.jena.query.expr.ExprVisitor ;
import com.hp.hpl.jena.query.util.IndentedLineBuffer;
import com.hp.hpl.jena.query.util.IndentedWriter;
import com.hp.hpl.jena.query.util.FmtUtils;

/** com.hp.hpl.jena.query.core.FormatterARQ
 * 
 * @author Andy Seaborne
 * @version $Id: FormatterAbstract.java,v 1.21 2006/01/19 17:21:29 andy_seaborne Exp $
 */

public class FormatterAbstract extends FormatterBase
    implements FormatterElement, FormatterTemplate 
{
    static int INDENT = FormatterElement.INDENT ;

    static final boolean closingBracketOnSameLine = QuerySerializerAbstract.closingBracketOnSameLine ; 
    static final boolean allowDoubles = true ;

    public FormatterAbstract(IndentedWriter out, SerializationContext context)
    {
        super(out, context) ;
    }
    
    public static void format(IndentedWriter out, SerializationContext cxt, Element el)
    {
        FormatterAbstract fmt = new FormatterAbstract(out, cxt) ;
        fmt.startVisit() ;
        el.visit(fmt) ;
        fmt.finishVisit() ;
    }
    
    
    public static String asString(Element el)
    {
        SerializationContext cxt = new SerializationContext() ;
        IndentedLineBuffer b = new IndentedLineBuffer() ;
        FormatterAbstract.format(b.getIndentedWriter(), cxt, el) ;
        return b.toString() ;
    }

    public void visit(ElementTriplePattern el)
    {
        out.print("(triplepattern") ;
        out.print(" ") ;
        formatTriple(el.getTriple()) ;
        printClose() ;
        
    }
    
    public void visit(ElementBlock el)
    {
        out.print("(block") ;
        out.incIndent(INDENT) ;
        out.newline() ;
        if ( el.getDataset() != null )
            out.print("dataset") ;
        el.getPatternElement().visit(this) ;
        out.decIndent(INDENT) ;
        printClose() ;
    }

    public void visit(ElementFilter el)
    {
        //writer.newline() ;
        out.print("(filter") ;
        out.incIndent(INDENT) ;
        out.print(" ") ;
        if ( el.getConstraint().isExpr() )
        {
            ExprVisitor v = new FmtExprAbstract(out, context) ;
            el.getConstraint().getExpr().visit(v) ;
        }
        else
            out.print(el.getConstraint().toString()) ;
        out.decIndent(INDENT) ;
        printClose() ;
    }
    
    public void visit(ElementUnion el)
    {
        multiElement("union", el.getElements().iterator()) ;
    }
    public void visit(ElementGroup el)
    {
        multiElement("group", el.getElements().iterator()) ;
    }

    public void visit(ElementOptional el)
    {
        singleElement("optional", el.getElement()) ;
    }
    
    public void visit(ElementNamedGraph el)
    {
        out.print("(graph ") ;
        out.print(slotToString(context, el.getGraphNameNode())) ;
        out.incIndent(INDENT) ;
        out.newline() ;
        el.getElement().visit(this) ;
        out.decIndent(INDENT) ;
        printClose() ;
    }
    
    public void visit(ElementUnsaid el)
    {
        singleElement("unsaid", el.getElement()) ;
    }
    
    public void visit(ElementExtension el)
    {
        out.print("(ext ") ;
        String uri = el.getURI() ;
        String tmp = FmtUtils.stringForURI(uri, context.getPrefixMapping()) ;
        out.print(tmp) ;
        out.print("(") ;
        
        for ( int i = 1 ; ; i++ )  
        {
            Expr expr = el.getArg(i) ;
            if ( expr == null )
                break ; 
            if ( i != 1 )
                out.print(", ") ;
            ExprVisitor v = new FmtExprARQ(out, context) ;
            expr.visit(v) ;
        }
        out.print(")") ;
        out.println(" )") ;
        //printClose() ;
    }
    
    // ---- Worker functions
    
    private void singleElement(String name, Element element)
    {
        out.print("(") ;
        out.print(name) ;
        out.incIndent(INDENT) ;
        out.newline() ;
        element.visit(this) ;
        out.decIndent(INDENT) ;
        printClose() ;
    }
    
    private void multiElement(String name, Iterator iter)
    {
        out.print("(") ;
        out.print(name) ;
        out.incIndent(INDENT) ;
        for ( ; iter.hasNext() ; )
        {
            out.newline() ;
            Element element = (Element)iter.next() ;
            element.visit(this) ;
        }
        out.decIndent(INDENT) ;
        printClose() ;
    }
    
    public void visit(TemplateTriple template)
    {
        out.print("(tripletemplate") ;
        out.print(" ") ;
        formatTriple(template.getTriple()) ;
        printClose() ;
//        Triple t = template.getTriple() ;
//        formatTriple(t) ;
    }

    public void visit(TemplateGroup tGroup)
    {
        out.print("(templategroup") ;
        out.incIndent(INDENT) ;
        for ( Iterator iter = tGroup.templates() ; iter.hasNext() ;)
        {
            out.newline() ;
            Template sub = (Template)iter.next() ;
            sub.visit(this) ;
        }
        out.decIndent(INDENT) ;
        printClose() ;
    }
    
    private void printClose()
    {
        if ( closingBracketOnSameLine )
            out.print(")") ;
        else
        {
            out.println() ;
            out.print(")") ;
        }
    }
}

/*
 * (c) Copyright 2004, 2005, 2006 Hewlett-Packard Development Company, LP
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in the
 *    documentation and/or other materials provided with the distribution.
 * 3. The name of the author may not be used to endorse or promote products
 *    derived from this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE AUTHOR ``AS IS'' AND ANY EXPRESS OR
 * IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES
 * OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED.
 * IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR ANY DIRECT, INDIRECT,
 * INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT
 * NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
 * DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
 * THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
 * (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF
 * THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */