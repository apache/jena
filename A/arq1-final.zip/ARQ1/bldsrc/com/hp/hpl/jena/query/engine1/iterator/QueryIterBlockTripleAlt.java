/*
 * (c) Copyright 2006, 2007 Hewlett-Packard Development Company, LP
 * All rights reserved.
 * [See end of file]
 */

package com.hp.hpl.jena.query.engine1.iterator;

import java.util.Iterator;
import java.util.List;

import com.hp.hpl.jena.graph.Graph;
import com.hp.hpl.jena.graph.Triple;
import com.hp.hpl.jena.query.engine.Binding;
import com.hp.hpl.jena.query.engine.QueryIterator;
import com.hp.hpl.jena.query.engine1.ExecutionContext;
import com.hp.hpl.jena.util.iterator.NiceIterator;

public class QueryIterBlockTripleAlt  extends QueryIter
{
    List pattern ;          // List of Triples
    private QueryIterator input ;
    private Graph graph ;
    private QueryIterator output ;
    
    public static QueryIterator create(QueryIterator input,
                                    List pattern , 
                                    ExecutionContext execContext)
    {
        return new QueryIterBlockTripleAlt(input, pattern, execContext) ;
    }
    
    private QueryIterBlockTripleAlt( QueryIterator input,
                                    List pattern , 
                                    ExecutionContext execContext)
    {
        super(execContext) ;
        this.pattern = pattern ;
        this.input = input ;
        graph = execContext.getActiveGraph() ;
        // Create a chain of triple iterators.
        // This code is elsewhere (Group? build serial?)
        QueryIterator chain = input ;
        for ( Iterator iter = pattern.listIterator(); iter.hasNext(); )
        {
            Triple t = (Triple) iter.next() ;
            chain = new QueryIterTriplePattern(chain, t, execContext) ;
        }
        output = chain ;
    }

    //@Override
    protected boolean hasNextBinding()
    {
        return output.hasNext() ;
    }

    //@Override
    protected Binding moveToNextBinding()
    {
        return output.nextBinding() ;
    }

    //@Override
    protected void closeIterator()
    {
        if ( ! isFinished() )
        {
            NiceIterator.close(output) ;
            output = null ;
        }
    }
}

/*
 * (c) Copyright 2006, 2007 Hewlett-Packard Development Company, LP
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in the
 *    documentation and/or other materials provided with the distribution.
 * 3. The name of the author may not be used to endorse or promote products
 *    derived from this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE AUTHOR ``AS IS'' AND ANY EXPRESS OR
 * IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES
 * OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED.
 * IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR ANY DIRECT, INDIRECT,
 * INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT
 * NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
 * DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
 * THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
 * (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF
 * THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */